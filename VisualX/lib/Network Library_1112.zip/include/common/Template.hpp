#pragma once
/// Log Include
#include "common/verbose.h"

/// Common Include
#include "common/CommonInclude.h"

/// Template Function Include
#include "common/template/TemplateUtility.hpp"

/// Custom Memory Include
#include "common/refptr.hpp"