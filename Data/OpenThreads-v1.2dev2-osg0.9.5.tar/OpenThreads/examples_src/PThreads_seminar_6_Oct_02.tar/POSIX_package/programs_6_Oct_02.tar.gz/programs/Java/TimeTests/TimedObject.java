//              TimedObject.java

/*
  
*/

import java.io.*;
import java.util.*;
import Extensions.*;


public interface TimedObject { 

public void test(int n);

}
