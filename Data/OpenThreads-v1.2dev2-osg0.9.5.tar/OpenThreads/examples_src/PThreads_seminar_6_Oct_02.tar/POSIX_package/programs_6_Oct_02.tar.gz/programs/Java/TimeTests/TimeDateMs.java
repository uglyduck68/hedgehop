import java.io.*;
import Extensions.*;
import java.util.*;

public class TimeDateMs implements TimedObject {
  static int j = 0;

 
public void test(int n) {
  for (int i=0; i<n; i++)
    {new Date().getTime();}
  
}
}
