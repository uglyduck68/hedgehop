//              ServerSimple/Consumer.java

import java.io.*;
import Extensions.*;



public class Consumer implements Runnable {
  Workpile                      workpile;



public Consumer(Workpile w) {
  workpile = w;
}



public void run() {
}
 
}
