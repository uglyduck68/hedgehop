//              TestRecursiveMutex/MyRecursiveMutex.java

/*
  A place holder for you...
*/

import java.io.*;
import Extensions.*;


public class MyRecursiveMutex {
}
