import java.io.*;
import Extensions.*;
 

public class DiscriminationNet2 implements TimedObject {
  static int j = 0;

  

public void test(int n) {
  Object[] a = new Object[1];
  a[0] = new Thingg();
  for (int i=0; i<n; i++)
    {Thingg10 o = (Thingg10) a[0];}
  
}
}


class Thingg10 {
public int foo() {
return 100;
}}

class Thingg9 extends Thingg10 {
public int foo() {
return 10;
}}

class Thingg8 extends Thingg9 {
public int foo() {
return 19;
}}

class Thingg7 extends Thingg8 {
public int foo() {
return 18;
}}

class Thingg6 extends Thingg7 {
public int foo() {
return 17;
}}

class Thingg5 extends Thingg6 {
public int foo() {
return 16;
}}

class Thingg4 extends Thingg5 {
public int foo() {
return 15;
}}

class Thingg3 extends Thingg4 {
public int foo() {
return 14;
}}

class Thingg2 extends Thingg3 {
public int foo() {
return 13;
}}

class Thingg1 extends Thingg2 {
public int foo() {
return 12;
}}

class Thingg extends Thingg1 {
public int foo() {
return 1;
}}
