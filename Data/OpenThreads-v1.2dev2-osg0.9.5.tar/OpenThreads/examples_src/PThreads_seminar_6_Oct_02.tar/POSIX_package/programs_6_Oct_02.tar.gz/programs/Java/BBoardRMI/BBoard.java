//              ServerSelect/Reporter.java

import java.io.*;
import java.net.*;
import Extensions.*;



public class BBoard {
}
