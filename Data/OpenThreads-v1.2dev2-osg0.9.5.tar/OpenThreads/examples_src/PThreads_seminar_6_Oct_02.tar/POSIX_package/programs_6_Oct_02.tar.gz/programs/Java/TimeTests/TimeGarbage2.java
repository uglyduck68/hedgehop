
import java.util.*;
import java.io.*;
import Extensions.*;


public class TimeGarbage2 implements TimedObject {
 TimeGarbage2 p[] = new TimeGarbage2[100];

  

public   void test(int n) { 

  for (int i=0; i<n; i++) 
    {
      TimeGarbage2 g = new TimeGarbage2();
    } 
}
}
