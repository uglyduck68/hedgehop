import java.io.*;
import Extensions.*;


public class TimeGlobalSet implements TimedObject {
  static int j = 0;

 
public void test(int n) {
  for (int i=0; i<n; i++)
    {j++;}
  
}
}
