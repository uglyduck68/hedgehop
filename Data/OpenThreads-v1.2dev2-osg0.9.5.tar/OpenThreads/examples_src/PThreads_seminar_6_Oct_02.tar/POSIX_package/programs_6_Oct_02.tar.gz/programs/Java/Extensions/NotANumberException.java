//              Extensions/NotANumberException.java

package Extensions;

public class NotANumberException extends Exception {


public NotANumberException(String s)
    {super(s);}

public NotANumberException( )
    { }

}
