package Logger;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Checkbox;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTree;

import java.awt.Dimension;
import java.awt.Point;

import javax.swing.border.TitledBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import java.awt.GridLayout;

import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.Box;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import javax.swing.BoxLayout;

import com.rti.dds.dynamicdata.DynamicData;
import com.rti.dds.dynamicdata.DynamicDataMemberInfo;
import com.rti.dds.infrastructure.BadKind;
import com.rti.dds.infrastructure.ByteSeq;
import com.rti.dds.typecode.TCKind;
import com.rti.dds.typecode.TypeCode;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;

import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;

import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.border.EtchedBorder;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Toolkit;

class MyDataType
{
	DynamicData dynamicData;
	String		sendCSCI;
	String		receiveTime;
}
 //���̺� ��
 class MyTableModel extends AbstractTableModel
 {
	String col[] = {"Time","Send CSCI","Topic Name"};
	Vector <MyDataType> data = new Vector();
	
  public int getRowCount(){
   return data.size();
  }
  public int getColumnCount(){
   return col.length;
  }
  public Object getValueAt(int row, int column)
  {
	  Object ret=null;
	  
	  MyDataType dynamicData  = data.elementAt(row);
	   
	  if( dynamicData == null )
	  {
		  ret = "ERROR";
	  }
	  else
	  {
		  switch(column)
		  {
		  case 0:
			  ret = dynamicData.receiveTime;
			  break;
		  case 1:
			  ret = dynamicData.sendCSCI;
			  break;
		  case 2:
			  ret = dynamicData.dynamicData.get_type();
			  if (ret == null )
				  ret = dynamicData.receiveTime;
			  break;
			  
		  }
	  }
	  return ret;
  }
  public String getColumnName(int column){
   return col[column];
  }
  
  public DynamicData getContents(int row)
  {
	  return data.elementAt(row).dynamicData;
  }
  
  public void addRow(DynamicData i_data)
  {
  	//������ Ŀ���� ù��° ����
    if ( getRowCount() >  2000000 )
    	data.removeElementAt(0);
    
    
	//����ð�
	Date date = new Date();
	SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	String strDate = dayTime.format(date);
	
	short shortData = -1;
	
	DynamicData dataSub = new DynamicData( );
	
	if( i_data.member_exists("stHead" ,DynamicData.MEMBER_ID_UNSPECIFIED))
	{
		i_data.get_complex_member(dataSub,"stHead" ,DynamicData.MEMBER_ID_UNSPECIFIED);
		shortData = dataSub.get_short("bySendCSCI", DynamicData.MEMBER_ID_UNSPECIFIED);
	}
	
	String strSendCSCI; 
	switch( shortData )
	{
	case 1:
		strSendCSCI = "MFC-1";
		break;
	case 2:
		strSendCSCI = "MFC-2";
		break;
	case 3:
		strSendCSCI = "MFC-3";
		break;
	case 4:
		strSendCSCI = "IPN";
		break;
	case 5:
		strSendCSCI = "IICU";
		break;
	case 6:
		strSendCSCI = "DLP";
		break;
	case 7:
		strSendCSCI = "VDRE-1";
		break;
	case 8:
		strSendCSCI = "VDRE-2";
		break;
	case 9:
		strSendCSCI = "VDRE-3";
		break;
	case 10:
		strSendCSCI = "SBT";
		break;
	case 11:
		strSendCSCI = "SDU";
		break;
	case 12:
		strSendCSCI = "PANEL";
		break;
	default:
		strSendCSCI = "etc";
		break;
	}

	//����Ʈ�� ������ ���� �ʱ� ����
/*		if( data.size() < 65536 )
		{
			
		}
		else
		{
			data.remove(0);
		}
*/			
		
	  MyDataType myDataType = new MyDataType();
	  myDataType.dynamicData = i_data;
	  myDataType.sendCSCI = strSendCSCI;
	  myDataType.receiveTime = strDate;
	  data.add(myDataType);
  }
  
  public void Clear()
  {
	  data.clear();
  }

 }
 

 
 //GUI Ŭ����
public class DDSMonitorUI {

	private JFrame frmLigTopic;
	private JTable table_1;
	private int iCount = 0;
	private JTree tree;
	private JScrollPane scrollPane;
	private static DDSMonitorUI m_instance = null;
	private JCheckBox chckbxMfc;
	private JCheckBox chckbxMfc_1;
	private JCheckBox chckbxMfc_2;
	private JCheckBox chckbxIpn;
	private JCheckBox chckbxIicu;
	private JCheckBox chckbxDlp;
	private JCheckBox chckbxVdre;
	private JCheckBox chckbxVdre_2;
	private JCheckBox chckbxVdre_1;
	private JCheckBox chckbxSbt;
	Timer t;
	private boolean bIsRun = true;
	private JCheckBox chckbxEtc;
	private JCheckBox chckbxSdu;
	private JCheckBox checkBox_11; 
	private JTextField textField_1;
	private boolean bIsPause = false;
	private JTextField textField_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private Component horizontalGlue;
	private JTextField textFieldDomainNo;
	private JTextField textFieldFilter;
			
	public void RefreshUI()
	{
	   SwingUtilities.invokeLater(new Runnable() 
		 {

			@Override
			public void run() {
				//Refresh
				table_1.updateUI();
		    	
				if( bIsRun )
				{
					//���̺� ���� �Ʒ���
					scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum());
				}				
			}
				
	     });
	}
	 //Ÿ�̸� Ŭ����
	 class TimesGo extends TimerTask 
	 { //TimerTask �� ��ӹ޴´�.
	     @Override
	    public void run() 
	    { //run()�޼ҵ� ����, ������ �۾�
	      	RefreshUI();
	    }
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					m_instance = new DDSMonitorUI();
					m_instance.frmLigTopic.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static synchronized DDSMonitorUI getInstance()
	{
		if(m_instance == null)
		{
			m_instance = new DDSMonitorUI();
		}
		
		return m_instance;
	}

	public void AddColumn(DynamicData data)
	{
		short shortData = -1;
		
		DynamicData dataSub = new DynamicData( );
		
		if( data.member_exists("stHead" ,DynamicData.MEMBER_ID_UNSPECIFIED))
		{
			data.get_complex_member(dataSub,"stHead" ,DynamicData.MEMBER_ID_UNSPECIFIED);
			shortData = dataSub.get_short("bySendCSCI", DynamicData.MEMBER_ID_UNSPECIFIED);
		}

		
		boolean bPrint = false;
		
		//üũ �ڽ� �׽�Ʈ �� üũ �ȰŸ� �Է�
		if( chckbxMfc.isSelected() && shortData == 1) // MFC_1
			bPrint = true;
		else if( chckbxMfc_1.isSelected() && shortData == 2) // MFC_2
			bPrint = true;
		else if( chckbxMfc_2.isSelected() && shortData == 3) // MFC_3
			bPrint = true;
		else if( chckbxIpn.isSelected() && shortData == 4) // IPN
			bPrint = true;
		else if( chckbxIicu.isSelected() && shortData == 5) // IICU
			bPrint = true;
		else if( chckbxDlp.isSelected() && shortData == 6) // DLP
			bPrint = true;
		else if( chckbxVdre.isSelected() && shortData == 7) // VDRE_1
			bPrint = true;
		else if( chckbxVdre_2.isSelected() && shortData == 8) // VDRE_2
			bPrint = true;
		else if( chckbxVdre_1.isSelected() && shortData == 9) // VDRE_3
			bPrint = true;
		else if( chckbxSbt.isSelected() && shortData == 10) // SBT
			bPrint = true;
		else if( checkBox_11.isSelected() && shortData == 12) // Panel
			bPrint = true;
		else if( chckbxSdu.isSelected() && shortData == 11 ) // SDU 
			bPrint = true;
		else if( chckbxEtc.isSelected() && ( shortData > 12 || shortData <= 0))  //ETC
			bPrint = true;
		//else
			//bPrint = true;
		
		//Filter�� �ش��ϴ°͸� ���
		String textFilter = textFieldFilter.getText();
		String topicNameFilter = data.get_type().toString();
		if( topicNameFilter.contains( textFilter ) && textFilter.isEmpty() == false   && bPrint == true)
			bPrint = true;
		else if( !topicNameFilter.contains( textFilter ) && textFilter.isEmpty() == false )
			bPrint= false;
		
		//Ư���ܾ�� �ɷ��� ���
		String textException = textField_1.getText();
		String topicName = data.get_type().toString();
		if( topicName.contains( textException ) && textException.isEmpty() == false )
			bPrint = false;
		
		//�Ͻ� ����
		if( bIsPause )
			bPrint = false;
		
		if( bPrint == true )
		{
			//�Է�
			MyTableModel tm = (MyTableModel)table_1.getModel();
			tm.addRow(data);
		}
	}
	
	/**
	 * Create the application.
	 */
	public DDSMonitorUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLigTopic = new JFrame();
		frmLigTopic.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\71165\\Pictures\\LIG logo.gif"));
		frmLigTopic.setTitle("LIG\uB125\uC2A4\uC6D0 SWSS \uC804\uD22C\uCCB4\uACC4 DDS Topic \uBAA8\uB2C8\uD130\uB9C1 \uD504\uB85C\uADF8\uB7A8 (v 0.52)");
		frmLigTopic.getContentPane().setSize(new Dimension(300, 500));
		frmLigTopic.getContentPane().setMinimumSize(new Dimension(300, 500));
		frmLigTopic.setBounds(100, 100, 1024, 727);
		frmLigTopic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBag = new GridBagLayout();
		gridBag.columnWeights = new double[]{0.0, 1.0, 0.5};
		gridBag.columnWidths = new int[]{200, 200, 200};
		frmLigTopic.getContentPane().setLayout(gridBag);

		
		JPanel panel = new JPanel();
		panel.setBounds(new Rectangle(0, 0, 300, 0));
		
		GridBagConstraints con= new GridBagConstraints();
		con.weightx = 1.0;
		con.weighty = 1.0;
		con.fill = GridBagConstraints.BOTH;
		con.gridx = 0;
		con.gridy = 0;
		con.gridwidth = 1;
		con.gridheight = 1;
		con.weightx = 0.2;
		
		frmLigTopic.getContentPane().add(panel, con);
		
		JButton btnNewButton = new JButton("\uC2DC\uC791");
		btnNewButton.setBounds(71, 25, 63, 31);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String textDomain = textFieldDomainNo.getText();
				
				Logger logger = new Logger();
				if ( !logger.start(Integer.parseInt(textDomain)) ) {
					return;
				}
				textFieldDomainNo.setEnabled(false);

				
				//Ÿ�̸� ����
				t = new Timer();         
				TimesGo tg = new TimesGo();      // Timer�� ������ �۾� ��ü ����( TimerTask Ŭ������ ��ӹ޾Ƽ� ������ Ŭ����) 
		        // 3���� 1�ʸ��� ����
		        t.schedule(tg, 0 , 1000);
		        
		        btnNewButton.setEnabled(false);
		        

			}
		});
		panel.setLayout(null);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC885\uB8CC");
		btnNewButton_1.setBounds(51, 673, 127, 25);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		panel.add(btnNewButton_1);
		
		Box verticalBox = Box.createVerticalBox();
		verticalBox.setBounds(31, 66, 167, 362);
		verticalBox.setBorder(new TitledBorder(null, "CSCI", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(verticalBox);
		
		chckbxMfc = new JCheckBox("MFC_1");
		verticalBox.add(chckbxMfc);
		
		chckbxMfc_1 = new JCheckBox("MFC_2");
		verticalBox.add(chckbxMfc_1);
		
		chckbxMfc_2 = new JCheckBox("MFC_3");
		verticalBox.add(chckbxMfc_2);
		
		chckbxIpn = new JCheckBox("IPN");
		verticalBox.add(chckbxIpn);
		
		chckbxIicu = new JCheckBox("IICU");
		verticalBox.add(chckbxIicu);
		
		chckbxDlp = new JCheckBox("DLP");
		verticalBox.add(chckbxDlp);
		
		chckbxVdre = new JCheckBox("VDRE_1");
		verticalBox.add(chckbxVdre);
		
		chckbxVdre_1 = new JCheckBox("VDRE_2");
		verticalBox.add(chckbxVdre_1);
		
		chckbxVdre_2 = new JCheckBox("VDRE_3");
		verticalBox.add(chckbxVdre_2);
		
		chckbxSbt = new JCheckBox("SBT");
		verticalBox.add(chckbxSbt);
		
		chckbxSdu = new JCheckBox("SDU");
		verticalBox.add(chckbxSdu);
		
		checkBox_11 = new JCheckBox("PPC");
		verticalBox.add(checkBox_11);
		
		chckbxEtc = new JCheckBox("etc");
		verticalBox.add(chckbxEtc);
		
		JToggleButton btnNewButton_2 = new JToggleButton("||");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//�Ͻ� ����
				bIsPause = !bIsPause;
			}
		});
		btnNewButton_2.setBounds(135, 25, 63, 31);
		panel.add(btnNewButton_2);
		
		Box exclusion = Box.createVerticalBox();
		exclusion.setBorder(new TitledBorder(null, "Exclusion", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		exclusion.setBounds(31, 479, 167, 50);
		panel.add(exclusion);
		
		textField_1 = new JTextField();
		exclusion.add(textField_1);
		textField_1.setColumns(10);
		
		Box verticalBox_1 = Box.createVerticalBox();
		verticalBox_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Search", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		verticalBox_1.setBounds(31, 528, 167, 78);
		panel.add(verticalBox_1);
		
		textField_2 = new JTextField();
		verticalBox_1.add(textField_2);
		textField_2.setColumns(10);
		
		Box horizontalBox = Box.createHorizontalBox();
		verticalBox_1.add(horizontalBox);
		
		Component horizontalGlue_1 = Box.createHorizontalGlue();
		horizontalBox.add(horizontalGlue_1);
		
		btnNewButton_3 = new JButton("Prev");
		horizontalBox.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//���� ���õ� ��
				int rowIndex = table_1.getSelectedRow();

				//������ ã��
				for( int i=rowIndex-1; i>=0 ; i--)
				{
					TypeCode rowData = (TypeCode)table_1.getModel().getValueAt(i,  2 );
					String textFind = textField_2.getText();
					String topicName = rowData.toString();
					
					if( topicName.contains( textFind ) && textFind.isEmpty() == false )
					{
						table_1.changeSelection(i, 0, false, false);
						ShowContents();
						break;
					}
					
				}
			}
		});
		
		horizontalGlue = Box.createHorizontalGlue();
		horizontalBox.add(horizontalGlue);
		
		btnNewButton_4 = new JButton("Next");
		horizontalBox.add(btnNewButton_4);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//���� ���õ� ��
				int rowIndex = table_1.getSelectedRow();

				//������ ã��
				for( int i=rowIndex+1; i<table_1.getRowCount() ; i++)
				{
					TypeCode rowData = (TypeCode)table_1.getModel().getValueAt(i,  2 );
					String textFind = textField_2.getText();
					String topicName = rowData.toString();
					
					if( topicName.contains( textFind ) && textFind.isEmpty() == false )
					{
						table_1.changeSelection(i, 0, false, false);
						ShowContents();
						break;
					}
					
				}
			}
		});
		
		Component horizontalGlue_2 = Box.createHorizontalGlue();
		horizontalBox.add(horizontalGlue_2);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBorder(new TitledBorder(null, "Alignment", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		horizontalBox_1.setBounds(31, 613, 167, 50);
		panel.add(horizontalBox_1);
		
		Component horizontalGlue_3 = Box.createHorizontalGlue();
		horizontalBox_1.add(horizontalGlue_3);
		
		JToggleButton tglbtnNewToggleButton = new JToggleButton("Auto");
		horizontalBox_1.add(tglbtnNewToggleButton);
		
		Component horizontalGlue_4 = Box.createHorizontalGlue();
		horizontalBox_1.add(horizontalGlue_4);
		
		JButton btnClear = new JButton("Clear");
		horizontalBox_1.add(btnClear);
		
		Component horizontalGlue_5 = Box.createHorizontalGlue();
		horizontalBox_1.add(horizontalGlue_5);
		
		Box verticalBox_2 = Box.createVerticalBox();
		verticalBox_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Filter", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		verticalBox_2.setBounds(31, 432, 167, 50);
		panel.add(verticalBox_2);
		
		textFieldFilter = new JTextField();
		textFieldFilter.setColumns(10);
		verticalBox_2.add(textFieldFilter);
		
		textFieldDomainNo = new JTextField();
		textFieldDomainNo.setText("1");
		textFieldDomainNo.setBounds(34, 27, 25, 27);
		panel.add(textFieldDomainNo);
		textFieldDomainNo.setColumns(10);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MyTableModel tm = (MyTableModel)table_1.getModel();
				tm.Clear();
				
				//Refresh
				RefreshUI();
			}
		});
		tglbtnNewToggleButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Ÿ�̸� ����
       
				if( tglbtnNewToggleButton.isSelected() != true )
				{
					bIsRun = true;
				}
				else
				{
					bIsRun = false;
				}
					
			}
		});

		
		MyTableModel tm = new MyTableModel();
		
		table_1 = new JTable(tm);
		
		table_1.getColumnModel().getColumn(0).setPreferredWidth(130);
		table_1.getColumnModel().getColumn(0).setMaxWidth(300);
		
		table_1.getColumnModel().getColumn(1).setPreferredWidth(40);
		table_1.getColumnModel().getColumn(1).setMaxWidth(300);
		
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				ShowContents();
			}
		});
		
		
		scrollPane = new JScrollPane(table_1);
		scrollPane.setPreferredSize(new Dimension(100, 100));
		
		GridBagConstraints con2 = new GridBagConstraints();
		con2.weightx = 1.0;
		con2.weighty = 1.0;
		con2.fill = GridBagConstraints.BOTH;
		con2.gridx = 1;
		con2.gridy = 0;

		con2.gridx = 1;
		con2.gridy = 0;
		con2.weightx = 0;
		
		frmLigTopic.getContentPane().add(scrollPane, con2);
		
		tree = new JTree();
		
		
		JScrollPane scrollPane_1 = new JScrollPane(tree);
		
		GridBagConstraints con3 = new GridBagConstraints();
		con3.weightx = 1.0;
		con3.weighty = 1.0;
		con3.fill = GridBagConstraints.BOTH;
		con3.gridx = 0;
		con3.gridy = 0;

		con3.gridx = 2;
		con3.gridy = 0;
		con3.weightx = 0.2;
		
		frmLigTopic.getContentPane().add(scrollPane_1, con3);
		
		
	}
	
	private void ShowContents()
	{
		//���̺����� ������ �Է¹޾�
		int row = table_1.getSelectedRow();
		MyTableModel tm =  (MyTableModel) table_1.getModel();
		DynamicData myData = tm.getContents(row);
		
		//Ʈ����Ʈ�ѿ� ���
		DefaultTreeModel model = (DefaultTreeModel)tree.getModel(); //�������� �����´�				
						
		DefaultMutableTreeNode root = new javax.swing.tree.DefaultMutableTreeNode(myData.get_type());
		
		for (int j = 0; j < myData.get_member_count(); j++) 
		{
			DynamicDataMemberInfo memberInfo = new DynamicDataMemberInfo();
			myData.get_member_info_by_index(memberInfo, j);
			
			DefaultMutableTreeNode child = MakeNode(myData, memberInfo);
			
			if( child != null )
				root.add(child);
						
		}
		

		model.setRoot(root);

		for( int iTree = 0 ; iTree < tree.getRowCount(); iTree++)
			tree.expandRow(iTree);
	}
	
	//������常���
	private void MakeTree(DefaultMutableTreeNode parentNode, DynamicData data, int count )
	{
//		DynamicDataMemberInfo memberInfo = new DynamicDataMemberInfo();
//		data.get_member_info_by_index(memberInfo, j);
	}
	
	private DefaultMutableTreeNode MakeNode(DynamicData data, DynamicDataMemberInfo memberInfo)
	{
		DefaultMutableTreeNode child= null;
		
		DefaultMutableTreeNode childroot= null;
		
		childroot = new DefaultMutableTreeNode(memberInfo.member_name);

		if (memberInfo.member_kind == TCKind.TK_STRING) 
		{
			//Data is in string form
			String stringData = data.get_string(memberInfo.member_name, memberInfo.member_id);

			child = new DefaultMutableTreeNode(stringData);	
		} 
		else if (memberInfo.member_kind == TCKind.TK_LONG ||memberInfo.member_kind == TCKind.TK_ULONG)
		{
			long longData = data.get_long(memberInfo.member_name, memberInfo.member_id);

			child = new DefaultMutableTreeNode(longData);
		} 
		else if (memberInfo.member_kind == TCKind.TK_FLOAT) 
		{
			float floatData = data.get_float(memberInfo.member_name, memberInfo.member_id);
			//System.out.println("Flaot: " + floatData);
			child = new DefaultMutableTreeNode(floatData);
		} 
		else if (memberInfo.member_kind == TCKind.TK_SHORT ) 
		{
			short shortData = data.get_short(memberInfo.member_name, memberInfo.member_id);
			//System.out.println("short: " + shortData);
			child = new DefaultMutableTreeNode(shortData);
		} 
		else if ( memberInfo.member_kind == TCKind.TK_USHORT) 
		{
			int nData = data.get_short(memberInfo.member_name, memberInfo.member_id) & 0xffff;
			
			child = new DefaultMutableTreeNode(nData);			
		} 
		else if (memberInfo.member_kind == TCKind.TK_SEQUENCE) 
		{
			ByteSeq seq = new ByteSeq();
			data.get_byte_seq(seq, memberInfo.member_name, memberInfo.member_id);
			//System.out.println("Byte Sequence: " + seq);
			child = new DefaultMutableTreeNode(seq);
		}
		else if (memberInfo.member_kind == TCKind.TK_ARRAY) 
		{
			if(memberInfo.element_kind == TCKind.TK_CHAR)
			{
				char chData[] = new char[memberInfo.element_count] ;
				data.get_char_array(chData , memberInfo.member_name, memberInfo.member_id);

				String strData = new String(chData, 0 , chData.length);
				child = new DefaultMutableTreeNode(strData);	
	
			}
			else if(memberInfo.element_kind == TCKind.TK_LONG)
			{
				int[] iData = new int[memberInfo.element_count] ;
				data.get_int_array(iData , memberInfo.member_name, memberInfo.member_id);

				for (int iArrayChildCount=0 ; iArrayChildCount <memberInfo.element_count; iArrayChildCount++)
				{
					child = new DefaultMutableTreeNode(iData[iArrayChildCount]);	
					if( child != null )
						childroot.add(child);
				}	
			}
			else if (memberInfo.element_kind == TCKind.TK_OCTET) 
			{
				byte[] byData = new byte[memberInfo.element_count] ; ;
				data.get_byte_array( byData, memberInfo.member_name, memberInfo.member_id);

				for (int iArrayChildCount=0 ; iArrayChildCount <memberInfo.element_count; iArrayChildCount++)
				{
					child = new DefaultMutableTreeNode(byData[iArrayChildCount]);	
					if( child != null )
						childroot.add(child);
				}
			}
			else if (memberInfo.element_kind == TCKind.TK_SHORT) 
			{
				short[] sData = new short[memberInfo.element_count] ; ;
				data.get_short_array( sData, memberInfo.member_name, memberInfo.member_id);

				for (int iArrayChildCount=0 ; iArrayChildCount <memberInfo.element_count; iArrayChildCount++)
				{
					child = new DefaultMutableTreeNode(sData[iArrayChildCount]);	
					if( child != null )
						childroot.add(child);
				}
			}
			else if (memberInfo.element_kind == TCKind.TK_FLOAT) 
			{
				float[] fData = new float[memberInfo.element_count] ; ;
				data.get_float_array( fData, memberInfo.member_name, memberInfo.member_id);

				for (int iArrayChildCount=0 ; iArrayChildCount <memberInfo.element_count; iArrayChildCount++)
				{
					child = new DefaultMutableTreeNode(fData[iArrayChildCount]);	
					if( child != null )
						childroot.add(child);
				}
			}
			else if (memberInfo.element_kind == TCKind.TK_DOUBLE) 
			{
				double[] dblData = new double[memberInfo.element_count] ; ;
				data.get_double_array( dblData, memberInfo.member_name, memberInfo.member_id);

				for (int iArrayChildCount=0 ; iArrayChildCount <memberInfo.element_count; iArrayChildCount++)
				{
					child = new DefaultMutableTreeNode(dblData[iArrayChildCount]);	
					if( child != null )
						childroot.add(child);
				}
			}
			else if( memberInfo.element_kind == TCKind.TK_STRUCT)
			{
				TypeCode tcStruct = data.get_member_type(memberInfo.member_name ,DynamicData.MEMBER_ID_UNSPECIFIED);
				
				TypeCode seqElementTC = null;
				try {
					seqElementTC = tcStruct.content_type();
				} catch (BadKind e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				int count = 0;
				
				try {
					count = tcStruct.element_count();
				} catch (BadKind e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//Sequence
	        	DynamicData seqMember = new DynamicData(tcStruct, DynamicData.PROPERTY_DEFAULT);
	        	
	        	data.get_complex_member(seqMember, memberInfo.member_name ,DynamicData.MEMBER_ID_UNSPECIFIED);
	        	
	        	//����ü �ϳ�
				DynamicData seqElement = new DynamicData(null, DynamicData.PROPERTY_DEFAULT);
	        	
	        	DefaultMutableTreeNode child2=null;
	        	
	        	for( int i=0 ; i<count ; i++)
				{
					seqMember.get_complex_member(seqElement, null, i + 1);
					
					child = new DefaultMutableTreeNode(memberInfo.member_name +'['+ i +']');
					
					
					for (int jj = 0; jj < seqElement.get_member_count(); jj++) 
					{
						DynamicDataMemberInfo memberInfo2 = new DynamicDataMemberInfo();
						seqElement.get_member_info_by_index(memberInfo2, jj);
						
						child2 = MakeNode(seqElement, memberInfo2);
						
						if( child2 != null )
							child.add(child2);
					}
					
					childroot.add(child);
				}
	        	child = null;

			}
			else
			{
				System.out.println("memberInfo.member_kind : " + memberInfo.member_kind.toString()+" memberInfo.element_kind : " + memberInfo.element_kind.toString());
			}
				
		}
		else if( memberInfo.member_kind == TCKind.TK_STRUCT)
		{
					
			DynamicData dataSub = new DynamicData( );
			
			data.get_complex_member(dataSub, memberInfo.member_name ,DynamicData.MEMBER_ID_UNSPECIFIED);
			
			for (int jj = 0; jj < dataSub.get_member_count(); jj++) 
			{
				DynamicDataMemberInfo memberInfo2 = new DynamicDataMemberInfo();
				dataSub.get_member_info_by_index(memberInfo2, jj);
				
				child = MakeNode(dataSub, memberInfo2);
				
				if( child != null )
					childroot.add(child);
							
			}

		}
		else if (memberInfo.member_kind == TCKind.TK_OCTET) 
		{
			byte byData ;
			byData = data.get_byte( memberInfo.member_name, memberInfo.member_id);

			child = new DefaultMutableTreeNode(byData);	
		}
		else if (memberInfo.member_kind == TCKind.TK_DOUBLE) 
		{
			double dbData ;
			dbData = data.get_double( memberInfo.member_name, memberInfo.member_id);

			child = new DefaultMutableTreeNode(dbData);	
		}
		else if (memberInfo.member_kind == TCKind.TK_BOOLEAN) 
		{
			boolean bData ;
			bData = data.get_boolean( memberInfo.member_name, memberInfo.member_id);

			child = new DefaultMutableTreeNode(bData);	
		}
		else if (memberInfo.member_kind == TCKind.TK_CHAR) 
		{
			char cData ;
			cData = data.get_char( memberInfo.member_name, memberInfo.member_id);

			child = new DefaultMutableTreeNode(cData);	
		}
		else
		{
			System.out.println("memberInfo.member_kind : " + memberInfo.member_kind.toString());
		}
		
		if( child != null)
			childroot.add(child);
		
		return childroot;
	}
}
