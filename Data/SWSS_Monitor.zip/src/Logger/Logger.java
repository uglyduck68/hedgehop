package Logger;

import java.util.concurrent.ConcurrentSkipListMap;

import com.rti.dds.domain.*;
import com.rti.dds.dynamicdata.DynamicDataTypeSupport;
import com.rti.dds.infrastructure.*;
import com.rti.dds.publication.builtin.*;
import com.rti.dds.subscription.*;
import com.rti.dds.subscription.builtin.SubscriptionBuiltinTopicData;
import com.rti.dds.subscription.builtin.SubscriptionBuiltinTopicDataDataReader;
import com.rti.dds.topic.Topic;
import com.rti.dds.topic.TopicQos;
import com.rti.dds.typecode.TypeCode;
import com.sun.xml.internal.bind.marshaller.DataWriter;

public class Logger {
	int domainId = 1;
	public DomainParticipant participant;
	private PublicationBuiltinTopicDataDataReader   publicationsDR;
	private SubscriptionBuiltinTopicDataDataReader  subscriptionDR;
	private ConcurrentSkipListMap<String, TypeCode> discoveredTypes;
	DDSMonitorUI  m_monitorGui ;

	public static final void main(String args[]) throws InterruptedException {
		
	/*	System.out.println("Logger");
        System.out.println("Loading nddscore");
        System.loadLibrary("nddscore");
        System.out.println("Loading nddsc");
        System.loadLibrary("nddsc");
        System.out.println("Loading nddsjava");
        System.loadLibrary("nddsjava");
        
		Logger logger = new Logger();
		if ( !logger.start(1) ) {
			return;
		}
		Logger logger2 = new Logger();
		if ( !logger2.start(7) ) {
			return;
		}
		*/
	}
	
	public boolean start(int i_domainID) {
		domainId = i_domainID;
		discoveredTypes = new ConcurrentSkipListMap<String, TypeCode>();

		DomainParticipantFactory factory = DomainParticipantFactory.get_instance();
		DomainParticipantFactoryQos factoryQos = new DomainParticipantFactoryQos();
		factory.get_qos(factoryQos);
		factoryQos.entity_factory.autoenable_created_entities = false;
		factory.set_qos(factoryQos);
		
		DomainParticipantQos pQos = new DomainParticipantQos();
		//factory.get_default_participant_qos(pQos);
		factory.get_participant_qos_from_profile(pQos, "DefaultLibrary", "Reliable");
		
		pQos.participant_name.name = "RTI Connext Logger";
	    participant = factory.create_participant( domainId, pQos, null, StatusKind.STATUS_MASK_NONE);
		publicationsDR = (PublicationBuiltinTopicDataDataReader) 
	    participant.get_builtin_subscriber().lookup_datareader("DCPSPublication");
		
		subscriptionDR = (SubscriptionBuiltinTopicDataDataReader) 
		participant.get_builtin_subscriber().lookup_datareader("DCPSSubscription");
		
	    participant.enable(); 
		publicationsDR.set_listener(new TopicListenerPub(this), StatusKind.STATUS_MASK_ALL);
		publicationsDR.get_statuscondition().set_enabled_statuses(StatusKind.DATA_AVAILABLE_STATUS);
		
		//subscriptionDR.set_listener(new TopicListenerSub(this), StatusKind.STATUS_MASK_ALL);
		//subscriptionDR.get_statuscondition().set_enabled_statuses(StatusKind.DATA_AVAILABLE_STATUS);

		return true;
	}


	public void processDiscoveredTopic(PublicationBuiltinTopicData topicData) {
		TypeCode existingType = null;
		DynamicDataTypeSupport typeSupport = null;

		//System.out.println("Discovered topic: \"" + topic_name + "\"  with type: \"" + type_name + "\"");
		if ( topicData.type_code == null ) {
			System.out.println("No type information was supplied for type: \"" + topicData.type_name + "\"");    
			return;
		}

		existingType = discoveredTypes.get(topicData.type_name);

		if ( existingType == null ) {
			discoveredTypes.put(topicData.type_name, topicData.type_code);

			// register the discovered type with the Participant
			typeSupport = new DynamicDataTypeSupport(topicData.type_code, DynamicDataTypeSupport.TYPE_PROPERTY_DEFAULT);
			typeSupport.register_type(participant, topicData.type_name);
		} 
		else {
			//System.out.println(topic_name+" This type had been seen already. Comparing the type definitions...");
			if ( existingType.equals(topicData.type_code) ) {
				//System.out.println(topic_name+" The type matches the existing definition");
			}
			else {
				System.out.println(topicData.topic_name+" The type DOES NOT match the existing definition");

				System.out.println("This is the existing definition:");
				existingType.print_IDL(0);  

				System.out.println("This is the definition of the type just discovered:");
				topicData.type_code.print_IDL(0);                
			}
		}

		// Check if we had already a topic created with that name
		if ( this.participant.lookup_topicdescription(topicData.topic_name) == null ) {
			//System.out.println("This topic \"" + topic_name + "\" had not seen before. Creating it.");
			
			//TopicQos topicQOS = DomainParticipant.TOPIC_QOS_DEFAULT;
			//DataReaderQos drQOS = Subscriber.DATAREADER_QOS_DEFAULT;
			//topicQOS.ownership.copy_from(topicData.ownership);
			
			Topic topic = participant.create_topic(
					topicData.topic_name, 
					topicData.type_name, 
					DomainParticipant.TOPIC_QOS_DEFAULT, 
					null, // listener
					StatusKind.STATUS_MASK_NONE);
			if (topic == null) {
				System.err.println("Unable to create topic.");
				return;
			}
			// Create the data reader using the default publisher
			//drQOS.ownership.copy_from(topicData.ownership);
			DataReader dataReader =
					(DataReader) participant.create_datareader_with_profile(
							topic,
							"DefaultLibrary", "Reliable",
							new DynamicListener(this),         // Listener
							StatusKind.STATUS_MASK_ALL);
			//dataReader.get_subscriber().copy_from_topic_qos(drQOS, topicQOS);
			//dataReader.enable();
			//dataReader.get_statuscondition().set_enabled_statuses(StatusKind.DATA_AVAILABLE_STATUS);
			
			System.out.println(topicData.topic_name + " craeted topic (Pub)");
		}
	}
	
	public void processDiscoveredTopic(SubscriptionBuiltinTopicData topicData) {
		TypeCode existingType = null;
		DynamicDataTypeSupport typeSupport = null;

		//System.out.println("Discovered topic: \"" + topic_name + "\"  with type: \"" + type_name + "\"");
		if ( topicData.type_code == null ) {
			System.out.println("No type information was supplied for type: \"" + topicData.type_name + "\"");    
			return;
		}

		existingType = discoveredTypes.get(topicData.type_name);

		if ( existingType == null ) {
			discoveredTypes.put(topicData.type_name, topicData.type_code);

			// register the discovered type with the Participant
			typeSupport = new DynamicDataTypeSupport(topicData.type_code, DynamicDataTypeSupport.TYPE_PROPERTY_DEFAULT);
			typeSupport.register_type(participant, topicData.type_name);
		} 
		else {
			//System.out.println(topic_name+" This type had been seen already. Comparing the type definitions...");
			if ( existingType.equals(topicData.type_code) ) {
				//System.out.println(topic_name+" The type matches the existing definition");
			}
			else {
				System.out.println(topicData.topic_name+" The type DOES NOT match the existing definition");

				System.out.println("This is the existing definition:");
				existingType.print_IDL(0);  

				System.out.println("This is the definition of the type just discovered:");
				topicData.type_code.print_IDL(0);                
			}
		}

		// Check if we had already a topic created with that name
		if ( this.participant.lookup_topicdescription(topicData.topic_name) == null ) {
			//System.out.println("This topic \"" + topic_name + "\" had not seen before. Creating it.");
			
			//TopicQos topicQOS = DomainParticipant.TOPIC_QOS_DEFAULT;
			//DataReaderQos drQOS = Subscriber.DATAREADER_QOS_DEFAULT;
			//topicQOS.ownership.copy_from(topicData.ownership);
			
			Topic topic = participant.create_topic(
					topicData.topic_name, 
					topicData.type_name, 
					DomainParticipant.TOPIC_QOS_DEFAULT, 
					null, // listener
					StatusKind.STATUS_MASK_NONE);
			if (topic == null) {
				System.err.println("Unable to create topic.");
				return;
			}
			// Create the data reader using the default publisher
			//drQOS.ownership.copy_from(topicData.ownership);
			DataWriter dataWriter =
					(DataWriter) participant.create_datawriter_with_profile(
							topic,
							"DefaultLibrary", "Reliable",
							null,         // Listener
							StatusKind.STATUS_MASK_ALL);
			//dataReader.get_subscriber().copy_from_topic_qos(drQOS, topicQOS);
			//dataReader.enable();
			//dataReader.get_statuscondition().set_enabled_statuses(StatusKind.DATA_AVAILABLE_STATUS);
			
			System.out.println(topicData.topic_name + " craeted topic (Sub)");
		}
	}
}