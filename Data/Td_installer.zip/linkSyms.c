/* linkSyms.c - dynamically generated configuration file */


/*
GENERATED: Tue Sep 23 18:56:51 +1000 2014
DO NOT EDIT - file is regenerated whenever the project changes
*/

typedef int (*FUNC) ();

FUNC linkSyms [] = {
    0
};


int * linkDataSyms [] = {
    0
};

