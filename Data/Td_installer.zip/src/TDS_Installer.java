import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;


public class TDS_Installer extends JFrame {
	
//	JButton SBT1_1, SBT1_2, SBT2_1, SBT2_2;
	static JButton b1_Serial1	=	new JButton("�ø��󿬵�ī��1");
	static JButton b2_Serial2	=	new JButton("�ø��󿬵�ī��2");
	static JButton b3_Ethernet1 =	new JButton("�̴��ݿ���ī��1");
	static JButton b4_Ethernet2 =	new JButton("�̴��ݿ���ī��2");
	static JButton b5_SBT		=	new JButton("�����Ʒ�ī��");
	
	static JButton b6_Info1_1 = new JButton("����ó����ġ1-1");
	static JButton b7_Info1_2 = new JButton("����ó����ġ1-2");
	static JButton b8_Info2_1 = new JButton("����ó�����2-1");
	static JButton b9_Info2_2 = new JButton("�庸ó����ġ2-2");
	static JTextArea textarea = new JTextArea(10, 10);
	
    static JScrollPane scroll = new JScrollPane(textarea);	
    
    static HashMap<JButton, String> NameMap = new HashMap<JButton, String>();
    static boolean btnEnable = true;

    Container	contentPane;
	
	TDS_Installer() {
		
		JPanel 	SBT1panel	= new JPanel(new FlowLayout(FlowLayout.LEFT,30,15));
		JPanel	Subpanel	= new JPanel();
		
	    scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

	    //Add Textarea in to middle panel
    
		setBounds(100,200,500,570);
		
		setLayout(new BorderLayout(10,10));
		setResizable(false);
		setTitle("TDS Install Program");

		JLabel jlabel = new JLabel("TDS Install(for Vxworks board)", SwingConstants.CENTER);
		jlabel.setFont(new Font("Verdana", 1, 20));
		
		Subpanel.add(jlabel);

		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("jpg/LIG.jpg");
		setIconImage(img);

		Btn_Conf(b1_Serial1, "Serial1",SBT1panel);
		Btn_Conf(b2_Serial2, "Serial2",SBT1panel);		
		Btn_Conf(b3_Ethernet1, "Ethernet1",SBT1panel);		
		Btn_Conf(b4_Ethernet2, "Ethernet2",SBT1panel);
		Btn_Conf(b5_SBT, "SBT",SBT1panel);
		Btn_Conf(b6_Info1_1, "Info1_1", SBT1panel);
		Btn_Conf(b7_Info1_2, "Info1_2",SBT1panel);
		Btn_Conf(b8_Info2_1, "Info2_1",SBT1panel);
		Btn_Conf(b9_Info2_2, "Info2_2",SBT1panel);
		//EnableBtn(true);
		
		add(Subpanel,BorderLayout.NORTH);
		
		textarea.setBorder(new EtchedBorder(EtchedBorder.RAISED) );
		textarea.setEditable(false);
		//textarea.setPreferredSize(new Dimension(450, 200));
		add(SBT1panel,BorderLayout.CENTER);
		add(scroll,BorderLayout.SOUTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void Btn_Conf(JButton btn, String strName,JPanel panel){
	
		btn.addActionListener(new MyButtonListener());
		btn.setPreferredSize(new Dimension(200,40));
		panel.add(btn);
		NameMap.put(btn, strName);
		Thread t1 = new Ping_check(btn);
		t1.start();	
		btn.setEnabled(false);
	}
	
	public static void EnableBtn(Boolean flag){
		btnEnable = flag;
		b1_Serial1.setEnabled(flag);
		b2_Serial2.setEnabled(flag);
		b3_Ethernet1.setEnabled(flag);
		b4_Ethernet2.setEnabled(flag);
		b5_SBT.setEnabled(flag);
		b6_Info1_1.setEnabled(flag);
		b7_Info1_2.setEnabled(flag);
		b8_Info2_1.setEnabled(flag);
		b9_Info2_2.setEnabled(flag);
		
	}
	
	class MyButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			EnableBtn(false);
			JButton btn = (JButton)e.getSource();
			Thread t1 = new Telnet(btn);
			t1.start();
		}
	}

	public static void append(String str){
		textarea.append(str);
		scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getMaximum());
		
	}
	public TDS_Installer getInstance(){
		return this;
	}
	public static void main(String[] args) {
		try {
			Process process = new ProcessBuilder("C:/WindRiver/vxworks-6.8/host/x86-win32/bin/wftpd32.exe").start();
			Thread.sleep(1000);
		} catch(Exception e){

		} finally {
			new TDS_Installer();
		}
	}
}
