import java.io.FileInputStream;
import java.net.InetAddress;
import java.util.Properties;

import javax.swing.JButton;


public class Ping_check extends Thread {

	InetAddress TargetIp;
	String		Host;
	JButton		Btn;
	public Ping_check(JButton btn){
		
		try{
			// Read properties file.
			Properties properties = new Properties();
			String conf = TDS_Installer.NameMap.get(btn);
			properties.load(new FileInputStream("conf/"+conf+".properties"));

			Host = properties.getProperty("IP");			
			TargetIp = InetAddress.getByName(Host);
			Btn		= btn;
			//boolean reachable = targetIp.isReachable(1000);
		} catch(Exception e){

		}
		
	}
	
	public void run() {
		try{
			do{
				boolean reachable = TargetIp.isReachable(2000);
				if(TDS_Installer.btnEnable)
					Btn.setEnabled(reachable);
				Thread.sleep(100);
			} while(true);
		}catch(Exception e){
		
		}
	}

}
