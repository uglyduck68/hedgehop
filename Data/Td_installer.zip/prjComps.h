/* prjComps.h - dynamically generated configuration header */


/*
GENERATED: Tue Sep 23 18:56:51 +1000 2014
DO NOT EDIT - file is regenerated whenever the project changes
*/

#ifndef INCprjCompsh
#define INCprjCompsh
#define _WRS_LAYER 4

/*** INCLUDED COMPONENTS ***/

#define INCLUDE_USER_APPL

#endif /* INCprjCompsh */
