//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by birdwatcher.rc
//
#define IDD_BIRDWATCHER_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDI_CONDOR_FLYING1              129
#define IDI_CONDOR_CLAIMED              130
#define IDI_CONDOR_IDLE                 131
#define IDI_CONDOR_OFF                  132
#define IDI_CONDOR_FLYING2              133
#define IDI_PREEMPTING                  134
#define IDC_EDIT_TOP_PANE               1000
#define IDC_EDIT_BOTTOM_PANE            1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
