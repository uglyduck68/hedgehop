#define GLOBAL
#include "p4.h"
#include "p4_sys.h"
