
#include <math.h>
#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <sys/types.h>
#include <time.h>

main(int argc, char **argv)
{
  double a = 360.0;
  int i;
  double u, distValue;

  if (argc >= 2)
   a = atof(argv[1]);

  srand48(time(0));
  for (i = 0; i < 10000; i++) {
    u = drand48();
    distValue = -a * log(u);
    if ((distValue < 40) || (distValue > 2 * a))
      continue;
    cout << (int) distValue << endl;
  }
  cout << endl;
}
