#!/usr/local/bin/perl
#require "sys/wait.ph";

@machineNames = ('magha', 'phalgun', 'ardra', 'mriga','mula');
#@machineNames = ('magha', 'phalgun', 'ardra', 'mriga');


$numMachines = @machineNames;
print "# of machines: $numMachines \n";

chop($currentDir = `pwd`);

for ($i = 0; $i < $numMachines; $i++) { 
    #run on machine i
    print "rsh @machineNames[$i] $currentDir/remove-hung-procs \n";
		
    system("rsh @machineNames[$i] sh $currentDir/remove-hung-procs");
    system("rsh @machineNames[$i] '\\rm -f /tmp/listenerInfo /export/suburbia/sriram/procTable'");
}
