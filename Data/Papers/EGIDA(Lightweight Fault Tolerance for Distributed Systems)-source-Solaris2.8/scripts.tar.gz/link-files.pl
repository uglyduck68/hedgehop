#!/usr/local/bin/perl
#require "sys/wait.ph";

@machineNames = ('magha', 'phalgun', 'ardra', 'mriga','mula');
#@machineNames = ('magha', 'phalgun', 'ardra', 'mriga');

$numMachines = @machineNames;
print "# of machines: $numMachines \n";

chop($currentDir = `pwd`);

for ($i = 0; $i < $numMachines; $i++) { 
    #run on machine i
		
#  system("rsh @machineNames[$i] sh $currentDir/synth-link-script");
#  system("rsh @machineNames[$i] sh $currentDir/link-script");
   system("rsh @machineNames[$i] sh $currentDir/results-link-script");
}
