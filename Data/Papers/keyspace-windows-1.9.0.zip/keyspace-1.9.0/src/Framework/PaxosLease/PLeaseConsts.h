#ifndef PLEASECONSTS_H
#define PLEASECONSTS_H

#include "System/Common.h"

#define ACQUIRELEASE_TIMEOUT	2000	// msec
#define MAX_LEASE_TIME			7000	// msec
#define PLEASE_PORT_OFFSET		1

#endif
