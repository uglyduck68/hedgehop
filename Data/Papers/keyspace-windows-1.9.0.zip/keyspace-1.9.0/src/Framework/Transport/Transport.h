#ifndef TRANSPORT_H
#define TRANSPORT_H

#include "System/Common.h"

#define MAX_TCP_MESSAGE_SIZE (1*MB + 10*KB)

#define MAX_UDP_MESSAGE_SIZE (64*KB + 1*KB)

#endif
