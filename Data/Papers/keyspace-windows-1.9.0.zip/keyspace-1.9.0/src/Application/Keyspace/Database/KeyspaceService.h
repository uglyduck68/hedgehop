#ifndef KEYSPACESERVICE_H
#define KEYSPACESERVICE_H

#include "System/Buffer.h"
#include "KeyspaceDB.h"

class KeyspaceOp;

class KeyspaceService
{
public:
	virtual			~KeyspaceService() {}
	virtual	void	OnComplete(KeyspaceOp* op, bool final = true) = 0;
	virtual bool	IsAborted() = 0;

	void Init(KeyspaceDB* kdb_)
	{
		kdb = kdb_;
		numpending = 0;
	}


	bool Add(KeyspaceOp *op)
	{
		bool ret;
		
		ret = kdb->Add(op);
		if (ret)
			numpending++;
		return ret;
	}

protected:
	int				numpending;
	KeyspaceDB*		kdb;
};


class KeyspaceOp
{
public:
	enum Type
	{
		GET,
		DIRTY_GET,
		LIST,
		DIRTY_LIST,
		LISTP,
		DIRTY_LISTP,
		COUNT,
		DIRTY_COUNT,
		SET,
		TEST_AND_SET,
		ADD,
		RENAME,
		DELETE,
		REMOVE,
		PRUNE,
		SET_EXPIRY,
		EXPIRE,
		REMOVE_EXPIRY,
		CLEAR_EXPIRIES
	};
	
	bool					appended;
	
	Type					type;
	uint64_t				cmdID;
	ByteBuffer				key;
	ByteBuffer				newKey; // for rename
	ByteBuffer				value;
	ByteBuffer				test;
	ByteBuffer				prefix;
	int64_t					num;
	uint64_t				count;
	uint64_t				offset;
	uint64_t				prevExpiryTime;
	uint64_t				nextExpiryTime;
	bool					forward;
	bool					status;
	
	KeyspaceService*		service;
	
	KeyspaceOp()
	{
		appended = false;
		status = false;
        num = 0;
        count = 0;
        offset = 0;
        prevExpiryTime = 0;
        nextExpiryTime = 0;
	}
	
	~KeyspaceOp()
	{
		Free();
	}
	
	void Free()
	{
		key.Free();
		newKey.Free();
		value.Free();
		test.Free();
		prefix.Free();
	}
	
	bool IsAborted()
	{
		return service->IsAborted();
	}
	
	bool IsWrite()
	{
		return (type == KeyspaceOp::SET ||
				type == KeyspaceOp::TEST_AND_SET ||
				type == KeyspaceOp::DELETE ||
				type == KeyspaceOp::REMOVE ||
				type == KeyspaceOp::ADD ||
				type == KeyspaceOp::RENAME ||
				type == KeyspaceOp::PRUNE ||
				IsExpiry());
	}

	bool IsRead()
	{
		return !IsWrite();
	}
	
	bool IsGet()
	{
		return (type == GET || type == DIRTY_GET);
	}
	
	bool IsListKeys()
	{
		return (type == LIST || type == DIRTY_LIST);
	}

	bool IsListKeyValues()
	{
		return (type == LISTP || type == DIRTY_LISTP);
	}
	
	bool IsList()
	{
		return (type == LIST ||
				type == DIRTY_LIST ||
				type == LISTP ||
				type == DIRTY_LISTP);
	}

	bool IsCount()
	{
		return (type == COUNT || type == DIRTY_COUNT);
	}
	
	bool IsDirty()
	{
		return (type == DIRTY_GET ||
				type == DIRTY_LIST ||
				type == DIRTY_LISTP ||
				type == DIRTY_COUNT
				);
	}
	
	bool IsExpiry()
	{
		return (type == KeyspaceOp::SET_EXPIRY ||
			    type == KeyspaceOp::EXPIRE ||
			    type == KeyspaceOp::REMOVE_EXPIRY ||
				type == KeyspaceOp::CLEAR_EXPIRIES);
	}
	
	bool MasterOnly()
	{
		return (type == GET ||
				type == LIST ||
				type == LISTP ||
				type == COUNT ||
				IsWrite());
	}
};

#endif
