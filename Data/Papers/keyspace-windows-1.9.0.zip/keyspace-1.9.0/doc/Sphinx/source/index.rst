.. Keyspace documentation master file, created by
   sphinx-quickstart on Wed Mar 10 16:38:55 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Keyspace documentation
======================

Contents:

.. toctree::
   :maxdepth: 2
   :numbered:

   about.rst
   installation.rst
   configuration.rst
   running.rst
   understanding.rst
   http_api.rst
   python_api.rst
   java_api.rst
   csharp_api.rst
   c_api.rst
   php_api.rst
   ruby_api.rst
   perl_api.rst

.. Indices and tables
   ==================

  * :ref:`genindex`
  * :ref:`modindex`
  * :ref:`search`

