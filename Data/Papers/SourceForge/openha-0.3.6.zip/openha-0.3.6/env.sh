#!/bin/sh
EZ_BIN=$EZ/bin
export EZ_BIN
EZ_SERVICES=$EZ/conf/services
export EZ_SERVICES
EZ_NODES=$EZ/conf/nodes
export EZ_NODES
EZ_MONITOR=$EZ/conf/monitor
export EZ_MONITOR
EZ_LOG=$EZ/log
export EZ_LOG
