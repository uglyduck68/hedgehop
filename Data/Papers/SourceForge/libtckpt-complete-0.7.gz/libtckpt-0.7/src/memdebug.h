/*
  memdebug.h

  Memory corruption debugging

  History
  -------
  $Log: memdebug.h,v $
  Revision 6.1  2000/05/02 20:09:42  dieter
  Released version 0.6.

  Revision 5.1  2000/02/01 23:38:13  dieter
  Release 0.5 plus some fixes

  Revision 4.1  1999/08/02 15:11:45  dieter
  Moving to version 4.1
  This is essentially the version reported in FTCS-29.

 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:27:46  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.3  1998/12/11  21:44:04  dieter
 * Define MemDebugInit to be an empty macro when MEM_DEBUG is not defined.
 *
 * Revision 1.2  1998/09/15  14:39:17  dieter
 * Disable memory debug by default.
 *
 * Revision 1.1  1998/09/15  14:34:24  dieter
 * Initial revision
 *
 * Revision 1.1  1997/11/03  23:10:56  dieter
 * Initial revision
 *
 */

#ifndef MEM_DEBUG_H
#define MEM_DEBUG_H

#include <sys/types.h>
#include <stdlib.h>

/* #define MEM_DEBUG */		/* comment this out to disable memory debug */
#ifdef MEM_DEBUG

/* replace malloc and free */
#define malloc(size)           DebugMalloc( size, __FILE__, __LINE__ )
#define calloc(nelem, elsize)  DebugCalloc( nelem, elsize, __FILE__, __LINE__ )
#define realloc(ptr, size)     DebugRealloc( ptr, size, __FILE__, __LINE__ )
#define free(ptr)              DebugFree( ptr, __FILE__, __LINE__ )
#define memalign( align, size) DebugMemalign( align, size, __FILE__, __LINE__ )
#define valloc( size )         DebugValloc( size, __FILE__, __LINE__ )

void MemDebugInit( void );

#else

#define MemDebugInit()

#endif

#endif


void *DebugMalloc( size_t size, char *file, int line );
void *DebugCalloc( size_t nelem, size_t elsize, char *file, int line );
void  DebugFree( void *ptr, char *file, int line );
void *DebugMemalign( size_t alignment, size_t size, char *file, int line );
void *DebugRealloc( void *ptr, size_t size, char *file, int line );
void *DebugValloc( size_t size, char *file, int line );

void  DebugMemCheck( void );
