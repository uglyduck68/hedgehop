/*
 * util.h
 *
 * generic utility functions.
 *
 * History
 * -------
 * $Log: util.h,v $
 * Revision 6.1  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 */

#ifndef UTIL_H
#define UTIL_H

char *ultostr(char *str, int len, unsigned long num);

#endif
