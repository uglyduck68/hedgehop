/*
 * sysio.c
 *
 * functions to intercept I/O system calls and update file state information
 * as needed.
 *
 * History
 * -------
 * $Log: sysio.c,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.4  2000/02/01 23:32:22  dieter
 * Do not check return code of fstate_delete_file when closing a file.
 *
 * Revision 4.3  2000/01/20 15:43:07  dieter
 * Initialize on the first call to an intercepted function if the
 * initialization has not been called yet.
 *
 * Revision 4.2  2000/01/19 22:48:44  dieter
 * Added pipe support
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:34:56  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.4  1998/12/11  21:41:07  dieter
 * Cast the return value of dlsym.
 * Include sysio.h.
 *
 * Revision 1.3  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.2  1998/09/01  15:56:54  dieter
 * Added changes to support libc I/O (fopen, fclose).
 *
 * Revision 1.1  1998/08/25  20:18:04  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdarg.h>
#include <dlfcn.h>

#include "memdebug.h"
#include "fstate.h"
#include "sysio.h"

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define SYSIO_INIT() {if(sys_open == NULL) sysio_init();}
/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int (*sys_open)(const char *path, int oflag, /* mode_t mode */ ...) = NULL;
int (*sys_close)(int fildes) = NULL;
int (*sys_dup)(int filedes) = NULL;
int (*sys_dup2)(int filedes, int filedes2) = NULL;
int (*sys_pipe)(int fliedes[2]) = NULL;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int sysio_init(void)
{
  sys_open  = (int (*)(const char *, int, ...))dlsym(RTLD_NEXT, "open");
  sys_close = (int (*)(int))dlsym(RTLD_NEXT, "close");
  sys_dup   = (int (*)(int))dlsym(RTLD_NEXT, "dup");
  sys_dup2  = (int (*)(int, int))dlsym(RTLD_NEXT, "dup2");
  sys_pipe  = (int (*)(int [2]))dlsym(RTLD_NEXT, "pipe");
  
  if (sys_open == NULL || sys_close == NULL || sys_dup == NULL ||
      sys_dup2 == NULL) {
    return -1;
  }

  return 0; 
}

int open(const char *path, int oflag, /* mode_t mode */ ...)
{
  va_list ap;			/* points to each unnamed arg in turn */
  mode_t mode;
  int filedes;
  int status;

  SYSIO_INIT();
  va_start(ap, oflag);
  mode = va_arg(ap, mode_t);
  filedes = sys_open(path, oflag, mode);
  if (filedes != -1) {
    status = fstate_add_file(path, oflag, mode, filedes);
    if (status == -1) {
      close(filedes);
      filedes = -1;
    }
  }

  va_end(ap);
  return filedes;
}

int close(int filedes)
{
  int status;

  SYSIO_INIT();
  status = sys_close(filedes);
  if (status != -1) {
/*      status = fstate_delete_file(filedes); */
    fstate_delete_file(filedes);
  }
  
  return status;
}

int dup(int filedes)
{
  int new_fd;
  int status;

  SYSIO_INIT();
  new_fd = sys_dup(filedes);
  if (new_fd != -1) {
    status = fstate_add_dup_file(filedes, new_fd);
    if (status == -1)
      close(new_fd);
  }
  
  return new_fd;
}

int dup2(int filedes, int filedes2)
{
  int status;

  SYSIO_INIT();
  fstate_delete_file(filedes2);

  status = sys_dup2(filedes, filedes2);
  if (status != -1) {
    status = fstate_add_dup_file(filedes, filedes2);
    if (status == -1)
      close(filedes2);
  }

  return status;
}

int pipe(int filedes[2])
{
  int status;

  SYSIO_INIT();
  status = sys_pipe(filedes);
  if (status != -1) {
    if ( (status = fstate_add_pipe(filedes)) == -1) {
      close(filedes[0]); 
      close(filedes[1]);
      status = -1;
    }
  }
  return status;
}

/* fcntl is complicated, so don't support it until there is a demand for it. */
#ifdef FCNTL_SUPPORTED
int fcntl(int fildes, int cmd, /* arg */ ...)
{
  return -1;
}
#endif
