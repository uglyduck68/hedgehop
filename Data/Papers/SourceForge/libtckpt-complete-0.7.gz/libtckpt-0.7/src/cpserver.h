#ifndef CPSERVER_H
#define CPSERVER_H

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define CP_SERVER_PORT 6411	/* randomly choose a port and hope noone else
				 * is using it.
				 */
#define MAX_HOSTS  128		/* max number of Unify hosts */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/
 
typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned long  uint32;

typedef enum cpserv_req {
  CP_SERV_WRITE,		/* write a checkpoint */
  CP_SERV_READ,			/* read a checkpoint */
  CP_SERV_STAT,			/* stat a checkpoint */
  CP_SERV_DELETE		/* delete a checkpoint */
} cpserv_req_t;

typedef struct cpserv_msg_hdr {
  uint8 version;		/* protocol version */
  uint8 req;			/* request type */
  uint32 wid;			/* worker id */
} cpserv_msg_t;

typedef struct cpserv_wopen_req {
  uint32 num;			/* checkpoint number */
  uint32 wid;			/* worker id */
  uint32 base_len;		/* file base len (string follows struct */
} cpserv_wopen_t;

typedef struct cpserv_write_req {
  off_t  file_offset;		/* offset into file */
  size_t size;			/* amount of data */
} cpserv_write_req_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

#endif
