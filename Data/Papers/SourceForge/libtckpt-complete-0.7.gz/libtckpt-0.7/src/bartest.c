/*
  bartest.c

  Test program for barrier.c

  History
  -------
  $Log: bartest.c,v $
  Revision 6.3  2001/06/06 21:11:34  wrdieter
  Added diagnostic output.

  Revision 6.2  2000/10/20 20:44:57  dieter
  Updated for new blocking barrier support.

  Revision 6.1  2000/05/02 20:09:42  dieter
  Released version 0.6.

  Revision 5.1  2000/02/01 23:37:32  dieter
  Release 0.5 plus some fixes

  Revision 1.1  2000/01/19 22:51:20  dieter
  Initial revision

*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

#include "barrier.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS 5	/* number of threads incl. the main thread */
#define DEFAULT_CYCLES      1000000 /* number of times to go around the ring */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int num_threads = DEFAULT_THREADS;
int num_cycles = DEFAULT_CYCLES;
int count = 0;
barrier_t *bar;

pthread_mutex_t barrier_ready_mutex;
pthread_cond_t  barrier_ready_cond;
int		barrier_ready;
int		barrier_tests_done;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);
void *do_count(void *arg);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
    int thr_id;
    pthread_t *ptid;
    pthread_attr_t attr;

    barrier_ready = 0;
    barrier_tests_done = 0;
    pthread_mutex_init(&barrier_ready_mutex, NULL);
    pthread_cond_init(&barrier_ready_cond, NULL);
    if ( (ptid = (pthread_t *)malloc(sizeof(pthread_t)*num_threads)) == NULL) {
      fprintf(stderr, "could not allocate ptid\n");
      exit(-1);
    }

    handle_args(argc, argv);
    chkpt_barrier_install_sighandler();

    count = 0;
    pthread_attr_init(&attr);
    pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
    for(thr_id = 1 ; thr_id < num_threads ; thr_id++) {
	pthread_create(&ptid[thr_id], &attr, do_count, (void *)thr_id);
	pthread_detach(ptid[thr_id]);
    }
    pthread_attr_destroy(&attr);
    ptid[0] = pthread_self();

    if ( (bar = chkpt_barrier_create(ptid, num_threads)) == NULL) {
	fprintf(stderr, "barrier_create failed for %d threads\n", num_threads);
	exit(-1);
    }

    pthread_mutex_lock(&barrier_ready_mutex);
    barrier_ready = 1;
    pthread_mutex_unlock(&barrier_ready_mutex);
    pthread_cond_broadcast(&barrier_ready_cond);

    do_count((void *) 0);

    return 0;
}

void *do_count(void *arg)
{
    int thr_id;
    int cycle_count;
    int status;

    thr_id = (int)arg;

    printf("thr_id %d in do_count\n", thr_id);
    pthread_mutex_lock(&barrier_ready_mutex);
    while(!barrier_ready) {
      pthread_cond_wait(&barrier_ready_cond, &barrier_ready_mutex);
    }
    pthread_mutex_unlock(&barrier_ready_mutex);

    printf("thr_id %d past cond_wait\n", thr_id);
    for(cycle_count = 0 ; cycle_count < num_cycles ; cycle_count++) {
	chkpt_barrier_wait(bar);
	status = (count % num_threads == thr_id);
	chkpt_barrier_wait(bar);
	if (status) {
	    count++;
	    if (count % 10000 == 0) {
	      printf("count is %d\n", count);
	    }
	}
    }

    chkpt_barrier_wait(bar);
    printf("thr_id %d says count is %d\n", thr_id, count);
    chkpt_barrier_wait(bar);
    if (thr_id == 0) {
	chkpt_barrier_wait(bar);
	printf("thr_id %d: others are waiting set count to 0\n", thr_id);
	count = thr_id;
	chkpt_barrier_wait(bar);
    } else {
	count = thr_id;
	chkpt_barrier_wait(bar);
	chkpt_barrier_wait(bar);
    }
    printf("thr_id %d says count is %d\n", thr_id, count);
    chkpt_barrier_wait(bar);

    pthread_mutex_lock(&barrier_ready_mutex);
    barrier_tests_done++;
    while(barrier_tests_done < num_threads) {
      pthread_cond_wait(&barrier_ready_cond, &barrier_ready_mutex);
    }
    pthread_mutex_unlock(&barrier_ready_mutex);
    pthread_cond_broadcast(&barrier_ready_cond);
    return NULL;
}

void handle_args(int argc, char *argv[])
{
    int errflg = 0;
    int waitflg = 0;
    int num_waits = 0;
    int option;

    while ((option = getopt(argc, argv, "t:c:w:")) != EOF)
	switch (option) {
	case 'c':
	    num_cycles = atoi(optarg);
	    break;
	case 't':
	    num_threads = atoi(optarg);
	    break;
	case 'w':
	    num_waits = atoi(optarg);
	    waitflg++;
	    break;
	case '?':
	    errflg++;
	}
    if(waitflg) {
	num_cycles = (num_waits + num_threads - 1) / num_threads;
    }
    if (errflg) {
	fprintf(stderr, "test program that uses threads and synchronization\n");
	fprintf(stderr, "usage: %s [ -t threads ] [ -c num_cycles ]\n", argv[0]);
	exit (2);
    }

}
