/*
 * exclude.c
 *
 * This file contains memory exculsion functions.  exclude_region can be
 * called with any address or lenght, but memory is excluded or included
 * on a per page basis.  If any part of a page is mapped and not excluded
 * the entire page is saved in the checkpoint and will be restored later.
 * If an entire page is mapped, but excluded, it will neither be saved in
 * the checkpoint nor restored after the checkpoint.
 *
 * The user program can use this feature to create regions of memory that
 * will survive restoration from a checkpoint.
 *
 * History
 * -------
 * $Log: exclude.c,v $
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.3  2000/01/19 22:43:12  dieter
 * Make parameters to chkpt_include_region and chkpt_exclude_region
 * be const.
 *
 * Revision 4.2  1999/09/02 21:41:58  dieter
 * Fixed bugs in chkpt_intersect_map
 *
 * Revision 4.1  1999/08/02 15:27:02  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.2  1999/07/06  20:18:54  dieter
 * Do not create 0 length mappings.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.4  1999/01/13  21:44:50  dieter
 * Fixed bugs in chkpt_intersect_map.
 *
 * Revision 2.3  1999/01/13  20:17:38  dieter
 * Align intersection addresses and lengths to page boundaries.
 *
 * Revision 2.2  1999/01/13  19:23:10  dieter
 * First pass at intersecting the exclude list with mappings.  Still need
 * to make sure mappings are on page boundaries after intersection.
 *
 * Revision 2.1  1999/01/11  21:12:49  dieter
 * first pass at memory exclusion.
 *
 */

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "debug.h"
#include "machif.h"
#include "exclude.h"
#include "checkpoint.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/* node in the list of memory regions to be excluded from a checkpoint */
typedef struct chkpt_exclude_node {
  char *start;			/* starting address of memory region	     */
  size_t len;			/* length of memory region		     */
  chkpt_exclude_opt_t        options;
  struct chkpt_exclude_node *next;
  struct chkpt_exclude_node *prev;
} chkpt_exclude_node_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

chkpt_exclude_node_t *chkpt_exclude_head;
chkpt_exclude_node_t *chkpt_exclude_tail;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static chkpt_exclude_node_t *new_region(char *start, size_t len,
					chkpt_exclude_opt_t options);
static int add_region_before(chkpt_exclude_node_t *next,
			     char *addr, size_t len,
			     chkpt_exclude_opt_t options);
static int new_tail_region(char *start, size_t len,
			   chkpt_exclude_opt_t options);
static void delete_region(chkpt_exclude_node_t *region);
static chkpt_exclude_node_t *find_region(char *addr,
					 chkpt_exclude_node_t *start);

void chkpt_print_exclude_list(void);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

/* TODO: chkpt_exclude_region is not atomic.  If a malloc fails part of the
 * requested region may be excluded, but not all of it.  I hope this is not
 * a problem, but making chkpt_exclude_region atomic would be difficult.
 * The user can always call chkpt_include_region to make sure the entire
 * region is included.
 */
int chkpt_exclude_region(const void *addr, size_t len,
			 chkpt_exclude_opt_t options)
{
  char *start;			/* an alias to addr */
  chkpt_exclude_node_t *first;
  chkpt_exclude_node_t *next_region;
  chkpt_exclude_node_t *region;
  int status;

#ifdef CHKPT_EXCLUDE_DEBUG
  /* You said you don't car what happens to your memory so I'm going to
   * fill it with trash unless you asked for NOREMAP.  It is ok to stash
   * stuff in NOREMAP memory.
   */
  if (!(options & CHKPT_EXCL_NOREMAP)) {
    fill_with_trash(addr, len);
  }
#endif

  start = (char *)addr;
  
  status = 0;
  first = find_region(start, NULL);
  if(first == NULL) {
    status = new_tail_region(start, len, options);
  } else if(start + len < first->start) {
    status = add_region_before(first, start, len, options);
  } else {
    if(start < first->start) {
      if (options == first->options) {
	first->len += first->start - start;
	first->start = start;
      }
    } else if (start > first->start) {
      if (options != first->options) {
	status = add_region_before(first, first->start, start - first->start,
				   first->options);
	if (status < 0) {
	  return status;
	}
	first->len = first->start + first->len - start;
	first->start = start;
      }
    }

    if(start + len > first->start + first->len) {
      if (options != first->options) {
	first->start = start;
	first->len = len;
	first->options = options;
      } else {
	first->len = start + len - first->start;
      }
      region = first->next;
      while(region != NULL && region->start + region->len <= start + len) {
	next_region = region->next;
	delete_region(region);
	region = next_region;
      }
      if(region == NULL) {
	first->next = NULL;
	chkpt_exclude_tail = first;
      } else if(start + len < region->start) {
	first->next = region;
	region->prev = first;
      } else {
	if (options == first->options) {
	  first->len = region->start + region->len - first->start;
	  first->next = region->next;
	  if(region->next == NULL)
	    chkpt_exclude_tail = first;
	  else
	    region->next->prev = first;
	  delete_region(region);
	} else {
	  region->len = region->start + region->len - (start + len);
	  region->start = start + len;
	}
      }
    } else if(options != first->options) {
      if (start + len < first->start + first->len) {
	if ( (status = add_region_before(first, start, len, options)) < 0) {
	  return status;
	}
	first->len = first->start + first->len - (start + len);
	first->start = start + len;
      } else {
	first->start = start;
	first->len = len;
	first->options = options;
      }
    }
  }

  return status;
}

int chkpt_include_region(const void *addr, size_t len)
{
  char *start;
  chkpt_exclude_node_t *first;
  chkpt_exclude_node_t *region;
  chkpt_exclude_node_t *next_region;
  int status;

  start = (char *)addr;
  status = 0;

  first = find_region(start, NULL);
  if(first != NULL && start + len > first->start) {
    /* included region overlaps with some previously excluded region */
    if(start + len < first->start + first->len) {
      /* included region does not extend past end of first */
      if(start > first->start) {
	status = add_region_before(first, first->start, start - first->start,
				   first->options);
      }
      first->len = first->start + first->len - (start + len);
      first->start = start + len;
    } else {
      /* included region extend past end of first (possibly intersects other
       * regions)
       */
      /* delete regions the included region completely overlaps */
      region = first->next;
      while(region != NULL && region->start + region->len <= start + len) {
	next_region = region->next;
	delete_region(region);
	region = next_region;
      }
      if(region == NULL) {
	/* deleted all the regions after first, so first is now the tail */
	first->next = NULL;
	chkpt_exclude_tail = first;
      } else {
	/* region points to the next region to be excluded after first */
	if(start + len > region->start) {
	  region->len = region->start + region->len - (start + len);
	  region->start = start + len;
	}
	first->next = region;
	region->prev = first;
      }
      /* adjust first */
      if(start > first->start) {
	/* included region overlaps end of first; chop off end of first */
	first->len = start - first->start;
      } else {
	/* included region entirely overlaps first; delete first */
	if(first->next != NULL)
	  first->next->prev = first->prev;
	else
	  chkpt_exclude_tail = first->prev;
	if(first->prev != NULL)
	  first->prev->next = first->next;
	else
	  chkpt_exclude_head = first->next;
	delete_region(first);
      }
    }
  }

 return status;
}

static chkpt_exclude_node_t *new_region(char *start, size_t len,
					chkpt_exclude_opt_t options)
{
  chkpt_exclude_node_t *region;

  region = (chkpt_exclude_node_t *)malloc(sizeof(chkpt_exclude_node_t));
  if(region != NULL) {
    region->start = start;
    region->len = len;
    region->options = options;
    region->next = NULL;
    region->prev = NULL;
  }

  return region;
}

static int add_region_before(chkpt_exclude_node_t *next,
			     char *addr, size_t len,
			     chkpt_exclude_opt_t options)
{
  chkpt_exclude_node_t *region;

  region = new_region(addr, len, options);
  if(region == NULL) {
    return -1;
  }

  region->next = next;
  region->prev = next->prev;
  if(next->prev == NULL)
    chkpt_exclude_head = region;
  else
    next->prev->next = region;
  next->prev = region;

  return 0;
}

static int new_tail_region(char *start, size_t len,
			   chkpt_exclude_opt_t options)
{
  chkpt_exclude_node_t *region;
  
  region = new_region(start, len, options);
  if(region == NULL) {
    return -1;
  }
  region->prev = chkpt_exclude_tail;
  if(chkpt_exclude_tail != NULL) {
    chkpt_exclude_tail->next = region;
  } else {
    chkpt_exclude_head = region;
  }
  chkpt_exclude_tail = region;
  return 0;
}

static void delete_region(chkpt_exclude_node_t *region)
{
  free(region);
}

/* search starting at start if start is not NULL */
static chkpt_exclude_node_t *find_region(char *addr,
					 chkpt_exclude_node_t *start)
{
  chkpt_exclude_node_t *node;

  /* start at the beginning if start is NULL */
  if(start == NULL) {
    node = chkpt_exclude_head;
  } else {
    node = start;
  }

  if(node == NULL)
    return NULL;

  while (node != NULL) {
    if (((node->start <= addr) && (addr < node->start + node->len))
	|| (node->start > addr)) {
	return node;
    }
    node = node->next;
  }

  return NULL;
}

int chkpt_num_exclude_regions(void)
{
  int region_count;
  chkpt_exclude_node_t *region;

  region_count = 0;
  for(region = chkpt_exclude_head ; region != NULL ; region = region->next) {
    region_count++;
  }

  return region_count;
}


/* intersect the memory mappings with the exclude list */
/* mapping is allocated big enough to hold the worst case
 * number of mappings assuming that no one excludes regions
 * after the call to get_state_info.
 */
void chkpt_intersect_map(int *nmap, memmap_t *mapping)
{
  int unsplit_map;		/* number of mappings not intersected */
  int next_map;			/* slot to put next mapping in */
  int max_nmap;			/* worst case number of mappings */
  int maps_left;		/* number of maps left to intersect */
  memmap_t cur_map;
  chkpt_exclude_node_t *region;
  chkpt_exclude_node_t *prev_region;
  long page_size;
  caddr_t region_start;
  caddr_t region_end;

  /* shift mappings to top */
  unsplit_map = chkpt_count_excl_maps(*nmap, mapping) - *nmap;
  if(unsplit_map == 0)
    return;
  
  max_nmap = *nmap + unsplit_map;
  memmove(mapping + unsplit_map, mapping, *nmap * sizeof(memmap_t));

  /* copy to beginning chopping out excluded regions */
  /* ASSUME: mappings are increasing memory order and on page boundaries */
  prev_region = NULL;
  maps_left = *nmap;
  next_map = 0;
  page_size = sysconf(_SC_PAGESIZE);
  do {
    cur_map = mapping[unsplit_map];

    region = find_region(cur_map.addr, prev_region);
    if(region != NULL && (cur_map.addr + cur_map.len > region->start)) {
      /* cur_map overlaps region */
      region_start = region->start + page_size - 1;
      region_start = region_start - ((unsigned long)region_start % page_size);
      region_end = region->start + region->len;
      region_end = region_end - ((unsigned long)region_end % page_size);
      if(region_start >= region_end) {
	/* this region is entirely within a page, so just skip it */
	prev_region = region->next;
	/* need to set region to terminate the loop in case prev_region
	 * is NULL and region overlaps cur_map because it is not page aligned
	 */
	region = prev_region;
      } else {
	if(cur_map.addr < region_start) {
	  /* cur_map overlaps front of region */
	  mapping[next_map] = cur_map;
	  mapping[next_map].len = region_start - cur_map.addr;
	  next_map++;
	  mapping[next_map].addr = region_start;
	} else {
	  mapping[next_map].addr = cur_map.addr;
	}
	  /* add empty region so excluded region will will be mapped
	     after recovery */
	if(cur_map.addr + cur_map.len > region_start) {
	  mapping[next_map].pagesize = cur_map.pagesize;
	  mapping[next_map].offset = 0;
	  mapping[next_map].prot = cur_map.prot;
	  mapping[next_map].type = SEG_EXCL;
	  mapping[next_map].file_offset = 0;
	  mapping[next_map].remap = (region->options & CHKPT_EXCL_NOREMAP)?0:1;
	}
	if(cur_map.addr + cur_map.len <= region_end) {
	  /* cur_map does not overlap end of region */
	  mapping[next_map].len = cur_map.addr + cur_map.len
	    - mapping[next_map].addr;
	  
	  unsplit_map++;
	  maps_left--;
	  prev_region = region;
	} else {
	  /* cur_map overlaps end of region */
	  mapping[next_map].len = region_end - mapping[next_map].addr;
	  
	  cur_map.len = cur_map.addr + cur_map.len - region_end;
	  cur_map.addr = region_end;
	  mapping[unsplit_map] = cur_map;
	  prev_region = region->next;
	  /* need to set region to terminate the loop in case
	   * prev_region is NULL and region overlaps cur_map because
	   * it is not page aligned 
	   */
	  region = prev_region;
	}
	if(cur_map.addr + cur_map.len > region_start) {
	  next_map++;
	}
      }
    } else {
      /* cur_map falls entirely before region */
      mapping[next_map] = cur_map;
      next_map++;
      unsplit_map++;
      maps_left--;
      prev_region = region;
    }
  } while(maps_left > 0 && region != NULL);

  while(maps_left > 0) {
      mapping[next_map] = mapping[unsplit_map];
      next_map++;
      unsplit_map++;
      maps_left--;
  }
  *nmap = next_map;
}

/* count number of mappings due to intersections of memory mappings
 *  with the exclude list
 */ 
int chkpt_count_excl_maps(int nmap, memmap_t *mapping)
{
  int maps_left;		/* number of maps left to intersect */
  int map_cnt;
  int next_map;
  memmap_t cur_map;
  chkpt_exclude_node_t *region;
  chkpt_exclude_node_t *prev_region;
  long page_size;
  caddr_t region_start;
  caddr_t region_end;

  /* shift mappings to top */
  if (chkpt_num_exclude_regions() == 0)
    return nmap;
  
  /* ASSUME: mappings are increasing memory order and on page boundaries */
  prev_region = NULL;
  maps_left = nmap;
  map_cnt = 0;
  next_map = 0;
  cur_map = mapping[next_map];
  page_size = sysconf(_SC_PAGESIZE);
  do {
    region = find_region(cur_map.addr, prev_region);
    if(region != NULL && (cur_map.addr + cur_map.len > region->start)) {
      /* cur_map overlaps region */
      region_start = region->start + page_size - 1;
      region_start = region_start - ((unsigned long)region_start % page_size);
      region_end = region->start + region->len;
      region_end = region_end - ((unsigned long)region_end % page_size);
      if(region_start >= region_end) {
	/* this region is entirely within a page, so just skip it */
	prev_region = region->next;
	/* need to set region to terminate the loop in case prev_region
	 * is NULL and region overlaps cur_map because it is not page aligned
	 */
	region = prev_region;
      } else {
	if(cur_map.addr < region_start) {
	  /* cur_map overlaps front of region */
	  map_cnt++;
	}
	map_cnt++;
	if(cur_map.addr + cur_map.len <= region_end) {
	  /* cur_map does not overlap end of region */
	  maps_left--;
	  cur_map = mapping[++next_map];
	  prev_region = region;
	} else {
	  /* cur_map overlaps end of region */
	  cur_map.len = cur_map.addr + cur_map.len - region_end;
	  cur_map.addr = region_end;
	  prev_region = region->next;
	  /* need to set region to terminate the loop in case prev_region
	   * is NULL and region overlaps cur_map because it is not page aligned
	   */
	  region = prev_region;
	}
      }
    } else {
      /* cur_map falls entirely before region */
      map_cnt++;
      cur_map = mapping[++next_map];
      maps_left--;
      prev_region = region;
    }
  } while(maps_left > 0 && region != NULL);

  while(maps_left > 0) {
    map_cnt++;
    maps_left--;
  }

  return map_cnt;
}

void chkpt_print_exclude_list(void)
{
  chkpt_exclude_node_t *cur;

  printf("chkpt exclude regions\n");
  printf("   addr        len     options\n");
  printf("----------  --------  ---------\n");
  for(cur = chkpt_exclude_head ; cur != NULL ; cur = cur->next) {
    printf("0x%08lx  %8d  %6s\n", (unsigned long)cur->start, cur->len,
	   ((cur->options & CHKPT_EXCL_NOREMAP) ? "NOREMAP" : "") );
  }
}

#ifdef CHKPT_EXCLUDE_DEBUG
/* fill excluded memory with trash to make sure no one is using it */
void chkpt_trash_exclude_list(void)
{
  chkpt_exclude_node_t *cur;

  for(cur = chkpt_exclude_head ; cur != NULL ; cur = cur->next) {
    if (!(cur->options & CHKPT_EXCL_NOREMAP)) {
      fill_with_trash(cur->start, cur->len);
    }
  }
}
#endif

