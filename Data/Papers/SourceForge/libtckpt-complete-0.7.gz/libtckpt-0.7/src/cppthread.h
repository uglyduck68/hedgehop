/*
 * cppthread.h
 *
 * checkpointing and pthreads
 *
 * History
 * -------
 * $Log: cppthread.h,v $
 * Revision 6.2  2000/10/20 21:40:05  dieter
 * renamed barrier_wait to chkpt_barrier_wait.
 * Fixed a synchronization problem that occured during recovery.
 * General cleanup.
 * Use POSIX rt signals if they are available.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.2  2000/05/02 14:32:04  dieter
 * Moved callbacks to checkpoint thread.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.6  2000/01/28 21:09:59  dieter
 * Included sys/time.h for hrtime_t.
 *
 * Revision 4.5  2000/01/25 20:42:09  dieter
 * Added code to time each checkpoint.
 *
 * Revision 4.4  2000/01/19 22:41:06  dieter
 * Added pending field to chkpt_thread_info_t structure.
 * Add structures to save and restore thread to pid mappings.
 *
 * Revision 4.3  1999/10/21 23:13:12  dieter
 * Fixed typo.
 *
 * Revision 4.2  1999/10/21  22:43:11  dieter
 * Use SIGFPE for checkpointing with Linux because LinuxThreads uses
 * SIGUSR1, and SIGFPE is not used.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.3  1999/04/20  15:08:00  dieter
 * Use mutexes instead of pthread_sigmask to prevent signals when locking a mutex.
 * Intercept _mutex_lock and _mutex_unlock to handle libraries that use mutexes.
 *
 * Revision 3.2  1999/03/11  17:43:17  dieter
 * Declare prevent_locks as volatile.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.3  1999/01/20  01:57:40  dieter
 * Removed setcontext/getcontext code.  It was not any better than
 * sigsetjmp/siglongjmp.
 *
 * Revision 2.2  1998/12/22  15:21:50  dieter
 * Allocate mutex info in clumps.
 * Try getcontext/setcontext instead of sigsetjmp/siglongjmp.
 *
 * Revision 2.1  1998/12/22  15:21:08  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.11  1998/11/23  21:57:23  dieter
 * Added prevent_locks.
 *
 * Revision 1.10  1998/11/23  20:32:40  dieter
 * Wait for all threads to be signalled before proceeding in the sighandler.
 *
 * Revision 1.9  1998/09/01  17:11:51  dieter
 * Got rid of race between threads being created or exiting during a
 * checkpoint.
 *
 * Revision 1.8  1998/08/26  21:24:42  dieter
 * Checkpointing works with timer, but only once.
 *
 * Revision 1.7  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.6  1998/08/17  17:03:15  dieter
 * Added the main thread to the thread table.
 *
 * Revision 1.5  1998/08/16  16:42:17  dieter
 * Made changes so that threads checkpoint when they get a SIGUSR1.
 * Recovery does not work yet.
 *
 * Revision 1.4  1998/08/10  19:18:12  dieter
 * Switched from thread info list to hash table of thread info.
 *
 * Revision 1.3  1998/08/10  15:43:57  dieter
 * Made changes so threads automatically add or remove themselves from the
 * thread_info list
 *
 * Revision 1.2  1998/07/31  20:15:14  dieter
 * Pretty much everything is moved over from the old version of checkpointing.
 *
 * Revision 1.1  1998/07/31  13:38:29  dieter
 * Initial revision
 *
 */

#ifndef CPPTHREAD_H_
#define CPPTHREAD_H_

#include <sys/time.h>		/* for hrtime_t */
#include <sys/types.h>
#include <signal.h>
#include <pthread.h>
#include <setjmp.h>

#include "hash.h"
#include "barrier.h"
#include "cpglobal.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define CHKPT_SIG          __chkpt_signal

#define MUTEX_INFO_INCR  8	/* number of mutex info structures to 
				 * allocate at at time
				 */

#define THR_IN_SIGHANDLER  0x01L /* The thread is in the signal handler */
#define THR_LOCKING_MUTEX  0x02L /* The thread is locking a mutex */
#define THR_SIGNALLED      0x04L /* The thread has been signalled */
#define THR_COND_WAIT	   0x08L /* The thread is in pthread_cond_wait */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct chkpt_mutex_info {
  pthread_mutex_t *mutex;	/* a pointer to the mutex 		     */
  unsigned long    status;	/* information about the mutex 	 	     */
  struct chkpt_mutex_info *next; /* next mutex in the list	             */
} chkpt_mutex_info_t;

/* a structure that can save the thread attributes without using a pointer
   into the heap */
typedef struct chkpt_pthread_attr {
  int                 contentionscope;
  int                 detachstate;
  size_t              stacksize;
  void               *stackaddr;
  struct sched_param  param;
  int                 policy;
  int                 inheritsched;
} chkpt_pthread_attr_t;

typedef struct chkpt_thread_info {
  pthread_t id;			/* the thread ID */
  chkpt_pthread_attr_t attr;	/* attributes object */
  sigjmp_buf jmp_buf;		/* where to jump when recovering */
  void *stack_item;		/* a pointer to something on the stack */
  chkpt_mutex_info_t *held_mutexes; /* a list of mutexes this thread holds */
  chkpt_mutex_info_t *free_mutexes; /* list of empty mutex strutures */
  sigset_t sigmask;		/* the thread's signal mask */
  sigset_t pending;		/* signals pending at the time of the chkpt */
  unsigned long status;
  pthread_mutex_t sig_mutex;
} chkpt_thread_info_t;

#ifndef TPID_DESC_T
#define TPID_DESC_T
/* thread_pid_descriptor */
typedef struct tpid_desc {
    pthread_t tid;
    pid_t     pid;
} tpid_desc_t;  
#endif

typedef struct norestore {
  char   pad1[PAD_SIZE];
  tpid_desc_t thr_pids[MAX_CHKPT_THREADS];
  int         num_pids;
  char   pad2[PAD_SIZE];
} norestore_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

extern htable_t *chkpt_thr_tab;
extern int       num_other_threads;
extern int       main_thread_id; /* thread id of the "main" thread */
extern pthread_t chkpt_thread_id; /* thread id of the "checkpoint" thread */
extern char     *chkpt_filename; /* filename in which to save checkpoint */
extern pthread_mutex_t chkpt_start_mutex;
extern int volatile prevent_locks;
extern int all_threads_signalled;
extern pthread_cond_t thread_signalled_cond;

extern pthread_cond_t sending_sigs_cond;
extern pthread_cond_t locker_cnt_cond;
extern barrier_t *chkpt_barrier;

#if OS == LINUX
extern norestore_t chkpt_no_restore;
#endif

extern hrtime_t chkpt_save_start;
extern hrtime_t chkpt_save_end;

extern int __chkpt_signal;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int chkpt_thread_init( void );

void restore_threads( int fd );
void wait_for_other_threads(void);
void continue_other_threads(void);

int  save_thread_state(void);

void add_thread_info( pthread_t tid, const pthread_attr_t *attr );
void remove_thread_info( pthread_t tid );

void suspend_threads( void );
void chkpt_sighandler( int sig, siginfo_t *siginfo, void *ucontext );

void chkpt_thrlib_cleanup(void);
void save_pending_signals(void);

#if OS == LINUX
/* pthread_chkpt_* prototypes should be in pthread.h in patched thread lib */
extern int pthread_chkpt_precreate(sigjmp_buf *mgr_env
#if 0
,
				   void (*block_func)(sigjmp_buf *)
#endif
				   );
extern int pthread_chkpt_postcreate(int sig);
extern void pthread_chkpt_prerestart(tpid_desc_t *thread_pids,
				     int *num_pids,
				     sigjmp_buf *mgr_env);
extern int pthread_chkpt_postrestart(tpid_desc_t *thread_pids,
				     int num_pids,
				     int sig);
extern int pthread_chkpt_restart_main(int recovering);
#endif

#endif /* CPPTHREAD_H_ */
