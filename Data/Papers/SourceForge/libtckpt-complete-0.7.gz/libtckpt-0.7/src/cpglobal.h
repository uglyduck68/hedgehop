/*
 * cpglobal.h
 *
 * Global variables that all files may need to see.
 *
 * History
 * -------
 * $Log: cpglobal.h,v $
 * Revision 6.2  2000/10/20 20:59:37  dieter
 * Beginnings of better recovery.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.2  2000/05/02 14:29:56  dieter
 * Added declaration of chkpt_recovering.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.3  2000/01/28 21:12:31  dieter
 * Added interface for Linux checkpointing.
 *
 * Revision 4.2  2000/01/19 22:38:16  dieter
 * Moved MAX_CHKPT_THREADS and PAD_SIZE here so multiple files can use them.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.2  1999/04/20  15:08:56  dieter
 * Use mutexes instead of pthread_sigmask to prevent signals when
 * locking a mutex.
 * Intercept _mutex_lock and _mutex_unlock to handle libraries that use mutexes.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.3  1999/01/08  23:49:48  dieter
 * Added chkpt_block and chkpt_unblock to allow user code to be atomic
 * with respect to checkpoints.
 *
 * Revision 2.2  1999/01/06  23:22:42  dieter
 * Added extern declaration for chkpt_count.
 *
 * Revision 2.1  1998/12/22  15:17:03  dieter
 * Version that worked for ftcs paper.
 *
 * Revision 1.2  1998/08/26  21:24:42  dieter
 * Checkpointing works with timer, but only once.
 *
 * Revision 1.1  1998/08/18  19:07:49  dieter
 * Initial revision
 *
 */

#ifndef CPGLOBAL_H_
#define CPGLOBAL_H_

#include "checkpoint.h"

#define MAX_CHKPT_THREADS 256	/* maximum number of threads allowed for
				 * by checkpointing code.
				 */

#define PAD_SIZE	   4096	/* enough to align so that exclude works */

#if OS == LINUX

#define PTHREAD_FMT  "%ld"	/* pthread_t is a long int in Linux */
#elif OS == SOLARIS
/* Solaris does not use the pthread_chkpt calls */ 
#define pthread_chkpt_precreate(manager_env) {}
#define pthread_chkpt_postcreate() {}
#define pthread_chkpt_prerestart(pids, num_pids, manager_env) {}
#define pthread_chkpt_postrestart(pids, num_pids) {}

#define PTHREAD_FMT  "%d"	/* pthread_t is an int in Linux */
#else
#error OS is unsupported.  Maybe try config for Linux?
#endif

int do_checkpoint(char *filename);

extern chkpt_opt_t chkpt_opts;
extern int         chkpt_count;	/* current checkpoint number		     */

extern int         init_done;
extern pthread_mutex_t in_chkpt_mutex;
extern int         chkpt_recovering;
extern int chkpt_restart_manager;	/* true when manager thread should run */

#endif
