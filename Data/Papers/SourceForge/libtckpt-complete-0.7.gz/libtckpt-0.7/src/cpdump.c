#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "config.h"

#include "cppthread.h"
#include "machif.h"

void dump_thread_info(int fd);
void dump_mappings(int fd);

int main(int argc, char *argv[])
{
    int cp_fd;

    if (argc != 2) {
	fprintf(stderr, "usage: %s chkpt_file\n", argv[0]);
	exit(-1);
    }

    if ( (cp_fd = open(argv[1], O_RDONLY)) == -1) {
	fprintf(stderr, "%s: cannot open %s: %s\n", argv[0], argv[1],
		strerror(errno));
	exit(-1);
    }

    dump_thread_info(cp_fd);
    dump_mappings(cp_fd);

    close(cp_fd);

    return 0;
}

void dump_thread_info(int fd)
{
    int		         status; /* return code from system calls            */
    chkpt_thread_info_t  info;	/* thread information read from checkpoint   */
    int 	         n_threads; /* number of threads		     */
    int 		 thr_count; /* loop index			     */
    sigjmp_buf		 mgr_env;

    if( (status = read(fd, &n_threads, sizeof(int))) == -1) {
	fprintf(stderr, "cannot read number of threads: %s\n",
		strerror(errno));
	exit(-1);
    }

    printf("%d threads\n", n_threads);
    printf("id   stack addr  stack size\n");
    printf("---  ----------  ----------\n");
    for(thr_count = 0 ; thr_count < n_threads ; thr_count++) {
	if( (status = read(fd, &info, sizeof(chkpt_thread_info_t))) == -1) {
	    fprintf(stderr, "cannot read thread info: %s\n", strerror(errno));
	    exit(-1);
	}
	printf("%3ld  0x%08lx  %8d\n", info.id, (long)(info.attr.stackaddr),
	       info.attr.stacksize);
    }
    if( (status = read(fd, &mgr_env, sizeof(sigjmp_buf))) < 0) {
      fprintf(stderr, "cannot read manager env: %s\n", strerror(errno));
      exit(-1);
    }
}

void dump_mappings(int fd)
{
    int       nmap;
    int       status;
    caddr_t   endds;
    caddr_t   stkbase;
    memmap_t  memmap;
    int       map;
    char      type_buf[5];

    type_buf[4] = '\0';
    status = read(fd, &nmap, sizeof(int));
    status = read(fd, &endds, sizeof(caddr_t));
    status = read(fd, &stkbase, sizeof(caddr_t));
    printf("%d mappings, end of data = %p, stack base = %p\n",
	   nmap, endds, stkbase);

    printf("type   address      size    pagesize   offset   protections");
    printf("  file offset remap\n");
    printf("----  ----------  --------  --------  --------  -----------");
    printf("  ----------- -----\n");
    for(map = 0 ; map < nmap ; map++) {
	status = read( fd, &memmap, sizeof(memmap_t) );
	memcpy(type_buf, &memmap.type, 4);
	printf("%s %11p  %8ld  %8ld  %8ld", type_buf,
	       memmap.addr, memmap.len, memmap.pagesize, memmap.offset);
	printf("      %c", (memmap.prot & PROT_READ) ? 'r' : '-');
	printf("%c", (memmap.prot & PROT_WRITE) ? 'w' : '-');
	printf("%c     ", (memmap.prot & PROT_EXEC) ? 'x' : '-');
	printf("  %8d", memmap.file_offset);
	printf("  %5s\n", (memmap.remap ? "yes" : "no"));
    }
}
