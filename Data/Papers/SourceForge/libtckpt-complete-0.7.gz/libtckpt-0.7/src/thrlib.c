/*
 * thrlib.h
 *
 * Deal with the thread libraries.  In particular exclude them from the
 * checkpoint.  I will manually recreate the thread state during recovery,
 * so I don't want to save the thread library state in the checkpoint.
 * Hopfully this will avoid problems where the thread library state at
 * the time of the checkpoint not match the thread library state during
 * recovery.
 *
 * History
 * -------
 * $Log: thrlib.c,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  1999/10/08 20:42:15  dieter
 * Removed include of sys/fault.c.  Apparently it is unused.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 1.2  1999/08/02  14:41:31  dieter
 * Modified to not save the thread library state in the checkpoint.
 * This version does not work because the thread library is unaware of the
 * fact that the thread stacks of the restarted threads overlap with space
 * it has allocated.
 *
 * Revision 1.1  1999/07/07  21:24:24  dieter
 * Initial revision
 *
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <sys/syscall.h>
#include <errno.h>
#include <fcntl.h>
#include <procfs.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "debug.h"
#include "checkpoint.h"
#include "cppthread.h"
#include "hash.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define BUFSZ 1024
#define MAP_FILENAME          "/proc/self/map"
#define RESERVED_MAP_FILENAME "/proc/self/rmap"
#define LWP_STATUS_FILENAME   "/proc/self/lstatus"

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int  include_thr_stack( long key, void *value, void *arg );
void include_user_thr_stack(void);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int exclude_thr_libs(void)
{
  int          status;		/* return code from a system call            */
  struct stat  pthread_info;	/* lstat info for pthread library            */
  struct stat  sol_thread_info;	/* lstat info for solaris threads library    */
  struct stat  obj_info;	/* lstat info for obj. in /proc/self/object  */
  int          mapfd;		/* fd of /proc file with mappings	     */
  prmap_t      prmap;		/* a mapping read from /proc		     */
  char 	       obj_filename[BUFSZ]; /* filename of file in /proc/self/object */
  uintptr_t    last_addr;	/* end of last excluded region
				 * The unitialized data follows the
				 * initialized data in a separate mapping that
				 * is not mapped to any file.  ASSUME: any
				 * mapping immediately following a thread
				 * library mapping is unitialized data for
				 * the thread library and thus should be
				 * excluded.
				 */

  /* get info for libpthread */
  status = lstat("/usr/lib/libpthread.so.1", &pthread_info);
  if(status == -1) {
    perror("stat");
    exit(-1);
  }

  /* get info for libthread */
  status = lstat("/usr/lib/libthread.so.1", &sol_thread_info);
  if(status == -1) {
    perror("stat");
    exit(-1);
  }
  
  mapfd = open( MAP_FILENAME, O_RDONLY );
  if (mapfd < 0) {
    perror("open");
    fprintf(stderr, "exclude_thr_libs: %s\n", MAP_FILENAME);
    exit(-1);
  }

  /* search for mappings related to a thread library and exclude them */
  last_addr = 0;
  do {
    status = read(mapfd, &prmap, sizeof(prmap_t));
    if (status == sizeof(prmap_t)) {
      if (prmap.pr_mapname[0] != '\0') {
	strncpy(obj_filename, "/proc/self/object/", BUFSZ);
	strncat(obj_filename, prmap.pr_mapname, BUFSZ);
	lstat(obj_filename, &obj_info);
	if ((obj_info.st_dev == sol_thread_info.st_dev
	     && obj_info.st_ino == sol_thread_info.st_ino)
	    || (obj_info.st_dev == pthread_info.st_dev
		&& obj_info.st_ino == pthread_info.st_ino)) {
	  chkpt_exclude_region((void *)prmap.pr_vaddr, prmap.pr_size);
	  last_addr = prmap.pr_vaddr + prmap.pr_size;
	} else {
	  last_addr = 0;
	}
      } else if (last_addr == prmap.pr_vaddr) {
	chkpt_exclude_region((void *)prmap.pr_vaddr, prmap.pr_size);
	last_addr = 0;
      }
    } else if(status > 0) {
      fprintf(stderr, "read %d bytes from %s instead of expected %d\n",
	      status, MAP_FILENAME, sizeof(prmap_t));
      exit(-1);
    } else if (status < 0) {
      fprintf(stderr, "error reading %s\n", MAP_FILENAME);
      perror("read");
      exit(-1);
    }
  } while (status > 0);
  close(mapfd);

  return 0;
}

void exclude_thrlib_stacks(void)
{
  int      lwp_status_fd;
  int      rmap_fd;
  caddr_t  start;
  caddr_t  end;
  caddr_t  excl_start;
  caddr_t  excl_end;
  int      lwp;
  prheader_t   prheader;
  lwpstatus_t  lwpstatus;
  prmap_t      prmap;
  int	       status;
  caddr_t      sp;
  int          found;
  int          done;
  int          map;

  /* open files */
  if ( (lwp_status_fd = open(LWP_STATUS_FILENAME, O_RDONLY)) == -1) {
    CRASH(("error opening %s: %s\n", LWP_STATUS_FILENAME, strerror(errno)));
  }

  if ( (rmap_fd = open(RESERVED_MAP_FILENAME, O_RDONLY)) == -1) {
    CRASH(("error opening %s: %s\n", RESERVED_MAP_FILENAME, strerror(errno)));
  }

  status = pread(lwp_status_fd, &prheader, sizeof(prheader_t), 0);
  if (status == -1) {
    CRASH(("error reading lwp status header: %s\n", strerror(errno)));
  }

  excl_start = NULL;
  excl_end = NULL;
  /* read lwp stack (starting w/ lwp 2, lwp 1 == the main thread...) */
  for(lwp = 1 ; lwp < prheader.pr_nent ; lwp++) {
    status = pread(lwp_status_fd, &lwpstatus, sizeof(lwpstatus_t),
		   lwp * prheader.pr_entsize + sizeof(prheader_t));
    if (status == -1) {
      CRASH(("error reading lwp %d status: %s\n", lwp, strerror(errno)));
    }
    sp = (caddr_t)lwpstatus.pr_reg[R_SP];
    if (sp < excl_start || sp >= excl_end) {
      /* if not in currently excluded range search rmap for sp
       * while keeping track of contiguous regions of memory.
       */
      excl_start = NULL;
      excl_end = NULL;
      found = 0;
      done = 0;
      map = 0;
      while(!done && (status = pread(rmap_fd, &prmap, sizeof(prmap_t),
				     map * sizeof(prmap_t))) ) {
	if (status == -1) {
	  CRASH(("cound not read from map file:%s\n", strerror(errno)));
	}
	start = (caddr_t)prmap.pr_vaddr;
	end = (caddr_t)prmap.pr_vaddr + prmap.pr_size;

	if (excl_end == start) {
	  excl_end = end;
	} else if (!found) {
	  excl_start = start;
	  excl_end = end;
	} else {
 	  done = 1;
	}
	if (start <= sp && sp < end) {
	  found = 1;
	}
	map++;
      }

      if (found) {
	if(excl_end == NULL) {
	  excl_start = (caddr_t)prmap.pr_vaddr;
	  excl_end = (caddr_t)prmap.pr_vaddr + prmap.pr_size;
	}
	chkpt_exclude_region(excl_start, excl_end - excl_start);
      } else {
	CRASH(("stack pointer of LWP %d is unmapped at addr %p\n", lwp, sp));
      }
#if 0
      printf("excluding 0x%08p - 0x%08p for lwp %d (sp = %p)\n",
	     excl_start, excl_end, lwp, sp);
#endif
    }
  }

  close(rmap_fd);
  close(lwp_status_fd);

  include_user_thr_stack();
}

void include_user_thr_stack(void)
{
  int      rmap_fd;
  prmap_t  prmap;
  int	   status;

  /* open files */
  if ( (rmap_fd = open(MAP_FILENAME, O_RDONLY)) == -1) {
    CRASH(("error opening %s: %s\n", MAP_FILENAME, strerror(errno)));
  }

  while( (status = read(rmap_fd, &prmap, sizeof(prmap_t))) > 0) {
    htable_forall(chkpt_thr_tab, include_thr_stack, &prmap);
  }
  if (status == -1) {
    CRASH(("error reading rmap file: %s\n", strerror(errno)));
  }

  close(rmap_fd);
}

int  include_thr_stack( long key, void *value, void *arg )
{
  prmap_t *prmap;
  chkpt_thread_info_t *thr_info;

  prmap = (prmap_t *)arg;
  thr_info = (chkpt_thread_info_t *)value;

  if( thr_info->id == main_thread_id )
    return 0;
  
  if( (void *)prmap->pr_vaddr <= thr_info->stack_item &&
      thr_info->stack_item < (void *)prmap->pr_vaddr + prmap->pr_size ) {
    chkpt_include_region((void *)prmap->pr_vaddr, prmap->pr_size);
    return 1;
  }

  return 0;
}
