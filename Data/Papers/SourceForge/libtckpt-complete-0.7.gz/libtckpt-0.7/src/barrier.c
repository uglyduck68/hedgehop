/* #define BARRIER_BUSY_WAIT */
/*
  barrier.c
  
  This file implements a barrier without using mutexes or condition
  variables.  The mutex and condition variable calls are not
  reentrant, so it is not safe to call them within the signal handler
  in Linux.
 
  To implement barriers without other synchronization I borrowed
  ideas from SEClib (by Griffieon and Sumanasekara) and Shmapers (by
  Dietz, Mattox, and Krishnamurthy).  These barriers are not
  intended to be as blindingly fast as the shmapers ones.  However,
  for checkpointing raw barrier overhead time will still be tiny
  compared to the amount of time spend saving checkpoints.
 
  Part of the problem is that pthreads do not have thread ids that
  start at 0 or 1 and increment by 1, so I need to search the array to
  find the right entry to increment.

  How it works
  ------------
  barrier_init allocates an array with one entry per thread.  If the
  nubmer of threads changes, you need to allocate a new barrier array.
  Each array entry contains a thread id and count.  The thread id is
  initially set to an invalid id (ASSUME: -1 is an invalid thread
  id) and the count is set to 0.
  
  When a thread calls barrier, it searches the array.  If it finds its
  entry, it increments its counter.  Otherwise, it takes the first
  vacant entry for its own use and increments the counter for that
  entry.  The thread then waits for each entry in turn to reach the
  current count.
  
  History
  -------
  $Log: barrier.c,v $
  Revision 6.5  2001/07/06 23:08:59  wrdieter
  Fixed asynchronous checkpointing synchronization (problem #429309)

  Revision 6.4  2001/06/06 21:10:44  wrdieter
  Fixed singal based barriers.

  Revision 6.3  2000/10/20 20:44:11  dieter
  Added preliminary support for blocking (vs. busy waiting) barriers
  using signals.  Currently blocking barriers do not work reliably.

  Revision 6.2  2000/05/12 03:38:08  dieter
  Added ssched_yield for statically linked version of sched_yield.

  Revision 6.1  2000/05/02 20:09:42  dieter
  Released version 0.6.

  Revision 5.1  2000/02/01 23:37:32  dieter
  Release 0.5 plus some fixes

  Revision 1.2  2000/01/19 22:50:59  dieter
  Added barrier_init + some changes for checkpointing.

  Revision 1.1  1999/11/08 18:07:42  dieter
  Initial revision
 
*/

#include <stdlib.h>
#include <pthread.h>
#ifndef BARRIER_BUSY_WAIT
#include <signal.h>
#endif

#include "debug.h"
#include "barrier.h"
#include "machif.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define INVALID_PTHREAD_ID (-1)

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static int wait_for_other_cnt(barrier_t *bar, int wait_cnt);
#ifndef BARRIER_BUSY_WAIT
static void barrier_sighandler(int sig, siginfo_t *info, void *ucontext);
#endif
void print_sigmask(sigset_t *mask);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

barrier_t *chkpt_barrier_create(pthread_t *tids, int num_threads)
{
    barrier_t *barrier;

    barrier = (barrier_t *)malloc(sizeof(barrier_t)
				  + sizeof(bar_entry_t) * (num_threads - 1));
    chkpt_barrier_init(barrier, tids, num_threads);
    return barrier;
}

void chkpt_barrier_init(barrier_t *barrier, pthread_t *tids, int num_threads)
{
    int cnt;

    if (barrier != NULL) {
	barrier->num_threads = num_threads;
	barrier->wait_cnt = 1;
	for(cnt = 0 ; cnt < num_threads ; cnt++) {
	    barrier->entry[cnt].id = tids[cnt];
	    barrier->entry[cnt].pid = -1;
	    barrier->entry[cnt].cnt = 0;
	}
    }
}

void chkpt_barrier_destroy(barrier_t *barrier)
{
    free(barrier);
}

/* pid is restored during recover and therefore invalid.
 * Reset pid so it will get reinitialized correctly.
 */
void chkpt_barrier_pid_reset(barrier_t *bar)
{
  int cnt;

  for (cnt = 0 ; cnt < bar->num_threads ; cnt++) {
    bar->entry[cnt].pid = -1;
  }
}

int chkpt_barrier_wait(barrier_t *bar)
{
    int cnt;
    pthread_t me;
    int       status;

    me = pthread_self();
    for(cnt = 0 ;
	cnt < bar->num_threads && bar->entry[cnt].id != me ;
	cnt++)
	;

    ASSERT(cnt != bar->num_threads);

    if (bar->entry[cnt].pid == -1) {
	bar->entry[cnt].pid = getpid();
    }
    bar->entry[cnt].cnt++;
    /* ASSUME: all threads in this process are in the same process group
     * and no other processes are in the same process group.  Cannot use
     * pthread_kill here because it is not reentrant.
     */
    /* it would be nice to be more selective about waking up processes,
     * but that would require using a lock and managing a list... for
     * now just wake everyone up.  With a normal barrier we could just
     * wait for the last process to hit the barrier and have only it
     * send a signal.  That breaks chkpt_barrier_wait_for_others because
     * the one thread that is waiting for all the others may not be the
     * last process to hit the barrier (in fact it is usually not).
     */
    kill(0, BARRIER_SIG);
    status = wait_for_other_cnt(bar, bar->entry[cnt].cnt);
    return status;
}

/* Wait until all others get to the barrier, but don't increment my count.
 * Only one thread can call this per barrier...
 */
int chkpt_barrier_wait_for_others(barrier_t *bar)
{
    int cnt;
    pthread_t me;
    int       status;

    me = pthread_self();
    for(cnt = 0 ;
	cnt < bar->num_threads && bar->entry[cnt].id != me ;
	cnt++)
	;

    ASSERT(cnt != bar->num_threads);

    status = wait_for_other_cnt(bar, bar->entry[cnt].cnt + 1);
    /* all the others have gotten to the barrier, but they may not
     * be blocked in the kernel yet, so wait for them here.
     *
     * NOTE: this test in only important for checkpointing where
     *       we need to know for sure that the other threads are
     *       sleeping.  If you port this to a non-checkpointing 
     *       application you may be better off taking out this test.
     */
    for(cnt = 0 ; cnt < bar->num_threads ; cnt++) {
      if (bar->entry[cnt].id != me)
	wait_for_sleep(bar->entry[cnt].pid);
    }

    return status;
}

static int wait_for_other_cnt(barrier_t *bar, int wait_cnt)
{
    int cnt;
    pthread_t me;
    int status;
#ifndef BARRIER_BUSY_WAIT
    sigset_t barrier_sig_set;

    sigprocmask(SIG_SETMASK, NULL, &barrier_sig_set);
    sigdelset(&barrier_sig_set, BARRIER_SIG);
    sigdelset(&barrier_sig_set, SIGINT); /* for easier debugging */
#endif
    me = pthread_self();
    status = BARRIER_NO_WAIT;
    for(cnt = 0 ; cnt < bar->num_threads ; cnt++) {
	if(bar->entry[cnt].id != me) {
	    /* TODO: maybe spin a few times before blocking. */
	    while(bar->entry[cnt].id == INVALID_PTHREAD_ID
		  || ((bar->entry[cnt].cnt != wait_cnt)
		      && (bar->entry[cnt].cnt != wait_cnt + 1))) {
#ifdef BARRIER_BUSY_WAIT
		sched_yield();
#else
/*  		ssigsuspend(&barrier_sig_set); */
		sigsuspend(&barrier_sig_set);
		status = BARRIER_WAITED;
#endif
	    }
	    /* if some thread has already passed the next barrier all threads
	     * must have reached this barrier, so stop waiting
	     */
	    if(bar->entry[cnt].cnt == wait_cnt + 1)
		return status;
	}
    }
    return status;
}

/* must be called before any threads created so all threads inherit mask */
int chkpt_barrier_install_sighandler(void)
{
#ifndef BARRIER_BUSY_WAIT
  struct sigaction action;
  sigset_t mask;
  int status;

  status = 0;
  action.sa_sigaction = barrier_sighandler;
  action.sa_flags = SA_SIGINFO;
  sigemptyset(&action.sa_mask);
  if ( (status = sigaction(BARRIER_SIG, &action, NULL)) < 0) {
    return status;
  }

  /* block the barrier signal so it only gets through during a sigsuspend */ 
  sigemptyset(&mask);
  sigaddset(&mask, BARRIER_SIG);
  sigprocmask(SIG_BLOCK, &mask, NULL);

  return status;
#else
  return 0;
#endif
}

#ifndef BARRIER_BUSY_WAIT
static void barrier_sighandler(int sig, siginfo_t *info, void *ucontext)
{
  return;
}
#endif

void print_sigmask(sigset_t *mask)
{
  int sig;
  unsigned long word;

  word = mask->__val[0];
  for(sig = 0 ; sig < 32 ; sig++) {
    SIGDBG(((word & 0x80000000L) ? "1" : "0"));
    if ( (sig % 4) == 3)
      SIGDBG(" ");
    word <<= 1;
  }
  SIGDBG("\n");
}
