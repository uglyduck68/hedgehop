/*
  barrier.h

  Interface to barrier code.

  History
  -------
  $Log: barrier.h,v $
  Revision 6.4  2001/07/06 23:08:59  wrdieter
  Fixed asynchronous checkpointing synchronization (problem #429309)

  Revision 6.3  2001/06/06 21:10:44  wrdieter
  Fixed singal based barriers.

  Revision 6.2  2000/10/20 20:44:11  dieter
  Added preliminary support for blocking (vs. busy waiting) barriers
  using signals.  Currently blocking barriers do not work reliably.

  Revision 6.1  2000/05/02 20:09:42  dieter
  Released version 0.6.

  Revision 5.1  2000/02/01 23:37:32  dieter
  Release 0.5 plus some fixes

  Revision 1.2  2000/01/19 22:50:59  dieter
  Added barrier_init + some changes for checkpointing.

  Revision 1.1  1999/11/08 18:07:42  dieter
  Initial revision

*/
#ifndef BARRIER_H
#define BARRIER_H

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/* return codes from barrier_wait & friends */
#define ETHRNOTFOUND  	-10000	/* internal error */
#define BARRIER_NO_WAIT  0	/* did not have to wait at the barrier */
#define BARRIER_WAITED	 1	/* had to wait at the barrier */

#define BARRIER_SIG   SIGUSR2

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct bar_entry {
    pthread_t id;		/* id of thread using this entry */
    pid_t     pid;		/* pid of thread using this entry */
    volatile long cnt;
    long          leave_cnt;
} bar_entry_t;

typedef struct barrier {
    int num_threads;		/* number of threads that will wait at
				 * the barrier
				 */
    long wait_cnt;		/* current count to wait for */
    bar_entry_t entry[1];
} barrier_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

/* must be called before any threads created so all threads inherit mask */
int   chkpt_barrier_install_sighandler(void);
barrier_t *chkpt_barrier_create(pthread_t *tids, int num_threads);
void  chkpt_barrier_init(barrier_t *barrier, pthread_t *tids, int num_threads);
void  chkpt_barrier_pid_reset(barrier_t *barrier);
void  chkpt_barrier_destroy(barrier_t *barrier);
int   chkpt_barrier_wait(barrier_t *barrier);
int   chkpt_barrier_wait_for_others(barrier_t *bar);

#endif /* BARRIER_H */
