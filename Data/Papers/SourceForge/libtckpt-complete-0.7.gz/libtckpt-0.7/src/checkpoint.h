/*
 * checkpoint.h
 *
 * This file provides the API to the application program using
 * checkpointing.
 *
 * History
 * -------
 * $Log: checkpoint.h,v $
 * Revision 6.4  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 * Revision 6.3  2001/06/06 21:15:37  wrdieter
 * Interface cleanup; all external functions begin with "chkpt_".
 *
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02  20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.2  2000/02/02 15:00:25  dieter
 * Added options argument to checkpoint_init.
 *
 * Revision 5.1  2000/02/01 23:37:32  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  2000/01/19 22:36:39  dieter
 * Made address pointers to chkpt_include_region and chkpt_exclude_region
 * const.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.4  1999/01/11  21:12:23  dieter
 * Added prototypes for chkpt_exclude_region and chkpt_include_region.
 *
 * Revision 2.3  1999/01/08  23:49:43  dieter
 * Added chkpt_block and chkpt_unblock to allow user code to be atomic
 * with respect to checkpoints.
 *
 * Revision 2.2  1999/01/06  23:22:00  dieter
 * Added support for callback functions.
 *
 * Revision 2.1  1998/12/22  15:16:28  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.5  1998/08/31  20:48:47  dieter
 * Pass a pointer to argc so it can be updated.
 *
 * Revision 1.4  1998/08/27  17:58:42  dieter
 * Checkpoint names are now automatically generated.
 *
 * Revision 1.3  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.2  1998/07/31  20:15:14  dieter
 * Pretty much everything is moved over from the old version of checkpointing.
 *
 * Revision 1.1  1998/07/31  13:38:57  dieter
 * Initial revision
 *
 */

#ifndef CHECKPOINT_H_
#define CHECKPOINT_H_

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define CHKPT_EXCL_REMAP    0
#define CHKPT_EXCL_NOREMAP  1

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct chkpt_opt {
  int period;			/* checkpoint interval (in seconds) */
  int restore:1;		/* restore state from a checkpoint */
  int async:1;			/* save checkpoints asynchronously */
  char *filebase;		/* base for checkpoint filenames */
} chkpt_opt_t;

typedef void (*chkpt_callback_func_t)(int chkpt_num, void *arg);

/* Pre-checkpoint functions are called in the opposite order they were
 * pushed (last pushed is first called).  Post-checkpoint and recovery
 * functions are called in the same order they are pushed (last pushed
 * is last called).
 */
typedef struct chkpt_callback {
  chkpt_callback_func_t pre_chkpt; /* function called before each checkpoint */
  chkpt_callback_func_t post_chkpt; /* function called after each checkpoint
				    * during normal operation (i.e., not
				    * during recovery
				    */
  chkpt_callback_func_t recovery; /* function called after recovery	     */
} chkpt_callback_t;

typedef int chkpt_exclude_opt_t;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int  chkpt_init(int *argc, char *argv[], chkpt_opt_t *opts);
int  chkpt_now(char *filename);
int  chkpt_restore_state(char *filename);

void chkpt_opt_init(chkpt_opt_t *opts);
void chkpt_get_opts(chkpt_opt_t *opts);
void chkpt_set_opts(chkpt_opt_t *opts);

int  chkpt_block(void);
int  chkpt_unblock(void);

long chkpt_callback_push(chkpt_callback_t *callback, void *arg);
int  chkpt_callback_pop(long callback_id);

int  chkpt_exclude_region(const void *start, size_t len,
			  chkpt_exclude_opt_t options);
int  chkpt_include_region(const void *start, size_t len);

#endif
