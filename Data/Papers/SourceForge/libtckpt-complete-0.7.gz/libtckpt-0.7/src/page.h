/*
 * page.h
 *
 * History
 * -------
 * $Log: page.h,v $
 * Revision 1.1  2001/03/19 21:14:34  dieter
 * Greatly expanded page.c.
 * Added cpspinlock.h for spinlocks that work inside sighandlers.
 *
 */
#ifndef PAGE_H
#define PAGE_H

int chkpt_cow_init(void);
int chkpt_build_page_table(void);
void chkpt_destroy_page_table(void);

#endif
