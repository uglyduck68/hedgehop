/*
 * page.c
 *
 * Code to handle page faults for doing asynchronous and incremental
 * checkpoints.
 *
 * Pages are stored in a segmented page table.  The structure is an
 * array of segments.  Each segment is an array of contiguous page
 * table entries.
 *
 *   +--------+   +--------+--------+--------+-----+---------+
 *   | start1 |-->| page 1 | page 2 | page 3 | ... | page m1 |
 *   | end1   |   +--------+--------+--------+-----+---------+
 *   +--------+   +--------+--------+--------+-----+---------+
 *   | start2 |-->| page 1 | page 2 | page 3 | ... | page m2 |
 *   | end2   |   +--------+--------+--------+-----+---------+
 *   +--------+   +--------+--------+--------+-----+---------+
 *   | start3 |-->| page 1 | page 2 | page 3 | ... | page m3 |
 *   | end3   |   +--------+--------+--------+-----+---------+
 *   +--------+
 *       .
 *       .
 *       .
 *   +--------+   +--------+--------+--------+-----+---------+
 *   | startn |-->| page 1 | page 2 | page 3 | ... | page mn |
 *   | endn   |   +--------+--------+--------+-----+---------+
 *   +--------+
 *   
 *
 *
 * History
 * -------
 * $Log: page.c,v $
 * Revision 1.2  2001/03/19 21:14:34  dieter
 * Greatly expanded page.c.
 * Added cpspinlock.h for spinlocks that work inside sighandlers.
 *
 * Revision 1.1  2000/10/20 21:02:44  dieter
 * Initial revision
 *
 */

#include <sys/mman.h>
#include <sched.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "debug.h"
#include "machif.h"

#include "sysio.h"		/* only needed for standalone */
#include "page.h"
#include "cpspinlock.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define COPYING_PAGE  0x01
#define COPIED_PAGE   0x02

#define CHKPT_MAX_BUF_PAGES  20	/* max # of pages to buffer when checkpointing
				 * with copy-on-write
				 */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/* state of a page */
typedef struct chkpt_state {
  int saved:1;			/* this page has been saved */
  int changed:1;		/* this pages has been changed since
				   that last checkpoint */
} chkpt_state_t;

/* a page table entry */
typedef struct chkpt_page_table_entry {
  int real_prot;		/* current protections of the page */
  int prog_prot;		/* the protections the program thinks
				   the page */
  chkpt_state_t state;		/* checkpointing state of the page */
  int sv_status;		/* save status */
  chkpt_spin_lock_t lock;	/* spin lock protecting sv_status */
} chkpt_page_table_entry_t;

/* a range of addresses covered by this entry */
typedef struct chkpt_page_range {
  caddr_t start;		/* start of range */
  caddr_t end;			/* end of range */
  chkpt_page_table_entry_t *pages; /* pages for this range */
} chkpt_page_range_t;

typedef struct chkpt_page_buf {
  int start;			/* index of first page */
  int end;			/* index of last page */
  caddr_t *page[CHKPT_MAX_BUF_PAGES];
} chkpt_page_buf_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

static chkpt_page_range_t *segments = NULL;
static int                 num_segments = 0;
static struct sigaction chkpt_orig_segv_action;

static chkpt_spin_lock_t   page_buf_lock = CHKPT_SPIN_LOCK_UNLOCKED;
static chkpt_page_buf_t    page_buf;
/* TODO: this should be dynamically allocated (probably with mmap)
   especially for large CHKPT_MAX_BUF_PAGES, but for now I do not want
   to worry about what happens when memory is not available at
   checkpoint time.
*/
/* ASSUME: 4096 byte page size */
static chkpt_spin_lock_t   page_pool_lock = CHKPT_SPIN_LOCK_UNLOCKED;
static char                page_pool_raw[(CHKPT_MAX_BUF_PAGES+1) * 4096];
static char               *page_pool;
static char               *next_free_page;

char pad[4096 * 3];
char *foo;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static void chkpt_install_segv_handler(void);
static void chkpt_segv_handler(int sig, siginfo_t *info, void *ucontext);
static int get_page(caddr_t **page);
static int release_page(caddr_t *page);
int chkpt_build_page_table(void);
static void chkpt_allocate_page_tables(chkpt_page_range_t *seg_table,
				       memmap_t *mapping,
				       int nmap);
static void chkpt_free_page_tables(chkpt_page_range_t *seg_table, int n_segs);
static void chkpt_init_page_tables(chkpt_page_range_t *seg_table,
				   memmap_t *mapping,
				   int nmap);
static int chkpt_page_lookup(void *addr, chkpt_page_table_entry_t **entry);

static int chkpt_page_buf_init(void);
static int chkpt_page_pool_init(void);

static int queue_page(caddr_t *page);
static int dequeue_page(caddr_t **page);

int main(int argc, char *argv[])
{
  int  pagesize;		/* size of a page */
  int  status;
  caddr_t *page;

  sysio_init();
  chkpt_cow_init();
  if (chkpt_build_page_table() < 0) {
    CRASH("could not build checkpointing page table\n");
  }

  pagesize = sysconf(_SC_PAGESIZE);

  foo = pad + pagesize;
  *foo = 'a';
  printf("*foo = %c, foo = %p\n", *foo, foo);
  status = mprotect((void *)((ptrint)foo & ~(pagesize - 1)), pagesize,
		    PROT_READ|PROT_EXEC);
  if (status < 0) {
    CRASH("mprotect failed: %s\n", strerror(errno));
  }

  *foo = 'b';
  printf("*foo = %c, foo = %p\n", *foo, foo);

  while(dequeue_page(&page) == 0) {
    printf("page = %p\n", page);
    release_page(page);
  }
  chkpt_destroy_page_table();

  return 0;
}

static void chkpt_install_segv_handler(void)
{
  int status;
  struct sigaction chkpt_segv_action;

  chkpt_segv_action.sa_sigaction = chkpt_segv_handler;
  sigemptyset(&chkpt_segv_action.sa_mask);
  chkpt_segv_action.sa_flags = SA_SIGINFO;

  status = sigaction(SIGSEGV, &chkpt_segv_action, &chkpt_orig_segv_action);
  if (status < 0) {
    CRASH("could not install chkpt SIGSEGV signal handler: %s",
	  strerror(errno));
  }
}

static void chkpt_segv_handler(int sig, siginfo_t *info, void *ucontext)
{
  int   pagesize;		/* size of a page */
  void *page_addr;
  chkpt_page_table_entry_t *page_entry;
  caddr_t *page_copy;

  if (info->si_code == SEGV_ACCERR) {
    pagesize = sysconf(_SC_PAGESIZE);

    page_addr = (void *)((ptrint)info->si_addr & ~(pagesize-1));
    if (chkpt_page_lookup(info->si_addr, &page_entry) < 0) {
      CRASH("page not found in page table\n");
    }

    /* magic stuff here */
    chkpt_spin_lock(&page_entry->lock);
    if (page_entry->sv_status & COPYING_PAGE) {
      /* someone else is saving this page, wait until they are done */
      chkpt_spin_unlock(&page_entry->lock);
      /* TODO: queue up waiting for page instead of busy waiting */
      while(!(page_entry->sv_status & COPIED_PAGE))
	sched_yield();
    } else {
      /* copy the page to be saved later and continue */
      page_entry->sv_status |= COPYING_PAGE;
      chkpt_spin_unlock(&page_entry->lock);

      while(get_page(&page_copy) != 0) {
	/* no pages available; wait for one */
	/* TODO: queue up waiting for page instead of busy waiting */
	sched_yield();
      }
      memcpy(page_copy, page_addr, pagesize);

      chkpt_spin_lock(&page_entry->lock);
      page_entry->sv_status |= COPIED_PAGE;
      chkpt_spin_unlock(&page_entry->lock);

      queue_page(page_copy);
      mprotect(page_addr, pagesize, page_entry->real_prot);
    }
  } else {
    /* If we don't know what to do, pass the segv to the original handler */
    if (chkpt_orig_segv_action.sa_handler == SIG_IGN) {
      return;
    } else if (chkpt_orig_segv_action.sa_handler == SIG_DFL) {
      fprintf(stderr, "Segmentation Fault\n");
      abort();
    } else {
      chkpt_orig_segv_action.sa_sigaction(sig, info, ucontext);
    }
  }
}

int chkpt_build_page_table(void)
{
  int       nmap;		/* number of mappings */
  memmap_t *mapping;		/* the mappings */
  int       map;		/* index into mapping */
  pid_t     mypid;		/* pid of this process */

  mypid = getpid();
  if (allocate_map_info(mypid) < 0) {
    CRASH("could not allocate space for mappings\n");
  }
  if (get_state_info(mypid, NULL, &nmap, &mapping) < 0) {
    CRASH("could not get memory map info from /proc\n");
  }

  num_segments = 0;
  if (nmap > 0) {
    /* this should always be true there should at least be 3 maps (code,
     * data, and stack)
     */

    /* count the number of non-contiguous segments */
    num_segments = 1;
    for(map = 1 ; map < nmap ; map++) {
      if (mapping[map-1].addr + mapping[map-1].len != mapping[map].addr) {
	num_segments++;
      }
    }

    /* allocate page table (if necessary) */
    if (segments == NULL) {
      segments = (chkpt_page_range_t *)malloc(sizeof(chkpt_page_range_t)
					      * num_segments);
      if (segments == NULL) {
	CRASH("could not allocate checkpoint segmented page table\n");
      }
      chkpt_allocate_page_tables(segments, mapping, nmap);
      chkpt_init_page_tables(segments, mapping, nmap);
    } else {
      CRASH("cannot call chkpt_build_page_table twice (yet)\n");
    }
  }

  return 0;
}

/* allocate page tables for each segment and initialize segments */
static void chkpt_allocate_page_tables(chkpt_page_range_t *seg_table,
				       memmap_t *mapping,
				       int nmap)
{
  int       map;		/* index into mapping */
  int       segment;		/* index into segment table */
  int       pagesize;		/* size of a page */
  int       num_pages;		/* number of pages in a page table */

  pagesize = sysconf(_SC_PAGESIZE);

  segment = 0;
  seg_table[0].start = mapping[0].addr;
  for(map = 1 ; map < nmap ; map++) {
    if (mapping[map-1].addr + mapping[map-1].len != mapping[map].addr) {
      seg_table[segment].end = mapping[map-1].addr + mapping[map-1].len;
      /* ASSUME: everything is nicely page aligned */
      num_pages = seg_table[segment].end - seg_table[segment].start;
      num_pages /= pagesize;
      seg_table[segment].pages = (chkpt_page_table_entry_t *)
	malloc(sizeof(chkpt_page_table_entry_t) * num_pages);
      if (seg_table[segment].pages == NULL) {
	CRASH("cannot allocate space for checkpoint page table\n");
      }
      segment++;
      seg_table[segment].start = mapping[map].addr;
    }
  }

  seg_table[segment].end = mapping[map-1].addr + mapping[map-1].len;
  /* ASSUME: everything is nicely page aligned */
  num_pages = (seg_table[segment].end - seg_table[segment].start) / pagesize;
  seg_table[segment].pages = (chkpt_page_table_entry_t *)
    malloc(sizeof(chkpt_page_table_entry_t) * num_pages);
  if (seg_table[segment].pages == NULL) {
    CRASH("cannot allocate space for checkpoint page table\n");
  }
}

void chkpt_destroy_page_table(void)
{
  chkpt_free_page_tables(segments, num_segments);
  free(segments);
}

static void chkpt_free_page_tables(chkpt_page_range_t *seg_table, int n_segs)
{
  int       segment;		/* index into segment table */

  for(segment = 0 ; segment < n_segs ; segment++) {
    free(seg_table[segment].pages);
  }
}

/* initialize page status */
static void chkpt_init_page_tables(chkpt_page_range_t *seg_table,
				   memmap_t *mapping,
				   int nmap)
{
  int map;			/* index into mapping */
  int segment;			/* index into segment table */
  int pagesize;			/* size of a page */
  int page;			/* index into page tables */
  int last_page;		/* last page in current mapping */
  chkpt_page_table_entry_t *page_table; /* array of pages */

  pagesize = sysconf(_SC_PAGESIZE);

  segment = 0;
  page = 0;
  page_table = seg_table[segment].pages;
  for(map = 0 ; map < nmap ; map++) {
    if (map > 0
	&& (mapping[map-1].addr + mapping[map-1].len != mapping[map].addr)) {
      segment++;
      page_table = seg_table[segment].pages;
      page = 0;
    }

    last_page = (mapping[map].addr + mapping[map].len
		 - seg_table[segment].start) / pagesize;
    while(page < last_page) {
      page_table[page].real_prot = mapping[map].prot;
      page_table[page].prog_prot = mapping[map].prot;
      page_table[page].state.saved = 0;
      page_table[page].state.changed = 0;
      page++;
    }
  }
}

static int chkpt_page_lookup(void *addr, chkpt_page_table_entry_t **entry)
{
  caddr_t caddr;
  int top;			/* upper bound on segment */
  int bottom;			/* lower bound on segment */
  int mid;
  int page_index;
  long pagesize;
  
  caddr = (caddr_t)addr;
  /* binary search for the segment */
  top = num_segments - 1;
  bottom = 0;
  mid = (top + bottom) / 2;

  while (top >= bottom
	 && (caddr < segments[mid].start || segments[mid].end <= caddr)) {
    if (caddr < segments[mid].start) {
      top = mid - 1;
    } else {
      bottom = mid + 1;
    }
    mid = (top + bottom) / 2;
  }

  if (caddr < segments[mid].start || segments[mid].end <= caddr) {
    return -1;
  }

  pagesize = sysconf(_SC_PAGESIZE);
  page_index = (caddr - segments[mid].start) / pagesize;
  *entry = segments[mid].pages + page_index;
  
  return 0;
}

/* call once at startup to init page table code */
int chkpt_cow_init(void)
{
  int status;

  chkpt_install_segv_handler();
  if ( (status = chkpt_page_buf_init()) != 0) {
    return status;
  }
  status = chkpt_page_pool_init();
  return status;
}

static int chkpt_page_buf_init(void)
{
  page_buf.start = 0;
  page_buf.end = 0;

  return 0;
}

static int chkpt_page_pool_init(void)
{
  long pagesize;
  char **end;
  char **next_free;

  pagesize = sysconf(_SC_PAGESIZE);

  page_pool = (char *)((((ptrint)page_pool_raw) + pagesize - 1)
		       & ~(pagesize - 1));
  end = (char **)((((ptrint)page_pool_raw) + sizeof(page_pool_raw))
		  & ~(pagesize - 1));
  next_free = (char **)page_pool;
  *next_free = NULL;
  for (next_free += pagesize ; next_free < end ; next_free += pagesize) {
    *next_free = ((char *)next_free) - pagesize;
  }
  next_free_page = ((char *)next_free) - pagesize;

  return 0;
}

static int get_page(caddr_t **page)
{
  int status;
  if (next_free_page != NULL) {
    chkpt_spin_lock(&page_pool_lock);
    *page = (caddr_t *)next_free_page;
    next_free_page = *((char **)next_free_page);
    chkpt_spin_unlock(&page_pool_lock);
    status = 0;
  } else {
    *page = NULL;
    status = -1;
  }
  
  return status;
}

static int release_page(caddr_t *page)
{
  char **next_free;

  next_free = (char **)page;
  chkpt_spin_lock(&page_pool_lock);
  *page = next_free_page;
  next_free_page = (char *)page;
  chkpt_spin_unlock(&page_pool_lock);
  
  return 0;
}

/* get in line at the end */
static int queue_page(caddr_t *page)
{
  int status = 0;

  chkpt_spin_lock(&page_buf_lock);
  if ((page_buf.end+1 % CHKPT_MAX_BUF_PAGES) != page_buf.start) {
    page_buf.page[page_buf.end] = page;
    page_buf.end = (page_buf.end + 1) % CHKPT_MAX_BUF_PAGES;
  } else {
    status = -1;
  }
  chkpt_spin_unlock(&page_buf_lock);

  return status;
}

/* get out of line at the start */
static int dequeue_page(caddr_t **page)
{
  int status = 0;

  chkpt_spin_lock(&page_buf_lock);
  if (page_buf.start != page_buf.end) {
    *page = page_buf.page[page_buf.start];
    page_buf.start = (page_buf.start + 1) % CHKPT_MAX_BUF_PAGES;
  } else {
    status = -1;
  }
  chkpt_spin_unlock(&page_buf_lock);

  return status;
}
