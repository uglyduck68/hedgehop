/*
 * cpstate.h
 *
 * Structures, macro definitions, and global variables related to the
 * process's state.
 *
 * History
 * -------
 * $Log: cpstate.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  2000/01/19 22:42:09  dieter
 * Added manager_env global variable (for thread manager stack
 * environment).
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.3  1999/01/20  01:57:35  dieter
 * Removed setcontext/getcontext code.  It was not any better than
 * sigsetjmp/siglongjmp.
 *
 * Revision 2.2  1998/12/22  15:37:03  dieter
 * Try getcontext/setcontext instead of sigsetjmp/siglongjmp.
 *
 * Revision 2.1  1998/12/22  15:36:39  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.1  1998/07/31  20:16:40  dieter
 * Initial revision
 *
 */

#ifndef CPSTATE_H_
#define CPSTATE_H_

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

sigjmp_buf chkpt_env;		/* stack environment of the main thread      */
#if OS == LINUX
extern sigjmp_buf manager_env;	/* stack environment of the manager thread   */
#endif

extern int chkpt_sigcnt;	/* number of items in chkpt_sigaction        */
				/* signal actions at time of checkpoint      */
extern struct sigaction *chkpt_sigaction;
				/* signals pending at the time of
				   the checkpoint                            */
extern sigset_t chkpt_sig_pending;

#endif /* CPSTATE_H_ */
