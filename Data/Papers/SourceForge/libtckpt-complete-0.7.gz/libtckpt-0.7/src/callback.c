/*
 * callback.c
 *
 * manage checkpoint callback functions.
 *
 * History
 * -------
 * $Log: callback.c,v $
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:37:32  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.1  1999/01/06  23:43:42  dieter
 * Files were created after FTCS paper so move to version 2 to
 * be consistent with other library code files.
 *
 * Revision 1.1  1999/01/06  23:20:38  dieter
 * Initial revision
 *
 */

#include "debug.h"
#include "checkpoint.h"
#include "callback.h"


/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct chkpt_callback_node {
  long 			      id;    /* callback function id number	     */
  chkpt_callback_t 	      funcs; /* callback function pointers 	     */
  void			     *arg;   /* argument to callback function	     */
  struct chkpt_callback_node *next;  /* next callback in list		     */
  struct chkpt_callback_node *prev;  /* previous callback in list	     */
} chkpt_callback_node_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/* callback list variables */
chkpt_callback_node_t *chkpt_callback_head = NULL;
chkpt_callback_node_t *chkpt_callback_tail = NULL;

/* next available id */
long chkpt_callback_id = 0;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

long next_callback_id(void);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

long chkpt_callback_push(chkpt_callback_t *callback, void *arg)
{
  chkpt_callback_node_t *new_callback;

  new_callback = (chkpt_callback_node_t *)malloc(sizeof(chkpt_callback_node_t));
  if (new_callback == NULL) {
    return -1;
  }

  new_callback->id = next_callback_id();
  new_callback->funcs = *callback;
  new_callback->arg = arg;
  new_callback->next = chkpt_callback_head;
  if(new_callback->next == NULL)
    chkpt_callback_tail = new_callback;
  else
    new_callback->next->prev = new_callback;
  chkpt_callback_head = new_callback;
  new_callback->prev = NULL;

  return new_callback->id;
}

long next_callback_id(void)
{
  /* For now just increment this varaible to get the next id number.
   * In theory it may wrap, but that is unlikely.
   */
  /* TODO: use a more robust id allocation method */
  chkpt_callback_id++;
  if(chkpt_callback_id < 0) {
    CRASH("ran out of checkpoint callback id numbers\n");
  }

  return chkpt_callback_id;
}

int chkpt_callback_pop(long callback_id)
{
  chkpt_callback_node_t *node;
  int result;

  result = -1;
  node = chkpt_callback_head;
  while(node != NULL && result != 0) {
    if(node->id == callback_id) {
      if(node->next != NULL) {
	node->next->prev = node->prev;
      } else {
	chkpt_callback_tail = node->prev;
      }
      if(node->prev != NULL) {
	node->prev->next = node->next;
      } else {
	chkpt_callback_head = node->next;
      }
      free(node);
      result = 0;
    } else {
      node = node->next;
    }
  }
  
  return result;
}

void pre_chkpt_callbacks(int chkpt_num)
{
  chkpt_callback_node_t *node;

  for(node = chkpt_callback_head ; node != NULL ; node = node->next) {
    if(node->funcs.pre_chkpt != NULL) {
      node->funcs.pre_chkpt(chkpt_num, node->arg);
    }
  }
}

void post_chkpt_callbacks(int chkpt_num)
{
  chkpt_callback_node_t *node;

  for(node = chkpt_callback_tail ; node != NULL ; node = node->prev) {
    if(node->funcs.post_chkpt != NULL) {
      node->funcs.post_chkpt(chkpt_num, node->arg);
    }
  }
}

void recovery_callbacks(int chkpt_num)
{
  chkpt_callback_node_t *node;

  for(node = chkpt_callback_tail ; node != NULL ; node = node->prev) {
    if(node->funcs.recovery != NULL) {
      node->funcs.recovery(chkpt_num, node->arg);
    }
  }
}


