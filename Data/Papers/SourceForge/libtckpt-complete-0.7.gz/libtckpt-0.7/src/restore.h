/*
 * restore.h
 *
 * History
 * -------
 * $Log: restore.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  2000/01/19 22:46:44  dieter
 * Added prototypes for restore_pending_signals.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:33:03  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.1  1998/07/31  20:16:40  dieter
 * Initial revision
 *
 */

#ifndef RESTORE_H_
#define RESTORE_H_

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void restore_pending_signals(sigset_t *pending);

#endif /* RESTORE_H_ */
