/*
 * htest.c
 *
 * program to test hash.c
 *
 * History
 * -------
 * $Log: htest.c,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 2.1  1998/12/22  15:25:03  dieter
 * verstion that worked for ftcs paper.
 *
 * Revision 1.1  1998/08/10  19:18:12  dieter
 * Initial revision
 *
 */

#include <stdio.h>

#include "hash.h"

#define HTABLE_SZ 100

extern void  htable_dump( htable_t *htable );

void print_string_table( htable_t *htable );
int print_string( long key, void *value, void *arg );

int main( int arc, char *argv[] )
{
  htable_t *tab;
  char *str;

  tab = new_htable( HTABLE_SZ );
  htable_dump( tab );

  if( htable_find( tab, 6, (void **)&str ) == 0 ) {
    printf( "\nitem 6 is \"%s\"\n", str );
  } else {
    printf( "\ncannot find item 6\n" );
  }

  htable_add( tab, 4, "hello" );
  htable_add( tab, 5, "world" );
  htable_add( tab, 6, "This is" );

  htable_add( tab, 105, "a test" );

  print_string_table( tab );

  if( htable_find( tab, 6, (void **)&str ) == 0 ) {
    printf( "\nitem 6 is \"%s\"\n", str );
  } else {
    printf( "\ncannot find item 6\n" );
  }

  htable_delete( tab, 5 );

  print_string_table( tab );
  if( htable_find( tab, 5, (void **)&str ) == 0 ) {
    printf( "\nitem 5 is \"%s\"\n", str );
  } else {
    printf( "\ncannot find item 5\n" );
  }

  
  return 0;
}

void print_string_table( htable_t *htable )
{
  printf( "key        value\n" );
  printf( "---------  -------------\n" );
  htable_forall( htable, print_string, NULL );
}

int print_string( long key, void *value, void *arg )
{
  printf( "%8ld:  %s\n", key, (char *)value );
  
  return 0;
}

