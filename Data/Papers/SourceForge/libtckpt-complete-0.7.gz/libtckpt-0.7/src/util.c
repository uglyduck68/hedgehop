/* util.c
 *
 * utility functions that are useful for random different things
 *
 * History
 * -------
 * $Log: util.c,v $
 * Revision 6.1  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 */

#include <stdlib.h>

#include "util.h"

/* convert an unsigned long to a string; outside of the signal handler
 * sprintf will convert ints to strings in a more general way.  Alas,
 * sprintf locks at least one mutex, so it cannot be called inside a
 * signal handler.
 */
char *ultostr(char *str, int len, unsigned long num)
{
  char *end;
  char *next;
  unsigned long div;

  if (len < 2) {
    return NULL;
  }

  if (num == 0) {
    str[0] = '0';
    str[1] = '\0';
    return str + 1;
  }

  end = str;
  for (div = num ; div != 0 ; div /= 10) {
    end++;
  }
  
  if (end > str + len - 1) {
    return NULL;
  }

  *end = '\0';
  next = end - 1;
  for (div = num ; div != 0 ; div /= 10) {
    *next-- = '0' + div % 10;
  }

  return end;
}

