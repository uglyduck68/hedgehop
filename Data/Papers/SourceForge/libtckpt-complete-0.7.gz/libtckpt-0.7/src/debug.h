/*
 * debug.h
 *
 * debugging functions and macros
 *
 * History
 * -------
 * $Log: debug.h,v $
 * Revision 6.6  2001/02/06 18:47:15  dieter
 * mprint does not take a file parameter.
 *
 * Revision 6.5  2000/10/20 21:20:38  dieter
 * Added CRASH and CRASH_ERR macros.
 *
 * Revision 6.4  2000/10/20 20:41:09  dieter
 * Added ERROR macro.
 *
 * Revision 6.3  2000/05/08 19:49:28  dieter
 * Added SIGDBG for debugging in the signal handler.
 *
 * Revision 6.2  2000/05/08 19:09:36  dieter
 * Added fill_with_trash
 * Cleaned up CRASH macros a bit.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  2000/01/28 21:14:51  dieter
 * Use variable number of paramters with debug statments.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:25:03  dieter
 * verstion that worked for ftcs paper.
 *
 * Revision 1.2  1998/12/11  21:46:37  dieter
 * fixed up DBG_PRINTF when debugging is off
 *
 * Revision 1.1  1998/12/03  19:35:04  dieter
 * Initial revision
 *
 */

#ifndef DEBUG_H
#define DEBUG_H

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if BUILD_FOR_UNIFY != 1
#define ASSERT(cond) assert(cond)
#define ERROR(msg...) \
{ \
  fprintf(stderr, "%s:%d: ", __FILE__, __LINE__); \
  fprintf(stderr, msg); \
}
#define CRASH(msg...) \
{ \
  fprintf(stderr, "%s:%d: ", __FILE__, __LINE__); \
  fprintf(stderr, msg); \
  fprintf(stderr, "\n"); \
  abort(); \
}

#define CRASH_ERR(msg...) \
{ \
  fprintf(stderr, "%s:%d: ", __FILE__, __LINE__); \
  fprintf(stderr, msg); \
  fprintf(stderr, ": %s\n", strerror(errno)); \
  abort(); \
}
#else
extern void mprint(char *fmt, ...);
extern void _unify_abort(int val, char *file, int line);

#define ASSERT(cond) {if (!(cond)) CRASH("assert failed: " #cond " is false"); }
#define ERROR(msg...) \
{ \
  mprint("%s:%d: ", __FILE__, __LINE__); \
  mprint(msg); \
}
#define CRASH(msg...) \
{ \
  mprint("%s:%d: ", __FILE__, __LINE__); \
  mprint(msg); \
  mprint("\n"); \
  _unify_abort(1, __FILE__, __LINE__); \
}

#define CRASH_ERR(msg...) \
{ \
  mprint("%s:%d: ", __FILE__, __LINE__); \
  mprint(msg); \
  mprint(": %s\n", strerror(errno)); \
  _unify_abort(1, __FILE__, __LINE__); \
}

#endif

#ifdef DEBUG
#define DBG_PRINTF(msg...) printf(msg)
#else
#define DBG_PRINTF(msg...) {}
#endif

#ifdef SIGHANDLER_DEBUG
#define SIGHDLR_DBG(msg...) fprintf(stderr, msg)
#else
#define SIGHDLR_DBG(msg...) {}
#endif

/* safe to call from the signal handler */
#define SIGDBG(msg) write(1, msg, strlen(msg))

void err_printf(const char *format, ...);
void fill_with_trash(const void *addr, size_t len);

#endif

