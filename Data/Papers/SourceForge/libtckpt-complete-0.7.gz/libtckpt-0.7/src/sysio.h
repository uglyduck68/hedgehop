/*
 * sysio.h
 *
 * Direct interface to system I/O funcions (through the C library).
 *
 * History
 * -------
 * $Log: sysio.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  2000/01/19 22:48:51  dieter
 * Added pipe support.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:34:56  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.1  1998/08/25  20:18:04  dieter
 * Initial revision
 *
 */

#ifndef SYSIO_H
#define SYSIO_H

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

extern int (*sys_open)(const char *path, int oflag, /* mode_t mode */ ...);
extern int (*sys_close)(int fildes);
extern int (*sys_dup)(int filedes);
extern int (*sys_dup2)(int filedes, int filedes2);
extern int (*sys_pipe)(int fliedes[2]);

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int  sysio_init(void);

#endif
