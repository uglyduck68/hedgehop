/*
 * cpspinlock.h
 *
 * spinlocks (stolen from linux 2.2.16 kernel headers with minor modifications)
 *
 * History
 * -------
 * $Log: cpspinlock.h,v $
 * Revision 1.1  2001/03/19 21:14:34  dieter
 * Greatly expanded page.c.
 * Added cpspinlock.h for spinlocks that work inside sighandlers.
 *
 */

#ifndef CPSPINLOCK_H
#define CPSPINLOCK_H

typedef struct chkpt_spinlock {
  volatile unsigned int lock;
} chkpt_spin_lock_t;

#define CHKPT_SPIN_LOCK_UNLOCKED (chkpt_spin_lock_t) { 0 }

#define chkpt_spin_lock_init(x)	do { (x)->lock = 0; } while(0)

typedef struct { unsigned long a[100]; } __chkpt_dummy_lock_t;
#define __chkpt_dummy_lock(lock) (*(__chkpt_dummy_lock_t *)(lock))

#define chkpt_spin_lock_string \
	"\n1:\t" \
	"lock ; btsl $0,%0\n\t" \
	"jc 2f\n" \
	".section .text.lock,\"ax\"\n" \
	"2:\t" \
	"testb $1,%0\n\t" \
	"jne 2b\n\t" \
	"jmp 1b\n" \
	".previous"

#define chkpt_spin_unlock_string \
	"lock ; btrl $0,%0"

#define chkpt_spin_lock(lock) \
__asm__ __volatile__( \
	chkpt_spin_lock_string \
	:"=m" (__chkpt_dummy_lock(lock)))

#define chkpt_spin_unlock(lock) \
__asm__ __volatile__( \
	chkpt_spin_unlock_string \
	:"=m" (__chkpt_dummy_lock(lock)))

/* #define chkpt_spin_trylock(lock) (!test_and_set_bit(0,(lock))) */

#endif /* CPSPINLOCK_H */
