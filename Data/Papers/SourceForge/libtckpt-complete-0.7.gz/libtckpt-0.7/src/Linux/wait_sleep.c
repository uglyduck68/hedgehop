/*
 * sleep_wait.c
 *
 * Functions to handle waiting for a process to sleep
 *
 * History
 * -------
 * $Log: wait_sleep.c,v $
 * Revision 6.1  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 */

#include <fcntl.h>
#include <ctype.h>
#include <limits.h>
#include <sched.h>
#include <string.h>
#include <unistd.h>

#include "debug.h"
#include "sysio.h"
#include "proc.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int get_status(int fd);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int wait_for_sleep(pid_t pid)
{
  int status;
  int fd;

  do {
    sched_yield();
    if ( (fd = open_proc_file(pid, "stat", O_RDONLY)) < 0) {
      CRASH_ERR("cannot open stat file stat in /proc for pid %d", pid);
    }
    status = get_status(fd);
    if (sys_close(fd) < 0) {
	CRASH_ERR("error closing proce file\n");
    }
  } while (status != 'S');
  
  return 0;
}


int get_status(int fd)
{
  char stat;
  int  paren_cnt;
  ssize_t buf_size;

  /* It would be more efficient to read a big buffer full of bytes,
   * but there is no guarantee the buffer will hold all the status
   * information.  Processing multiple buffers is a PITA so instead
   * read just one character at a time.  Hopefully it is not too bad
   * because /proc is all in memory.  Yes, it would be nice to just
   * use fgetc, but that is not an option because fgetc locks a
   * mutex and this is called in a signal handler.  I could write
   * my own fgetc, but that would be a lot of work for potentially
   * little gain.
   */
  /* ASSUME: we read the right number of bytes, the /proc file
   * is well formed and the program does not have '(' or ')' in
   * its filename.
   */
  /* skip the pid and spaces */
  do {
    if ( (buf_size = read(fd, &stat, 1)) < 0) {
      return -1;
    }
  } while(stat != '(');

  /* skip the filename and following spaces */
  paren_cnt = 1;
  do {
    if ( (buf_size = read(fd, &stat, 1)) < 0) {
      return -1;
    }
    if (stat == '(') {
      paren_cnt++;
    } else if (stat == ')') {
      paren_cnt--;
    }
  } while(paren_cnt > 0);

  /* eat spaces */
  do {
    if ( (buf_size = read(fd, &stat, 1)) < 0) {
      return -1;
    }
  } while(isspace(stat));

  return stat;
}
