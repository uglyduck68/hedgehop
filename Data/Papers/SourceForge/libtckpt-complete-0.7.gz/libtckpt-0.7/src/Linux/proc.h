/*
 * proc.h
 *
 * functions that are generally useful for accessing /proc
 *
 * History
 * -------
 * $Log: proc.h,v $
 * Revision 6.1  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 */
int open_proc_file(pid_t pid, char *file, mode_t mode);
