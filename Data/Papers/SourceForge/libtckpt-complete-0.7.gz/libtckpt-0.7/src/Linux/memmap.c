/*
 * memmap.c
 *
 * This file contains functions that get the memory mapping
 * information from Linux and puts it in a machine independent
 * format.
 *
 * History
 * -------
 * $Log: memmap.c,v $
 * Revision 6.4  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 * Revision 6.3  2001/02/06 18:48:21  dieter
 * Use chkpt_write_all to save mappings.
 *
 * Revision 6.2  2000/05/08 19:10:18  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:12:37  dieter
 * Released version 0.6
 *
 * Revision 5.1  2000/02/01 23:40:29  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 1.6  2000/02/01 19:37:34  dieter
 * Removed open_proc_file.  It will never be used.
 *
 * Revision 1.5  2000/01/19 22:26:56  dieter
 * Use strtoul instead of strtol because addresses may be bigger than 0x80000000
 *
 * Revision 1.4  2000/01/12 19:14:26  dieter
 * Allocate checkpointing memory maps outside the signal handler.
 * Removed calls to sprintf and sscanf in functions called from the
 * signal handler.  They call pthread_mutex_lock, which is not
 * async-signal safe.
 *
 * Revision 1.3  1999/11/07 16:24:38  dieter
 * Added code to read lines from proc files without calling stdio file
 * routines.  The stdio routines use mutexes and therefore cannot be
 * called in a signal handler.
 *
 * Revision 1.2  1999/11/01 20:55:09  dieter
 * set brkbase, brklen, stkbase, and stklen.
 *
 * Revision 1.1  1999/10/21 22:53:01  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/procfs.h>
#include <sys/mman.h>
#include <limits.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "memdebug.h"
#include "debug.h"
#include "machif.h"
#include "save.h"
#include "exclude.h"
#include "proc.h"
#include "sysio.h"
#include "util.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define NMAP_FUDGE 4
#define MAP_BUF_MAX (128+PATH_MAX) /* max length of a /proc/xx/maps line     */
#define FILE_BUF_SIZE  4096

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct file_buf {
  int      fd;
  off_t    pos;
  size_t   size;
  char     buf[FILE_BUF_SIZE];
} file_buf_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

static memmap_t *chkpt_maps = NULL;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static char *fbuf_getline(char *line, int size, file_buf_t *fbuf);
static void advance_fbuf(file_buf_t *fbuf, int adv);
static int refill_fbuf(file_buf_t *fbuf);

static int parse_mapping(memmap_t *map, char *line);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

/* count number of maps (i.e., number of lines in /proc/pid/maps) */
static int count_maps(pid_t pid)
{
  int   fd;
  char  buf[MAP_BUF_MAX];
  int   n_read;
  int   line_cnt;
  char *cur_char;

  if ( (fd = open_proc_file(pid, "maps", O_RDONLY)) == -1) {
    CRASH_ERR("cannot open map file for %d", pid);
    return -1;
  }

  line_cnt = 0;
  while((n_read = read(fd, buf, MAP_BUF_MAX)) != 0) {
    cur_char = buf;
    while(n_read > 0) {
      if (*cur_char++ == '\n') {
	line_cnt++;
      }
      n_read--;
    }
  }

  sys_close(fd);

  return line_cnt;
}

int get_state_info( pid_t pid, proc_status_t *proc_status, int *nmap,
		    memmap_t **mapping )
{
  int      fd;			/* file descriptor associated with process   */
  file_buf_t fbuf;
  int      cnt;			/* generic loop index		 	     */
  char     buf[MAP_BUF_MAX];
  caddr_t  brk_end;
  caddr_t  stk_addr;		/* address of something on the stack */
  caddr_t  start;
  caddr_t  end;

  /* determine the number of mappings */
  if ( (*nmap = count_maps(pid)) < 0) {
    fprintf(stderr, "could not determine number of maps for %d\n", pid);
    return *nmap;
  }

  *mapping = chkpt_maps;

  if ( (fd = open_proc_file(pid, "maps", O_RDONLY)) == -1) {
    fprintf(stderr, "error opening proc file for pid %d\n", pid);
    perror("open");
    return -1;
  }
  fbuf.fd = fd;
  fbuf.pos = 0;
  fbuf.size = 0;

  brk_end = sbrk(0);
  stk_addr = (caddr_t)&stk_addr;
  /* read memory mapping info to memmap structure */
  for( cnt = 0 ; fbuf_getline(buf, MAP_BUF_MAX, &fbuf) != NULL ; cnt++ ) {
    /* check for growth in number of mappings */
    if (cnt >= *nmap) {
      if (cnt < *nmap + 1 + NMAP_FUDGE) {
	fprintf(stderr, "number of mappings grew, still ok\n");
      } else {
	fprintf(stderr, "number of mappings grew, overflowing array\n");
	exit(-1);
      }
    }
    parse_mapping(((*mapping) + cnt), buf);
    start = (*mapping)[cnt].addr;
    end = start + (*mapping)[cnt].len;

    if (proc_status != NULL) {
      /* check if brk is in this mapping */
      if (start < brk_end && brk_end <= end) {
	proc_status->brkbase = start;
	proc_status->brklen = end - start;
      }
      
      /* check if stack is in this segment */
      /* ASSUME: this thread is the main thread */
      if (start < stk_addr && stk_addr <= end) {
	proc_status->stkbase = start;
	proc_status->stksize = end - start;
      }
    }
  }

  sys_close(fd);

  return 0;
}

/* parse the mapping from a line in /proc/pid/maps file */
static int parse_mapping(memmap_t *map, char *line)
{
  caddr_t  end;
  char    *next_parse;

  /* would like to use :

     sscanf(line, "%p-%p %5s %lx %*d:%*d %*d %*s",
            &start, &end, prot_str, &offset);

   * but sscanf is not safe in a signal handler because it
   * calls pthread_mutex_lock.
   */
  /* ASSUME: a pointer will fit in a long */
  /* TODO: replace asserts with helpful error messages */
  map->addr = (caddr_t)strtoul(line, &next_parse, 16);
  ASSERT(*next_parse == '-');
  next_parse++;
  end = (caddr_t)strtoul(next_parse, &next_parse, 16);
  map->len      = end - map->addr;

  ASSERT(*next_parse == ' ');
  next_parse++;
  
  map->prot = PROT_NONE;
  map->prot |= (*next_parse++ == 'r') ? (PROT_READ)  : 0;
  map->prot |= (*next_parse++ == 'w') ? (PROT_WRITE) : 0;
  map->prot |= (*next_parse++ == 'x') ? (PROT_EXEC)  : 0;
  next_parse += 3;

  map->pagesize = sysconf(_SC_PAGESIZE);

  map->offset = strtoul(next_parse, &next_parse, 16);
  map->remap = 1;

  /* initialize now so that compute_mapping_offets can look at type */
  map->type = 0;
  /* do not really need to set these now, but initialize them anyway */
  map->file_offset = 0;
  
  return 0;
}

/* need to allocate a big enough array to handle all the mappings even
 * after regions have been excluded.  Excluded regions might add 1 or
 * 2 new mappings depending on where they fall.
 */
int allocate_map_info(pid_t pid)
{
  int nmap;
  int total_nmap;
  size_t size;

  /* determine the number of mappings */
  if ( (nmap = count_maps(pid)) < 0) {
    fprintf(stderr, "could not determine number of maps for %d\n", pid);
    return nmap;
  }

  /* need to allocate a big enough array to handle all the mappings even
   * after regions have been excluded.  Each excluded region might add
   * one additional mapping.
   */
  size = (nmap + 1 + NMAP_FUDGE) * sizeof(memmap_t);
  if (chkpt_maps == NULL) {
    chkpt_maps = (memmap_t *)malloc(size);
  } else {
    chkpt_maps = realloc(chkpt_maps, size);
  }
  if (chkpt_maps == NULL) {
    fprintf(stderr, "could not allocate mapping list\n");
    return -1;
  }

  if ( (get_state_info(getpid(), NULL, &nmap, &chkpt_maps)) < 0) {
    CRASH_ERR("error reading maps\n");
  }
  
  total_nmap = chkpt_count_excl_maps(nmap, chkpt_maps);

  if (total_nmap != nmap) {
    size = (total_nmap + 1 + NMAP_FUDGE) * sizeof(memmap_t);
    if ( (chkpt_maps = (memmap_t *)realloc(chkpt_maps, size)) == NULL) {
      CRASH_ERR("cannot allocate maps\n");
    }
  }

  return 0;
}

void free_map_info(void)
{
  free(chkpt_maps);
}

static char *fbuf_getline(char *line, int size, file_buf_t *fbuf)
{
  char *str;
  int   len;

  refill_fbuf(fbuf);
  if (fbuf->size == 0) {
    return NULL;
  }
  do {
    str = memchr(fbuf->buf + fbuf->pos, '\n', fbuf->size);
    if (str != NULL) {
      /* found a '\n'; will it fit in line?*/
      len = str - (fbuf->buf + fbuf->pos) + 1;
      if(len < size) {
	memcpy(line, fbuf->buf + fbuf->pos, len);
	line[len] = '\0';
	advance_fbuf(fbuf, len);
      } else {
	memcpy(line, fbuf->buf + fbuf->pos, size - 1);
	line[size-1] = '\0';
	advance_fbuf(fbuf, size - 1);
      }
    } else {
      if (fbuf->size < size) {
	memcpy(line, fbuf->buf + fbuf->pos, fbuf->size);
	size -= fbuf->size;
	line += fbuf->size;
	line[0] = '\0';
	advance_fbuf(fbuf, fbuf->size);
	refill_fbuf(fbuf);
	if (fbuf->size == 0) {
	  size = 0;
	}
      } else {
	memcpy(line, fbuf->buf + fbuf->pos, size - 1);
	line[size-1] = '\0';
	size = 0;
	advance_fbuf(fbuf, size - 1);
      }
    }
  } while(str == NULL && size > 0);

  return line;
}

static void advance_fbuf(file_buf_t *fbuf, int adv)
{
  fbuf->size -= adv;
  fbuf->pos += adv;
  if (fbuf->pos == FILE_BUF_SIZE) {
    fbuf->pos = 0;
  } else if(fbuf->pos > FILE_BUF_SIZE) {
    fprintf(stderr, "advanced past end of buffer\n");
    exit(-1);
  }
}

static int refill_fbuf(file_buf_t *fbuf)
{
  int n_read = 0;
  
  if(fbuf->size == 0) {
    n_read = read(fbuf->fd, fbuf->buf + fbuf->pos, FILE_BUF_SIZE - fbuf->pos);
    if (n_read != -1) {
      fbuf->size = n_read;
    }
  }

  return n_read;
}

int  write_mapping_data( int chkpt_fd, pid_t pid, int nmap, memmap_t *mapping )
{
  int map;

  for( map = 0 ; map < nmap ; map++ ) {
    if( mapping[map].type != SEG_CODE && mapping[map].type != SEG_EXCL ) {

      /* need to make sure the memory is readable before writing it */
      if( (mapping[map].prot & PROT_READ) == 0 ) {
	mprotect( mapping[map].addr, mapping[map].len, PROT_READ );
      }

      lseek(chkpt_fd, mapping[map].file_offset, SEEK_SET);
      chkpt_write_all(chkpt_fd, mapping[map].addr, mapping[map].len);

      if( (mapping[map].prot & PROT_READ) == 0 ) {
	mprotect( mapping[map].addr, mapping[map].len, mapping[map].prot );
      }

    }
  }

  return 0;
}
