/*
 * machine dependent I/O stuff
 *
 * History
 * -------
 * $Log: libcio.c,v $
 * Revision 6.1  2000/05/02 20:12:37  dieter
 * Released version 0.6
 *
 * Revision 5.1  2000/02/01 23:40:29  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 1.1  1999/10/21 22:53:01  dieter
 * Initial revision
 *
 */


#include <stdio.h>

int get_file_fd(FILE *fp)
{
  return fp->_fileno;
}
