/*
 * proc.c
 *
 * functions to manipulate proc files.
 *
 * History
 * -------
 * $Log: proc.c,v $
 * Revision 6.1  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include "debug.h"
#include "proc.h"
#include "sysio.h"
#include "util.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/* biggest filename size we might need:
 *   6 for "/proc/" + 10 for pid + 10 for "/whatever" + 1 for '\0'
 */
#define PROC_PATH_MAX 32

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

extern char *stpcpy(char *dest, char *src); /* should be in string.h */

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int open_proc_file(pid_t pid, char *file, mode_t mode)
{
  /* statically allocate because this might be called from a signal handler */
  char buf[PROC_PATH_MAX];
  char *next;

  next = stpcpy(buf, "/proc/");
  next = ultostr(next, PROC_PATH_MAX - (next - buf), pid);
  if (strlen(file) + next - buf + 2 > PROC_PATH_MAX) {
    CRASH("/proc/%d/%s is too big to fit in PROC_PATH_MAX\n", pid, file);
  }
  strcat(buf, "/");
  strcat(buf, file);
  return sys_open(buf, O_RDONLY);
}
