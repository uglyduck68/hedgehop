/*
 * libcio.h
 *
 * History
 * -------
 * $Log: libcio.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.2  1999/10/21 22:49:20  dieter
 * Changes to compile with Linux
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:26:33  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.1  1998/09/01  15:56:54  dieter
 * Initial revision
 *
 */

#ifndef LIBCIO_H
#define LIBCIO_H

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

extern FILE *(*libc_fopen)(const char *filename, const char *type);
extern FILE *(*libc_freopen)(const char *filename, const char *type, FILE *stream);

extern int   (*libc_fclose)(FILE *stream);

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int libcio_init(void);


#endif /* LIBCIO_H */
