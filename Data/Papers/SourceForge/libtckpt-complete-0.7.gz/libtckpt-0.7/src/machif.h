/*
 * machif.h
 *
 * machif is the interface between the machine dependent and machine
 * independent checkpointing code.
 *
 * History
 * -------
 * $Log: machif.h,v $
 * Revision 6.5  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 * Revision 6.4  2000/10/20 20:45:35  dieter
 * Updated for new blocking barrier support.
 *
 * Revision 6.3  2000/05/12 03:38:08  dieter
 * Fixed synchronization bug where recovery had one too few barriers.
 *
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.3  2000/01/19 22:44:54  dieter
 * Added ptrint type.
 * Added prototypes for several functions.
 *
 * Revision 4.2  1999/10/21 22:39:29  dieter
 * Added get_file_fd and little endian seg type descriptors for Linux
 * support.
 *
 * Revision 4.1  1999/08/02 15:27:02  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.2  1999/01/20  00:13:34  dieter
 * Added stack size to process status structure.
 * Added prototypes for static versions of pread and mprotect.
 *
 * Revision 2.1  1998/12/22  15:26:33  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.2  1998/07/31  20:15:14  dieter
 * Pretty much everything is moved over from the old version of checkpointing.
 *
 * Revision 1.1  1998/07/31  13:38:01  dieter
 * Initial revision
 *
 */

#ifndef MACHIF_H_
#define MACHIF_H_

#include "config.h"

#include <sys/types.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*
 * This structure contains information about a memory mapping (segment)
 */
typedef struct memmap {
  caddr_t        addr;		/* starting address of the mapping */
  unsigned long  len;		/* length of the mapping (in bytes) */
  unsigned long  pagesize;	/* size of the a page in the mapping */
  off_t          offset;	/* offset into mapped object */
  long           prot;		/* protections and attributes */
  unsigned long  remap:1;	/* remap this mapping? or just leave hole? */
  unsigned long  type;		/* type identifier for the mapping */
  size_t         file_offset;	/* offset into checkpoint file */
} memmap_t;

/*
 * This structure contains information about the whole process
 */
typedef struct proc_status {
  caddr_t        brkbase;	/* base address of the heap */
  unsigned long  brklen;	/* length of the heap (in bytes) */
  caddr_t        stkbase;	/* base address of the stack  */
  size_t	 stksize;	/* length of the stack segment */
} proc_status_t;

typedef unsigned long ptrint;	/* an integer large enough to hold a pointer */

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/* types of segments */
#ifdef BIGENDIAN_WORDS
#define SEG_CODE  0x434f4445	/* code segment */
#define SEG_DATA  0x44415441	/* data segment */
#define SEG_HEAP  0x48454150	/* heap segment */
#define SEG_STCK  0x5354434b	/* stack segment */
#define SEG_TSTK  0x5453544b	/* thread stack */
#define SEG_DYNM  0x44594e4d	/* dynamicly loaded segment */
#define SEG_EXCL  0x4558434c	/* excluded segment (do not save, but remap) */
#else
#define SEG_CODE  0x45444f43	/* code segment */
#define SEG_DATA  0x41544144	/* data segment */
#define SEG_HEAP  0x50414548	/* heap segment */
#define SEG_STCK  0x4b435453	/* stack segment */
#define SEG_TSTK  0x4b545354	/* thread stack */
#define SEG_DYNM  0x4d4e5944	/* dynamicly loaded segment */
#define SEG_EXCL  0x4c435845	/* excluded segment (do not save, but remap) */
#endif

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

caddr_t smmap(caddr_t addr, size_t len, int prot, int flags, int fildes,
	      off_t off);

ssize_t sread(int fildes, void *buf, size_t nbyte);
ssize_t spread(int fildes, void *buf, size_t nbyte, off_t offset);
int     smprotect(void *addr, size_t len, int prot);
int     ssched_yield(void);
int	ssigsuspend(const sigset_t *mask);

int  get_state_info( pid_t pid, proc_status_t *status, int *nmap,
		    memmap_t **mapping );

int  get_maps( pid_t pid, int *nmap, memmap_t **mapping );

int  write_mapping_data( int chkpt_fd, pid_t pid,
			 int nmap, memmap_t *mapping );

int get_file_fd(FILE *fp);

int allocate_map_info(pid_t pid);
void free_map_info(void);

int wait_for_sleep(pid_t pid);

#endif /* MACHIF_H_ */
