/*
 * checkpoint.c
 *
 * This file contains the machine independent part of the
 * checkpointing code that saves and restores the process's state.
 *
 * History
 * -------
 * $Log: checkpoint.c,v $
 * Revision 6.8  2001/07/06 23:08:59  wrdieter
 * Fixed asynchronous checkpointing synchronization (problem #429309)
 *
 * Revision 6.7  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 * Revision 6.6  2001/06/06 21:15:37  wrdieter
 * Interface cleanup; all external functions begin with "chkpt_".
 *
 * Revision 6.5  2001/02/13 21:44:39  dieter
 * Removed static modifier from chkpt_print_opts to avoid warnings about
 * it not being called.  May want to add it back later to avoid namespace
 * pollution.
 *
 * Revision 6.4  2001/02/13 21:41:25  dieter
 * Added support for setting checkpointing options with the CHKPTOPTS
 * environment variable.
 *
 * Revision 6.3  2000/10/26 00:05:23  dieter
 * sysconf(_SC_RTSIG_MAX) reports the wrong number of signals for Linux, so
 * use SIGRTMAX Instead.
 *
 * Revision 6.2  2000/10/20 20:55:20  dieter
 * Better recovery code stubbed in, but not working yet.
 * Return whether the process is recovering from do_checkpoint.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.3  2000/05/02 14:27:41  dieter
 * Moved callbacks to checkpoint thread instead of signal handler.
 *
 * Revision 5.2  2000/02/02 15:00:16  dieter
 * Added options argument to checkpoint_init.
 *
 * Revision 5.1  2000/02/01 23:37:32  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.6  2000/01/25 20:42:31  dieter
 * Added code to time each checkpoint.
 *
 * Revision 4.5  2000/01/19 22:34:47  dieter
 * Many changes for Linux support.
 * Index chkpt_sigaction properly.
 * Call pthread_chkpt_precreate.
 * Handle pending signals on a per thread basis.
 *
 * Revision 4.4  1999/10/28 18:39:09  dieter
 * Fixed up handle_args so it works with gnu getopt and sun getopt.
 *
 * Revision 4.3  1999/10/21 22:42:02  dieter
 * Minor changes to compile with Linux.
 *
 * Revision 4.2  1999/10/08 20:40:01  dieter
 * Removed include of sys/fault.h.  Apparently it is unneeded.
 *
 * Revision 4.1  1999/08/02 15:27:02  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.2  1999/04/20  15:08:56  dieter
 * Use mutexes instead of pthread_sigmask to prevent signals when
 * locking a mutex.
 * Intercept _mutex_lock and _mutex_unlock to handle libraries that use mutexes.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.9  1999/01/20  17:18:04  dieter
 * Added -b option to specify checkpoint file basename (checkpoint number
 * is appended).
 *
 * Revision 2.8  1999/01/20  01:57:55  dieter
 * Removed setcontext/getcontext code.  It was not any better than
 * sigsetjmp/siglongjmp.
 *
 * Revision 2.7  1999/01/20  00:15:56  dieter
 * Print out stack size when printing mappnigs.
 *
 * Revision 2.6  1999/01/13  21:44:18  dieter
 * Added memory exclusion.
 *
 * Revision 2.5  1999/01/08  23:49:39  dieter
 * Added chkpt_block and chkpt_unblock to allow user code to be atomic
 * with respect to checkpoints.
 *
 * Revision 2.4  1999/01/06  23:22:20  dieter
 * Added support for user supplied callback functions.
 *
 * Revision 2.3  1999/01/06  21:55:20  dieter
 * Removed code that was #ifdef USE_CHILD.  USE_CHILD will not work
 * because the thread state is not copied on a fork.
 *
 * Revision 2.2  1998/12/22  15:14:54  dieter
 * Try using setcontext/getcontext instead of siglongjmp/sigsetjmp
 *
 * Revision 2.1  1998/12/22  15:14:13  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.18  1998/12/03  20:34:43  dieter
 * updated some comments
 *
 * Revision 1.17  1998/12/03  15:05:25  dieter
 * Added include of debug.h to get DBG_PRINTF
 *
 * Revision 1.16  1998/12/03  15:03:06  dieter
 * changed some printfs
 *
 * Revision 1.15  1998/12/03  14:58:47  dieter
 * Changed some checkpointing messages.
 *
 * Revision 1.14  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.13  1998/09/09  14:34:06  dieter
 * In handle_args, reset optind to 1 so that the main program can still
 * use getopt.
 *
 * Revision 1.12  1998/09/01  15:56:54  dieter
 * Added changes to support libc I/O (fopen, fclose).
 *
 * Revision 1.11  1998/08/31  20:44:58  dieter
 * Skip over application arguments before reading checkpoint arguments.
 *
 * Revision 1.10  1998/08/27  17:58:19  dieter
 * Checkpoint names are now automatically generated.
 *
 * Revision 1.9  1998/08/26  21:24:42  dieter
 * Checkpointing works with timer, but only once.
 *
 * Revision 1.8  1998/08/25  21:15:24  dieter
 * Add checkpoint period option.
 *
 * Revision 1.7  1998/08/25  20:18:04  dieter
 * Added support for sequential I/O files.
 *
 * Revision 1.6  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.5  1998/08/16  16:42:17  dieter
 * Made changes so that threads checkpoint when they get a SIGUSR1.
 * Recovery does not work yet.
 *
 * Revision 1.4  1998/08/10  19:18:12  dieter
 * Switched from thread info list to hash table of thread info.
 *
 * Revision 1.3  1998/08/03  20:39:44  dieter
 * Attempted checkpoint asynchronously with USE_CHILD, but failed because
 * only the thread calling fork exists in the child process.
 *
 * Revision 1.2  1998/07/31  20:14:36  dieter
 * Pretty much everything is moved over from the old version of checkpointing.
 *
 * Revision 1.1  1998/07/31  13:39:13  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <setjmp.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>

#include "debug.h"
#include "memdebug.h"
#include "machif.h"
#include "cppthread.h"
#include "cpglobal.h"
#include "cpstate.h"
#include "save.h"
#include "checkpoint.h"
#include "callback.h"
#include "sysio.h"
#include "libcio.h"
#include "fstate.h"
#include "exclude.h"
#include "barrier.h"
#include "save.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#if OS == LINUX
#define SIGMAX  SIGRTMAX	/* _SC_RTSIG_MAX only reports 32 signals for
				 * Linux when in fact 63 are available
				 */
#else
#define SIGMAX  sysconf(_SC_RTSIG_MAX)
#endif

#if BUILD_FOR_UNIFY == 1
#define CHKPT_DEFAULT_PERIOD  0 /* default checkpoint period (inseconds)   */
#define ARG_SEP_COUNT         2
#else
#define CHKPT_DEFAULT_PERIOD  300 /* default checkpoint period (inseconds)   */
#define ARG_SEP_COUNT         1
#endif

#define CHKPT_ENV_OPTS "CHKPTOPTS"
#define OPT_WHITESPACE " \t"	/* whitespace characters in options env var  */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

sigjmp_buf chkpt_env;		/* stack environment of the main thread      */
#if OS == LINUX
sigjmp_buf manager_env;		/* stack environment of the manager thread   */
#endif

int chkpt_sigcnt = 0;		/* number of items in chkpt_sigaction        */
				/* signal actions at time of checkpoint      */
struct sigaction *chkpt_sigaction = NULL;

				/* information about the process             */
static proc_status_t chkpt_proc_status;

chkpt_opt_t chkpt_opts;
char *chkpt_restore_file = NULL;

pthread_mutex_t in_chkpt_mutex = MUTEX_INITIALIZER;

int init_done = 0;		/* true when initialization is done	     */
int chkpt_recovering = 0;
int chkpt_restart_manager = 1;	/* true when manager thread should run */

static char *chkpt_env_args = NULL; /* a copy of the checkpointing options
				    * environment variable, chopped up into
				    * an argv-style argument array.  We have
				    * to keep a copy around because if any
				    * of env args are used, the checkpointing
				    * library might keep a pointer to them.
				    * We could just duplicate the strings that
				    * have pointers to them or keep track of
				    * whether or not anything points into
				    * chkpt_env_args, but that is more trouble
				    * than it is worth to save a few hundred
				    * bytes.  I am keeping this pointer (and
				    * the next one) around so that some time
				    * in the future I can clean this mess up,
				    * TODO: free the env_args when not in use.
				    */
static char **chkpt_env_argv = NULL; /* the argv for the above args */

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void chkpt_print_opts(chkpt_opt_t *opts);

static void handle_env(char *cmd, chkpt_opt_t *opts);
static int count_args(char *str);
static int set_args(char *cmd, char *env, char **argv);

static void handle_cmd_line(int *argc, char *argv[], chkpt_opt_t *opts);
static void handle_args(int argc, char *argv[], chkpt_opt_t *opts);

int save_process_state( char *filename, pid_t pid );
int save_sig_info( void );

void print_mappings( proc_status_t *status, int nmap, memmap_t *mapping );
void print_mapping( memmap_t *map );

void print_sighandlers( void );

#if 0
static void chkpt_block_manager_thread(sigjmp_buf *env);
#endif

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int chkpt_init(int *argc, char *argv[], chkpt_opt_t *opts)
{
  int status;

  MemDebugInit();

  sysio_init();
  libcio_init();
  chkpt_barrier_install_sighandler();

  if(opts == NULL) {
    chkpt_opt_init(&chkpt_opts);
  } else {
    chkpt_set_opts(opts);
  }

  handle_env(argv[0], &chkpt_opts);
  handle_cmd_line(argc, argv, &chkpt_opts);

  chkpt_sigcnt = SIGMAX;
  chkpt_sigaction =(struct sigaction *)malloc(sizeof(struct sigaction)
					      * chkpt_sigcnt);
  if (chkpt_sigaction == NULL) {
    fprintf(stderr, "cannot allocate chkpt_sigaction array\n");
    return -1;
  }

  if ( (status = chkpt_thread_init()) != 0) {
    CRASH("thread initialization failed\n");
  }
  if ( (status = chkpt_save_init()) != 0) {
    CRASH("save initialization failed\n");
  }

  init_done = 1;

  if (chkpt_opts.restore) {
#if BUILD_FOR_UNIFY != 1
    chkpt_restore_state(chkpt_restore_file);
    /* never returns */
#endif
  }

  return 0;
}

void chkpt_opt_init(chkpt_opt_t *opts)
{
  memset(opts, 0, sizeof(chkpt_opt_t));
  opts->period = CHKPT_DEFAULT_PERIOD;
}

void chkpt_get_opts(chkpt_opt_t *opts)
{
  if(opts != NULL) {
    *opts = chkpt_opts;
  }
}

void chkpt_set_opts(chkpt_opt_t *opts)
{
  if(opts != NULL) {
    chkpt_opts = *opts;
  }
}

void chkpt_print_opts(chkpt_opt_t *opts)
{
  printf("period is %d seconds\n", opts->period);
  printf("restore is %s\n", opts->restore ? "enabled" : "disabled");
  if (opts->filebase != NULL) {
    printf("file basename is '%s'\n", opts->filebase);
  } else {
    printf("file basename is not set\n");
  }
}

static void handle_env(char *cmd, chkpt_opt_t *opts)
{
  char *env;			/* value of the CHKPT_ENV_OPTS env variable */
  int argc;

  if ( (env = getenv(CHKPT_ENV_OPTS)) != NULL) {
    if ( (chkpt_env_args = strdup(env)) == NULL) {
      ERROR("cannot allocate space for chkpt_env_args");
      fprintf(stderr, "ignoring environment variable options\n");
      return;
    }
    argc = count_args(chkpt_env_args);
    /* need +1 for terminating NULL pointer, +1 for dummy cmd name */
    if ((chkpt_env_argv = (char **)malloc(sizeof(char *) * (argc+2))) != NULL) {
      set_args(cmd, chkpt_env_args, chkpt_env_argv);
      handle_args(argc+1, chkpt_env_argv, opts);
    } else {
      ERROR("cannot allocate space for env arg vector");
      fprintf(stderr, "Ignoring environment variable options\n");
    }
    /* see comments at declaration of chkpt_env_args and chkpt_env_argv for
     * explanation of why they are not freed here.
     */
  }
}

/* count number of arguments that would be in this command line */
static int count_args(char *str)
{
  int argc = 0;

  ASSERT(str != NULL);

  while(*str != '\0') {
    str += strspn(str, OPT_WHITESPACE);
    if (*str != '\0') {
      argc++;
    }
    str += strcspn(str, OPT_WHITESPACE);
  }

  return argc;
}

/* make an argv array for a set of args (assume argv is big enough) */
static int set_args(char *cmd, char *env, char **argv)
{
  int argc;

  ASSERT(env != NULL);

  /* getopt will skip over the first argument, assuming it is the command */
  argv[0] = cmd;
  argc = 1;
  while(*env != '\0') {
    env += strspn(env, OPT_WHITESPACE);
    if (*env != '\0') {
      argv[argc++] = env;
    }
    env += strcspn(env, OPT_WHITESPACE);
    if (*env != '\0') {
      *env++ = '\0';
    }
  }
  argv[argc] = NULL;

  return argc;
}

static void handle_cmd_line(int *argc, char *argv[], chkpt_opt_t *opts)
{
  char *base;			/* basename for checkpoint files */
  int sep_count;
  int arg;
  char **chkpt_argv;
  int chkpt_argc;

  /* set default options */
  if (opts->filebase == NULL) {
    base = rindex(argv[0], '/');
    if (base != NULL) {
      opts->filebase = base + 1;
    } else {
      opts->filebase = argv[0];
    }
  }
        
  /* skip over non-checkpointing arguments */

  sep_count = 0;
  for(arg = 1 ; (arg < *argc) && (sep_count < ARG_SEP_COUNT) ; arg++) {
    if (strcmp("--", argv[arg]) == 0) {
      sep_count++;
#if BUILD_FOR_UNIFY == 1
    } else if ((sep_count > 0) && strcmp("-v", argv[arg]) == 0) {
      /* grab the unify recovery arg */
      opts->restore = 1;
#endif
    }
  }

  if (sep_count < ARG_SEP_COUNT)
    return;

  arg--;
  chkpt_argc = *argc - arg;
  chkpt_argv = argv + arg;

  /* handle checkpoint arguments */
  handle_args(chkpt_argc, chkpt_argv, opts);

  /* clean up args to hide checkpointing arguments */
  *argc = arg;
  argv[arg] = NULL;

  return;
}

static void handle_args(int argc, char *argv[], chkpt_opt_t *opts)
{
  int opt;
  int cflg = 0;
  int rflg = 0;
  int errflg = 0;
 
  void *foo;
  int size;

  /* handle checkpoint arguments */
  /* someone may have called getopt before this, so reset getopt */
  optind = 1;
  while ((opt = getopt(argc, argv, "ab:r:m:t:")) != EOF)
    switch (opt) {
    case 'a':
      opts->async = 1;
      break;
    case 'b':
      opts->filebase = optarg;
      break;
    case 'r':
      if( cflg ) {
	errflg++;
      } else {
	rflg++;
	chkpt_restore_file = optarg;
      }
      break;
    case 'm':
      /* allocate memory to make the checkpoint bigger */
      size = atoi(optarg);
      if (size > 0) {
	foo = (void *)malloc(size);
	if (foo == NULL) {
	  fprintf(stderr, "malloc for garbage memory failed\n");
	}
      }
      /* note the pointer to foo is lost upon return, but who
       * cares?  It is just garbage to make the checkpoint bigger.
       */
      break;
    case 't':
      /* set the checkpoint period */
      opts->period = atoi(optarg);
      if (opts->period < 0)
	errflg++;
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    fprintf(stderr, "usage: %s [ program args ] -- [-t period | -r file] "
	    "[-a] [ -b basename ] [ -m bytes ]\n", argv[0]);
    fprintf(stderr,
	    "\t-a           Save checkpoints asynchronously\n"
	    "\t-b basename  Use basename as the base for checkpoint names\n"
	    "\t-m bytes     (debug) Allocate a chunck of unused memory\n"
	    "\t-r file      Recover using file as the checkpoint file\n"
	    "\t-t period    Set checkpointing period to period seconds"
  	                    " (0 to disable)\n");
    exit (2);
  }

  if (rflg) {
    opts->restore = 1;
  }

  /* pretend like getopt has never been called */
  optind = 1;
  
  return;
}

#ifdef SEGVDEBUG
void segv_debug(int sig, siginfo_t *info, void *ucontext)
{
  fprintf(stderr, "segv at %p (%s)\n", info->si_addr,
	  (info->si_code == SEGV_MAPERR) ? "address unmapped" :
	  ((info->si_code == SEGV_ACCERR) ? "access protection violation" :
	   "unknown cause"));
  return;
}
#endif

int do_checkpoint(char *filename)
{
  struct itimerval no_timer = {{0, 0}, {0, 0}};
  struct itimerval itimer_real;
  struct itimerval itimer_virtual;
  struct itimerval itimer_prof;
#if HAVE_ITIMER_REALPROF == 1
  struct itimerval itimer_realprof;
#endif
  
  int alarm_val;
  int recovering;


  /* itimers and alarms are not inherited, so save them in the parent */
  setitimer( ITIMER_REAL, &no_timer, &itimer_real );
  setitimer( ITIMER_VIRTUAL, &no_timer, &itimer_virtual );
  setitimer( ITIMER_PROF, &no_timer, &itimer_prof );
#if HAVE_ITIMER_REALPROF == 1
  setitimer( ITIMER_REALPROF, &no_timer, &itimer_realprof );
#endif
  
  alarm_val = alarm(0);

  save_pending_signals();

  wait_for_other_threads();

  recovering = save_process_state( filename, getpid() );

  setitimer( ITIMER_REAL, &itimer_real, NULL );
  setitimer( ITIMER_VIRTUAL, &itimer_virtual, NULL );
  setitimer( ITIMER_PROF, &itimer_prof, NULL );
#if HAVE_ITIMER_REALPROF == 1
  setitimer( ITIMER_REALPROF, &itimer_realprof, NULL );
#endif

  alarm( alarm_val );

  continue_other_threads();

  return recovering;
}



int save_process_state( char *filename, pid_t pid )
{
  int       nmap;
  memmap_t *mapping;
  int       status;

  DBG_PRINTF(( "pid is %ld\n", getpid() ));
  chkpt_restart_manager = 0;
  pthread_chkpt_precreate(&manager_env
#if 0
			  , chkpt_block_manager_thread
#endif
			  );

  if( (chkpt_recovering = sigsetjmp(chkpt_env, 1)) == 0 ) 
  {
    /* save the state and exit */
    status = save_sig_info();
    if( status == -1 )
      return status;

    status = fstate_save();
    if( status == -1 )
      return status;

    /* WARNING: must finish all memory allocation before reading the prstatus
     * because allocating memory may change the size of the heap
     */
    
    status = get_state_info( pid, &chkpt_proc_status, &nmap, &mapping );
    if( status == -1 ) {
      return status;
    }

    chkpt_intersect_map( &nmap, mapping );
    chkpt_save_start = gethrtime();
    if (chkpt_opts.async) {
      chkpt_async_save(filename, pid, &chkpt_proc_status, nmap, mapping);
    } else {
      save_chkpt(filename, pid, &chkpt_proc_status, nmap, mapping);
    }
    chkpt_save_end = gethrtime();

    chkpt_restart_manager = 1;
    pthread_chkpt_postcreate(BARRIER_SIG);

#ifdef DEBUG_MAPPINGS
    printf("stack = 0x%08lx - 0x%08lx\n", (long)chkpt_proc_status.stkbase,
	   ((long)chkpt_proc_status.stkbase) + chkpt_proc_status.stksize);
    print_mappings( &chkpt_proc_status, nmap, mapping );
#endif
  } else {
    status = fstate_restore();
    if( status == -1 )
      return -1;

    chkpt_restart_manager = 1;
    pthread_chkpt_postrestart(&chkpt_no_restore.thr_pids[0],
			      chkpt_no_restore.num_pids, BARRIER_SIG);
 /*    printf( "recovering from checkpoint\n" ); */
#ifdef SEGVDEBUG
    {
      struct sigaction act;
      
      act.sa_sigaction = segv_debug;
      sigemptyset(&act.sa_mask);
      act.sa_flags = SA_SIGINFO;
      sigaction(SIGSEGV, &act, NULL);
    }
#endif
    chkpt_barrier_pid_reset(chkpt_barrier);
  }
  DBG_PRINTF( "main thread done with checkpointing\n" );

  return chkpt_recovering; 
}

int save_sig_info( void )
{
  int sig;

  /* in theory SIGMAX can change... */
  if( SIGMAX != chkpt_sigcnt ) {
    chkpt_sigcnt = SIGMAX;
    chkpt_sigaction = realloc( chkpt_sigaction, chkpt_sigcnt );
    if( chkpt_sigaction == NULL ) {
      fprintf( stderr, "could not realloc chkpt_sigaction\n" );
      return -1;
    }
  }

  /* copy info about signal handling into user space */
  for( sig = 1 ; sig < chkpt_sigcnt ; sig++ ) {
    sigaction( sig, NULL, chkpt_sigaction + sig - 1);
  }

  return 0;
}

void print_mappings( proc_status_t *prstatus, int nmap, memmap_t *mapping )
{
  int  i;

  printf( "%21s %10s %10s %8s Attributes\n", "start-stop      ", "Length",
	  "Page Size", "Offset" );

  for( i = 0 ; i < nmap ; i++ ) {
    print_mapping( &mapping[i] );

    if( mapping[i].addr == prstatus->stkbase ) {
      printf( "^^^ stack segment ^^^\n" );
    } else if( (char *)&chkpt_sigcnt >= mapping[i].addr &&
	(char *)&chkpt_sigcnt < mapping[i].addr + mapping[i].len  ) {
      printf( "^^^ data segment + heap^^^\n" );
    } else if( (char *)print_mappings >= mapping[i].addr &&
	(char *)print_mappings < mapping[i].addr + mapping[i].len  ) {
      printf( "^^^ code segment ^^^\n" );
    }
  }
}

void print_mapping( memmap_t *map ) 
{
  char *sep;

  printf( "0x%08lx-0x%08lx", (unsigned long)map->addr,
	  (unsigned long)(map->addr + map->len) );
  printf( " %10ld", map->len );
  printf( " %10ld", map->pagesize );
  printf( " %8ld", map->offset );
  printf( " " );

  sep = "";

  if( map->prot & PROT_READ ) {
    printf( "read" );
    sep = "|";
  }

  if( map->prot & PROT_WRITE ) {
    printf( "%swrite", sep );
    sep = "|";
  }

  if( map->prot & PROT_EXEC ) {
    printf( "%sexecute", sep );
    sep = "|";
  }

  printf( "\n" );
}

void print_sighandlers( void )
{
  int i;
  int status;
  struct sigaction current;

  for( i = 1 ; i <= SIGMAX ; i++ ) {
    status = sigaction( i, NULL, &current );
    if( status == -1 ) {
      fprintf( stderr, "cannot examine signal %d\n", i );
      perror( "print_sighandlers" );
    }
    if( current.sa_handler == SIG_DFL ) {
      printf( "%3d    Default Action\n", i );
    } else if( current.sa_handler == SIG_IGN ) {
      printf( "%3d    Ignore\n", i );
    } else {
      printf( "%3d    Function at 0x%p\n", i, current.sa_sigaction );
    }
  }
}

int chkpt_block(void)
{
  return pthread_mutex_lock(&in_chkpt_mutex);
}

int chkpt_unblock(void)
{
  return pthread_mutex_unlock(&in_chkpt_mutex);
}

#if OS == LINUX
#if 0
/* Get some notion of the current stack.  Need not be exactly the top
   of the stack, just something somewhere in the current frame.  */
#ifndef CURRENT_STACK_FRAME
#define CURRENT_STACK_FRAME  ({ char __csf; &__csf; })
#endif
#define THREAD_MANAGER_STACK_SIZE  65536 /* close enough (see below) */

/* We need the thread library manager thread to block in some
 * controlled way while we save the state.  If it uses code in the
 * thread library to block, the code may be relocated during recovery
 * because the thread library is dynamically linked.  Therefore, pass
 * the address of the following function to pthread_chkpt_precreate.
 * The thread library will call this function to block until the
 * checkpoint is done.  During recovery it will longjmp back into this
 * function, which is statically linked with the checkpointing
 * library. 
 */
/* ASSUME: the checkpointing library is statically linked to the
 * executable
 */
static void chkpt_block_manager_thread(sigjmp_buf *env)
{
  /* mask cannot be on the heap because it is used while the heap segment
   * is being reloaded.  Why not?  It should get overwritten with the same
   * value...
   */
  static sigset_t mask;
  int restart;
  
  restart = sigsetjmp(*env, 1);
  pthread_chkpt_restart_main(restart);

  /* wait for checkpoint to be saved (or restored)*/
  sigfillset(&mask);
  sigdelset(&mask, BARRIER_SIG);
  sigdelset(&mask, SIGINT);
  while(!chkpt_restart_manager) {
    ssigsuspend(&mask);
  }
}
#endif
#endif
