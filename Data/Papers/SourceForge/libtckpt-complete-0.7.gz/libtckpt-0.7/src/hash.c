/*
 * hash.c
 *
 * Hash table for keeping track of thread info (or anything else).
 *
 * Add and delete operations are protected by mutexes, but find is
 * not.  The table is designed so that as long as only one thread 
 * adds and deletes an entry, it can access information about it
 * without locking the table.
 *
 * History
 * -------
 * $Log: hash.c,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.2  1999/04/20  15:08:56  dieter
 * Use mutexes instead of pthread_sigmask to prevent signals when
 * locking a mutex.
 * Intercept _mutex_lock and _mutex_unlock to handle libraries that use mutexes.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:25:03  dieter
 * verstion that worked for ftcs paper.
 *
 * Revision 1.3  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.2  1998/08/31  21:51:33  dieter
 * Added htable_lock and htable_unlock.
 *
 * Revision 1.1  1998/08/10  19:18:12  dieter
 * Initial revision
 *
 */

#include <sys/types.h>

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "memdebug.h"
#include "hash.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define HENTRY_VALID  0x00000001 /* entry is being used */

#define PROBE_SIZE    7		/* arbitrarily chosen */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/* an entry in the hash table */
typedef struct hentry {
  long           status;	/* status of the entry */
  long		 key;		/* key by which items are stored */
  void          *value;		/* value stored in the table */
  struct hentry *next;		/* next item with same primary hash */
} hentry_t;

/* a table itself */
struct htable {
  size_t           size;	/* max. number of entries in table */
  size_t	   entries;	/* number of valid entries */
  hentry_t        *table;	/* the table itself */
  pthread_mutex_t  mutex;	/* mutex to prevent concurrent accesses */
};

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void  htable_dump( htable_t *htable );
int   print_hentry( long key, void *value, void *arg );

long primary_hash( htable_t *htable, long key );
long secondary_hash( htable_t *htable, long key, long prev );

hentry_t *get_hentry( htable_t *htable, long key );

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

htable_t *new_htable( size_t size )
{
  htable_t *new_htable;
  int       status;
  
  new_htable = (htable_t *)malloc( sizeof(htable_t) );
  if( new_htable == NULL ) {
    return NULL;
  }

  new_htable->size = size;
  new_htable->entries = 0;
  new_htable->table = calloc( size, sizeof(hentry_t) );
  if( new_htable->table == NULL ) {
    free( new_htable );
    return NULL;
  }

  status = pthread_mutex_init( &new_htable->mutex, NULL );
  if( status != 0 ) {
    fprintf( stderr, "new_htable: %s\n", strerror( status ) );
    free( new_htable->table );
    free( new_htable );
    return NULL;
  }

  return new_htable;
}

void destroy_htable( htable_t *htable )
{
  free( htable->table );
  free( htable );
}

/* these hash functions are really bad for most general cases, but
 * for my application, I expect the keys to be sequential integers.
 * In that case, this hash function should be fine (and it doesn't
 * require much thinking).
 */
long primary_hash( htable_t *htable, long key )
{
  return key % htable->size;
}

long secondary_hash( htable_t *htable, long key, long prev )
{
  return (prev+PROBE_SIZE) % htable->size;
}

hentry_t *get_hentry( htable_t *htable, long key )
{
  long index;
  long start_index;

  index = primary_hash( htable, key );
  if( ((htable->table[index].status & HENTRY_VALID) == 0)
      || htable->table[index].key != key ) {
    /* key not found at primary hash location, search secondary */
    start_index = index;
    do {
      index = secondary_hash( htable, key, index );
    } while( (((htable->table[index].status & HENTRY_VALID) == 0)
	      || (htable->table[index].key != key))
	     && (index != start_index) );
    if( index == start_index ) {
      return NULL;
    }
  }

  return &(htable->table[index]);
}

/* adding an item with the same key twice overwrites the original value */
int  htable_add( htable_t *htable, long key, void *value )
{
  long index;
  long start_index;

  pthread_mutex_lock( &htable->mutex );

  index = primary_hash( htable, key );
  if( htable->table[index].status & HENTRY_VALID
      && htable->table[index].key != key ) {
    /* primary hash entry is occupied; use secondary */
    start_index = index;
    do {
      index = secondary_hash( htable, key, index );
    } while( ((htable->table[index].status & HENTRY_VALID)
	      && (htable->table[index].key != key))
	     && index != start_index);

    if( index == start_index ) {
      /* table is full */
      pthread_mutex_unlock( &htable->mutex );
      return -1;
    }
  }
  
  /* insert entry here */
  htable->table[index].status |= HENTRY_VALID;
  htable->table[index].key = key;
  htable->table[index].value = value;
  htable->entries++;

  pthread_mutex_unlock( &htable->mutex );

  return 0;
}

int   htable_delete( htable_t *htable, long key )
{
  hentry_t *hentry;

  pthread_mutex_lock( &htable->mutex );
  /* find the entry */
  hentry = get_hentry( htable, key );
  if( hentry == NULL ) {
    pthread_mutex_unlock( &htable->mutex );
    return -1;
  }

  /* invalidate the entry */
  hentry->status &= ~HENTRY_VALID;
  htable->entries--;

  pthread_mutex_unlock( &htable->mutex );

  return 0;
}

int   htable_find(   htable_t *htable, long key, void **value )
{
  hentry_t *hentry;
  
  hentry = get_hentry( htable, key );
  if( hentry != NULL ) {
    *value = hentry->value;
    return 0;
  }
  
  return -1;
}

int   htable_entry_cnt( htable_t *htable )
{
  return htable->entries;
}

int   htable_forall( htable_t *htable,
		     int (*func)(long key, void *value, void *arg),
		     void *arg )
{
  long index;
  int status;

  for( index = 0 ; index < htable->size ; index++ ) {
    if( htable->table[index].status & HENTRY_VALID ) {
      status = func( htable->table[index].key, htable->table[index].value,
		     arg );
      if( status != 0 ) {
	return status;
      }
    }
  }
  
  return 0;
}

int   htable_lock(htable_t *htable)
{
  return pthread_mutex_lock(&htable->mutex);
}

int   htable_unlock(htable_t *htable)
{
  return pthread_mutex_unlock(&htable->mutex);
}

void  htable_dump( htable_t *htable )
{
  if( htable != NULL ) {
    printf( "key                     value   \n" );
    printf( "----------------------  --------\n" );
    htable_forall( htable, print_hentry, NULL );
  }
}

int   print_hentry( long key, void *value, void *arg )
{
  printf( "%8ld (0x%08lx):  %8p\n", key, key, value );

  return 0;
}
