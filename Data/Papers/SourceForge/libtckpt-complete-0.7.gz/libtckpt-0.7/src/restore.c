/*
 * restore.c
 *
 * Functions to read a processes's state from the disk.
 *
 * History
 * -------
 * $Log: restore.c,v $
 * Revision 6.3  2001/06/06 21:21:55  wrdieter
 * Minor cleanup; make internal functions static.
 *
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.7  2000/02/01 19:45:03  dieter
 * Use static pread.
 *
 * Revision 4.6  2000/01/20 00:15:22  dieter
 * Make sure all pending signals are delivered during recovery and only
 * during recovery to avoid crashes when running normally and deadlock on
 * recovery.
 *
 * Revision 4.5  2000/01/19 22:49:00  dieter
 * Delay sending signals pending before the checkpoint until the end of the
 * signal handler.
 *
 * Revision 4.4  1999/11/01 20:53:55  dieter
 * removed unneeded lines
 *
 * Revision 4.3  1999/10/21 22:47:20  dieter
 * Changes to compile with Linux.
 *
 * Revision 4.2  1999/08/02 15:40:22  dieter
 * checked in wrong version for 4.1, use this version instead.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.4  1999/01/20  01:57:27  dieter
 * Removed setcontext/getcontext code.  It was not any better than
 * sigsetjmp/siglongjmp.
 *
 * Revision 2.3  1999/01/20  00:17:11  dieter
 * Restore the stack using pread and mprotect instead of mmap.
 *
 * Revision 2.2  1998/12/22  15:32:24  dieter
 * Try getcontext/setcontext instead of sigsetjmp/siglongjmp.
 *
 * Revision 2.1  1998/12/22  15:32:02  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.7  1998/12/03  20:33:32  dieter
 * remove redundant code
 *
 * Revision 1.6  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.5  1998/09/08  21:05:44  dieter
 * Save the stack address separately so that I can restore the stack pointer
 * before loading any segments.  Then load all segments the same way
 * (including the stack segment.)  Otherwise must handle case where the
 * stack consists of multiple segments.
 *
 * Revision 1.4  1998/08/25  20:32:28  dieter
 * Cleaned up a bit.
 *
 * Revision 1.3  1998/08/25  20:18:04  dieter
 * Added support for sequential I/O files.
 *
 * Revision 1.2  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.1  1998/07/31  20:16:40  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "debug.h"
#include "memdebug.h"
#include "machif.h"
#include "cpstate.h"
#include "cppthread.h"
#include "sysio.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define STACK_FUDGE  4096	/* fudge factor to prevent restored stack */
				/* from hitting the top frame of the current */
				/* stack */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static void adjust_stack(int fd, int nmap, caddr_t stkbase);

static int  restore_sig_info(void);
static void restore_stack(memmap_t *memmap, int fd);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int chkpt_restore_state(char *filename)
{
  int      fd;
  int      nmap;
  int      status;
  caddr_t  endds;
  caddr_t  stkbase;

  fd = sys_open( filename, O_RDONLY );
  if( fd == -1 ) {
    fprintf( stderr, "error opening checkpoint file %s for read\n", filename );
    perror( filename );
    return -1;
  }

  /* restore thread state */
  restore_threads(fd);

  /* restore memory state */
  read(fd, &nmap, sizeof(int));

  /* set the brk explicitly; this simplifies working with programs that use */
  /* mprotect.  Using mprotect breaks the heap up into a bunch of mappings. */
  read(fd, &endds, sizeof(caddr_t));
  status = brk( endds );
  if( status == -1 ) {
    exit( -2 );
  }

  read(fd, &stkbase, sizeof(caddr_t));

  adjust_stack(fd, nmap, stkbase);

  return 0;
}

/* never returns */
static void adjust_stack(int fd, int nmap, caddr_t stkbase)
{
  int       i;
  memmap_t  memmap;
  caddr_t   pa;
  int       status;
  int       zero_fd;

  if ((caddr_t)&stkbase > stkbase) 
    adjust_stack(fd, nmap, stkbase);

  if ( (zero_fd = sys_open("/dev/zero", O_RDWR)) < 0) {
    fprintf(stderr, "cannot open /dev/zero: %s\n", strerror(errno));
    exit(-7);
  }

  for( i = 0 ; i < nmap ; i++ ) {
    /* need to use the statically linked version of read here */
    sread( fd, &memmap, sizeof(memmap_t) );

    if( memmap.remap ) {
      /* the code segment is not mapped */
      if( memmap.type == SEG_STCK ) {
	status = spread( fd, memmap.addr, memmap.len, memmap.file_offset );
	if( status == -1 ) {
	  exit( -4 );
	}
	status = smprotect( memmap.addr, memmap.len, memmap.prot );
	if( status == -1 ) {
	  exit( -5 );
	}
      } else if( memmap.type == SEG_EXCL ) {
	pa = smmap( memmap.addr, memmap.len, memmap.prot,
		    MAP_PRIVATE|MAP_FIXED, zero_fd, 0);
	if (pa == MAP_FAILED || pa != memmap.addr) {
	  exit(-6);
	}
#ifdef CHKPT_EXCLUDE_DEBUG
	fill_with_trash(memmap.addr, memmap.len);
#endif
      } else if( memmap.type != SEG_CODE ) {
	/* map all other segments right now */
	pa = smmap( memmap.addr, memmap.len, memmap.prot,
		    MAP_PRIVATE|MAP_FIXED, fd, memmap.file_offset );
	if( pa == MAP_FAILED || pa != memmap.addr ) {
	  exit( -3 );
	}
      }
    }
  }
  sys_close(zero_fd);

  /* threads are already ready to go; they will be unblocked later */

  restore_sig_info();
  /*  restore_stack( &stack_memmap, fd ); */
  /* restore_stack never returns */

  sys_close(fd);
  siglongjmp( chkpt_env, 1 );
}

/* signal handlers are per process not per thread so handle them here */
static int restore_sig_info(void)
{
  int sig;

  /* copy info about signal handling into kernel space */
  for( sig = 1 ; sig <= chkpt_sigcnt ; sig++ ) {
    sigaction( sig, chkpt_sigaction + sig - 1, NULL );
  }

  return 0;
}

/* send signals that where pending before the checkpoint */
void restore_pending_signals(sigset_t *was_pending)
{
  int sig;
  pthread_t me;
  sigset_t now_pending;

  /* I would rather just skip this whole function if we are not
   * recovering from a checkpoint, but I don't have a good way
   * to check for that.  For now, don't send the signal if it is
   * already pending.
   */
  sigpending(&now_pending);
  me = pthread_self();
  for( sig = 1 ; sig <= chkpt_sigcnt ; sig++ ) {
    if( sigismember(was_pending, sig) && !sigismember(&now_pending, sig) ) {
      pthread_kill( me, sig );
    }
  }
}

/* never returns */
static void restore_stack( memmap_t *memmap, int fd ) 
{
  memmap_t  local_memmap;
  caddr_t pa;

  local_memmap = *memmap;

  /* grow the stack beyond what will be restored */
  if( (caddr_t)memmap > local_memmap.addr
      || (caddr_t)memmap < (caddr_t)&local_memmap ) {
    restore_stack( &local_memmap, fd );
  }

  /* the stack frame for this function is now safe; restore the stack */

  pa = mmap( local_memmap.addr, local_memmap.len, local_memmap.prot,
	     MAP_PRIVATE|MAP_FIXED, fd, local_memmap.file_offset );
  if( pa == MAP_FAILED && pa != local_memmap.addr ) {
    exit( -6 );
  }
  
  sys_close(fd);
  siglongjmp( chkpt_env, 1 );
}
