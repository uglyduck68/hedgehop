/*
 * debug.c
 *
 * Functions to support debugging
 *
 * History
 * -------
 * $Log: debug.c,v $
 * Revision 6.2  2000/05/08 19:09:24  dieter
 * Added fill_with_trash
 *
 * Revision 6.1  2000/05/02  20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:23:12  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.1  1998/12/03  19:35:26  dieter
 * Initial revision
 *
 */
 
#include <stdio.h>
#include <stdarg.h>

typedef unsigned long ptrint_t;
typedef double biggest_t;

const char trash[sizeof(biggest_t)] =
{0xba, 0xad, 0xca, 0xfe, 0xde, 0xad, 0xbe, 0xef};

void err_printf(const char *format, ...)
{
  va_list  args;

  va_start(args, format);
  vfprintf(stderr, format, args);
  va_end(args);
}

void fill_with_trash(const void *addr, size_t len)
{
  unsigned char *cfill;		/* address to fill with chars */
  double        *dfill;
  int            offset;	/* amount off from alignment with biggest_t */

  cfill = (char *)addr;
  
  while( (len > 0) && (offset = ( (ptrint_t)cfill & (sizeof(biggest_t)-1)))) {
    *cfill++ = trash[offset];
    len--;
  }
  dfill = (double *)cfill;
  while(len > sizeof(biggest_t)) {
    *dfill++ = *((double *)trash);
    len -= sizeof(biggest_t);
  }
  cfill = (char *)dfill;
  for(offset = 0 ; len > 0 ; offset++) {
    *cfill++ = trash[offset];
    len--;
  }
}

