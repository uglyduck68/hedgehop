/*
 * libcio.c
 *
 * functions to intercept stdio file callse to capture file state information
 * as needed.
 *
 * History
 * -------
 * $Log: libcio.c,v $
 * Revision 6.2  2000/05/15 22:13:32  dieter
 * In fclose, get the file descriptor before closing the file.  After
 * closing the file it does not exist.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.3  2000/01/20 15:43:07  dieter
 * Initialize on the first call to an intercepted function if the
 * initialization has not been called yet.
 *
 * Revision 4.2  1999/10/21 22:49:33  dieter
 * Changes to compile with Linux.
 * Use get_file_fd to get file descriptor of a file pointer in a device independent way.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:26:33  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.3  1998/12/11  21:42:13  dieter
 * Cast return values of dlsym to remove compiler warnings.
 *
 * Revision 1.2  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.1  1998/09/01  15:56:54  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <dlfcn.h>

#include "memdebug.h"
#include "fstate.h"
#include "machif.h"
#include "libcio.h"

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define LIBCIO_INIT() {if (libc_fopen == NULL) libcio_init();}

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

FILE *(*libc_fopen)(const char *filename, const char *type) = NULL;
FILE *(*libc_freopen)(const char *filename, const char *type, FILE *stream)
     = NULL;

int   (*libc_fclose)(FILE *stream) = NULL;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int libcio_init(void)
{
  libc_fopen   =
    (FILE *(*)(const char *, const char *))dlsym(RTLD_NEXT, "fopen");
  libc_freopen =
    (FILE *(*)(const char *, const char *, FILE *))dlsym(RTLD_NEXT, "freopen");
  libc_fclose   = (int (*)(FILE *))dlsym(RTLD_NEXT, "fclose");
  
  if (libc_fopen == NULL || libc_freopen == NULL || libc_fclose == NULL) {
    return -1;
  }

  return 0; 
}

FILE *fopen(const char *filename, const char *type)
{
  int    status;
  FILE  *fp;
  int    oflag;
  mode_t mode;
  int    filedes;

  LIBCIO_INIT();
  fp = libc_fopen(filename, type);
  if (fp != NULL) {
    filedes = get_file_fd(fp);
    oflag = fcntl(filedes, F_GETFL);
    if (oflag == -1) {
      fclose(fp);
      return NULL;
    }
    /* reading the current file mode creation mask sets it, set it back */
    mode = umask(0);
    umask(mode);

    status = fstate_add_file(filename, oflag, mode, filedes);
    if (status == -1) {
      fclose(fp);
      fp = NULL;
    }
  }

  return fp;
}

FILE *freopen(const char *filename, const char *type, FILE *stream)
{
  int    status;
  FILE  *fp;
  int    oflag;
  mode_t mode;
  int    filedes;

  LIBCIO_INIT();
  /* the man page says that fclose or fflush may fail for stream, so it
   * may not be valid.  ASSUME: if fflush succeeds then stream is valid.
   */
  if (stream != NULL && (fflush(stream) == 0) ) {
    fstate_delete_file(get_file_fd(stream));
  }

  fp = libc_freopen(filename, type, stream);
  if (fp != NULL) {
    filedes = get_file_fd(fp);
    oflag = fcntl(filedes, F_GETFL);
    if (oflag == -1) {
      fclose(fp);
      return NULL;
    }
    
    /* reading the current file mode creation mask sets it, set it back */
    mode = umask(0);
    umask(mode);

    status = fstate_add_file(filename, oflag, mode, filedes);
    if (status == -1) {
      fclose(fp);
      fp = NULL;
    }
  }

  return fp;
}

/* do not need to intercept calls to fdopen because the file descriptor
 * passed to fdopen has already been opened with open (or some other method)
 * that was caught by sysio.c if necessary.
 */

int fclose(FILE *stream)
{
  int status;
  int filedes;

  LIBCIO_INIT();
  filedes = get_file_fd(stream);
  status = libc_fclose(stream);
  if (status != EOF) {
    status = fstate_delete_file(filedes);
  }

  return status;
}
