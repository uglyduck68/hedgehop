/*
 * cppthread.c
 *
 * Code to handle checkpointing with POSIX threads
 *
 * History
 * -------
 * $Log: cppthread.c,v $
 * Revision 6.8  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 * Revision 6.7  2001/06/06 21:25:13  wrdieter
 * Fixed bug when with restart.
 *
 * Revision 6.6  2001/02/13 16:08:33  dieter
 * Changed Solaris conditions for sending a signal based on some old changes
 * I found.
 *
 * Revision 6.5  2000/10/20 21:47:15  dieter
 * Removed unused variable.
 *
 * Revision 6.4  2000/10/20 21:40:05  dieter
 * renamed barrier_wait to chkpt_barrier_wait.
 * Fixed a synchronization problem that occured during recovery.
 * General cleanup.
 * Use POSIX rt signals if they are available.
 *
 * Revision 6.3  2000/05/12 03:38:08  dieter
 * Fixed synchronization bug where recovery had one too few barriers.
 *
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.2  2000/05/02 14:31:34  dieter
 * Moved checkpoint callbacks to checkpoint thread.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.12  2000/02/01 21:38:30  dieter
 * cleaned up some comments.
 *
 * Revision 4.11  2000/01/31 19:37:37  dieter
 * Removed some "#if 0" code.
 * Moved unused functions to bottom of file.
 *
 * Revision 4.10  2000/01/28  21:11:10  dieter
 * Use a barrier to coordinate saving signal state.
 *
 * Revision 4.9  2000/01/25 20:42:09  dieter
 * Added code to time each checkpoint.
 *
 * Revision 4.8  2000/01/20 15:53:15  dieter
 * Removed debugging printfs used with signalling.
 *
 * Revision 4.7  2000/01/20 15:45:54  dieter
 * Remove printing of main thread id on startup.
 *
 * Revision 4.6  2000/01/19 22:38:49  dieter
 * Many changes to support Linux.
 * Move non-async-signal-safe functions out of signal handlers.
 * Use barriers for synchronization.
 *
 * Revision 4.5  1999/11/01 19:55:03  dieter
 * Do not block SIGUSR1 or SIGUSR2 in Linux because LinuxThreads uses them.
 *
 * Revision 4.4  1999/10/21 22:46:29  dieter
 * More changes to compile with Linux.
 *
 * Revision 4.3  1999/10/21  22:41:00  dieter
 * Changes to compile with Linux.
 *
 * Revision 4.2  1999/08/11 17:12:47  dieter
 * Call _lwp_cond_timedwait to start force a scheduler activation.
 *
 * Revision 4.1  1999/08/02  15:27:02  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.5  1999/04/20  15:08:56  dieter
 * Use mutexes instead of pthread_sigmask to prevent signals when
 * locking a mutex.
 * Intercept _mutex_lock and _mutex_unlock to handle libraries that use mutexes.
 *
 * Revision 3.4  1999/04/19  16:33:22  dieter
 * Eliminated deadlock with locks.
 *
 * Revision 3.3  1999/03/11  17:43:11  dieter
 * Declare prevent_locks as volatile.
 *
 * Revision 3.2  1999/03/10  22:13:11  dieter
 * Don't bother growing the stack.  It has already been mapped just do
 * the longjmp.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.8  1999/01/20  01:57:46  dieter
 * Removed setcontext/getcontext code.  It was not any better than
 * sigsetjmp/siglongjmp.
 *
 * Revision 2.7  1999/01/20  01:49:12  dieter
 * Do not set chkpt_start when pthread_cond_wait returns with 0 error.
 * It may have returned for some other reason.  checkpoint_now sets
 * chkpt_start, so there is no need to set it in the checkpoint thread.
 *
 * Revision 2.6  1999/01/20  01:44:14  dieter
 * Do not exit the checkpoint thread when the checkpoint period is zero.
 * The application may still want to call checkpoint_now, so wait forever
 * on a condition variable.
 *
 * Revision 2.5  1999/01/08  23:49:52  dieter
 * Added chkpt_block and chkpt_unblock to allow user code to be atomic
 * with respect to checkpoints.
 *
 * Revision 2.4  1999/01/08  23:31:44  dieter
 * Cleanup synchronization in checkpoint_now.
 *
 * Revision 2.3  1998/12/22  15:39:19  dieter
 * Allocate mutex info in clumps
 * Try getcontext/setcontext instead of sigsetjmp/siglongjmp.
 *
 * Revision 2.2  1998/12/22  15:38:54  dieter
 * version that worked for ftcs paper.
 *
 * Revision 2.1  1998/12/22  15:19:23  dieter
 * Version that worked for ftcs paper.
 *
 * Revision 1.26  1998/12/03  15:05:05  dieter
 * Added include of debug.h to get DBG_PRINTF.
 *
 * Revision 1.25  1998/12/03  15:02:56  dieter
 * changed printfs
 *
 * Revision 1.24  1998/11/23  21:57:16  dieter
 * Added prevent_locks.
 *
 * Revision 1.23  1998/11/23  20:32:46  dieter
 * Wait for all threads to be signalled before proceeding in the sighandler.
 *
 * Revision 1.22  1998/11/23  19:45:20  dieter
 * revert to previous version.
 *
 * Revision 1.21  1998/11/23  19:19:41  dieter
 * Another broken synchronization algorithm.
 *
 * Revision 1.20  1998/09/28  19:11:19  dieter
 * Removed a race condition, where chkpt_done might have been cleared
 * in checkpoint_now after it was set by chkpt_thread.
 *
 * Revision 1.19  1998/09/25  18:51:40  dieter
 * Map memory for thread stacks plus a little more to allow for stack
 * growth during recovery.
 *
 * Revision 1.18  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.17  1998/09/08  21:05:44  dieter
 * Save the stack address separately so that I can restore the stack pointer
 * before loading any segments.  Then load all segments the same way
 * (including the stack segment.)  Otherwise must handle case where the
 * stack consists of multiple segments.
 *
 * Revision 1.16  1998/09/01  15:56:54  dieter
 * Added changes to support libc I/O (fopen, fclose).
 *
 * Revision 1.15  1998/08/31  12:21:14  dieter
 * Save stack size and address for the thread stacks so they will be
 * available during recovery.
 *
 * Revision 1.14  1998/08/28  13:29:59  dieter
 * Reset global variables so the program can take multiple checkpoints.
 *
 * Revision 1.13  1998/08/27  17:58:11  dieter
 * Checkpoint names are now automatically generated.
 *
 * Revision 1.12  1998/08/26  21:24:42  dieter
 * Checkpointing works with timer, but only once.
 *
 * Revision 1.11  1998/08/25  21:16:01  dieter
 * Use checkpoint option value instead of hard coded value for checkpoint
 * interval.
 * Detach the checkpoint thread.
 *
 * Revision 1.10  1998/08/25  20:18:04  dieter
 * Added support for sequential I/O files.
 *
 * Revision 1.9  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.8  1998/08/17  17:03:15  dieter
 * Added the main thread to the thread table.
 *
 * Revision 1.7  1998/08/16  17:38:36  dieter
 * Removed some excess printf's
 *
 * Revision 1.6  1998/08/16  16:59:59  dieter
 * Do not use local variables after sigsetjmp in save_thread_state.  They
 * may not be properly restored.
 *
 * Revision 1.5  1998/08/16  16:42:17  dieter
 * Made changes so that threads checkpoint when they get a SIGUSR1.
 * Recovery does not work yet.
 *
 * Revision 1.4  1998/08/10  19:18:12  dieter
 * Switched from thread info list to hash table of thread info.
 *
 * Revision 1.3  1998/08/10  15:42:42  dieter
 * Modified so that threads autmatically add and remove themselves for
 * the thread_info list.
 * Begin preparations to asynchronously interrupt threads.
 *
 * Revision 1.2  1998/08/03  18:21:23  dieter
 * Pass a structure to recovery_thread so that it does not need to read
 * from the checkpoint file.
 *
 * Revision 1.1  1998/07/31  20:16:40  dieter
 * Initial revision
 *
 */

#include "config.h"

#define MEASURE_PERF
#ifdef MEASURE_PERF
#include <sys/time.h>
#endif
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <errno.h>

#include "debug.h"
#include "memdebug.h"
#include "machif.h"
#include "callback.h"
#include "cppthread.h"
#include "cpstate.h"
#include "cpglobal.h"
#include "barrier.h"
#include "save.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define CHKPT_EXT      ".chkpt." /* extension to append to checkpoint files */
#define MAX_INT_CHARS  20	/* maximum number of chars required to
				 * represent an int.
				 */

#define TM_BUF_SZ 28
#define EXTRA_STACK_BYTES  0x2000

/* value to pass to longjmp... */
#define RECOVERY_RESTORE  1	/* ... when restoring thread stack */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/* replacement threads need the information in this structure to restore
 * the state of the original thread.
 */
typedef struct rep_thr_info {
  chkpt_thread_info_t info;	/* information aobut the new thread          */
  int        nmap;
  memmap_t  *memmap;		/* memory mapping containing thread's stack  */
} rep_thr_info_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

htable_t *chkpt_thr_tab = NULL; /* hash table of thread info		     */

				/* number of threads (other than main thread)*/
int                    num_other_threads = 0;

/* mutex to protect variables associated with threads being ready	     */
static pthread_mutex_t thread_ready_mutex = MUTEX_INITIALIZER;
#if OS == SOLARIS
/* count of other ready threads (not including the main thread)		     */
static int             other_threads_ready = 0;
/* condition to signal when other_threads_ready changes			     */
static pthread_cond_t  others_ready_cond = COND_INITIALIZER;

/* true if main thread ready 						     */
static int             main_ready = 0; 
/* condition to signal when the main thread is ready 			     */
static pthread_cond_t  main_ready_cond = COND_INITIALIZER;
#endif

#if OS == LINUX
				/* ASSUME: main thread has an id of 1024 */
int main_thread_id = 1024;	/* thread id of the "main" thread */
#else
				/* ASSUME: main thread has an id of 1 */
int main_thread_id = 1;		/* thread id of the "main" thread */
#endif
pthread_t chkpt_thread_id = -1;	/* thread id of the "checkpoint" thread */

char *chkpt_filename = NULL;

pthread_mutex_t chkpt_start_mutex = MUTEX_INITIALIZER;
pthread_cond_t  chkpt_start_cond = COND_INITIALIZER;
pthread_cond_t  chkpt_done_cond = COND_INITIALIZER;
int chkpt_start = 0;
int chkpt_done = 0;
int chkpt_count = 0;

pthread_mutex_t dummy_timer_mutex = MUTEX_INITIALIZER;
pthread_cond_t dummy_timer_cond = COND_INITIALIZER;

#if OS == SOLARIS
volatile int prevent_locks = 0;
int all_threads_signalled = 0;
pthread_cond_t thread_signalled_cond = COND_INITIALIZER;

pthread_cond_t sending_sigs_cond = COND_INITIALIZER;
#elif OS == LINUX

norestore_t chkpt_no_restore;
#else
#error Unsupported OS; maybe try Solaris or Linux
#endif

/* The following struct must match the struct in barrier.h except for
 * the of entries number.  It is an ugly way to do this, but I cannot
 * think of a better way.  chkpt_barrier needs to be statically
 * allocated because I cannot dynamically allocate it into the same
 * location after a checkpoint.  It needs to be in the same location
 * after a checkpoint because threads will be looking at it when
 * memory is restored.
 */
struct chkpt_barrier_t_ {
    int num_threads;
    long wait_cnt;
    bar_entry_t entry[MAX_CHKPT_THREADS];
} chkpt_barrier_space;

barrier_t *chkpt_barrier = (barrier_t *)&chkpt_barrier_space;

#ifdef MEASURE_PERF
hrtime_t chkpt_start_time;
hrtime_t chkpt_save_start;
hrtime_t chkpt_save_end;
hrtime_t chkpt_end_time;
#endif

/* make a guess at a signal that might not be used */
#if OS == LINUX
int __chkpt_signal = SIGFPE;
#else
int __chkpt_signal = SIGUSR1;
#endif

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int map_thr_stack(caddr_t stackaddr, size_t stacksize);
void *recovery_thread(void *arg);
static void restore_thread_stack(caddr_t stkbase, sigjmp_buf *thread_env);
int  signal_thread( long key, void *value, void *arg );

void *chkpt_thread(void *arg);
static void wait_for_checkpoint(void);
static int chkpt_get_filename(void);
static void thr_tab_init_barrier(void);
static void thr_info_init_barrier(chkpt_thread_info_t *info, int num_threads);
static int add_tid(long key, void *value, void *arg);

int get_num_lwps(void);

void chkpt_thrlib_cleanup(void);

void print_thr_info(chkpt_thread_info_t *thr_info);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

#if OS == SOLARIS
#include <sys/lwp.h>
#endif

/* ASSUME: This function is called by the main thread before any threads
 * are created.
 */
int chkpt_thread_init(void)
{
  int status;
  struct sigaction action;
  pthread_attr_t attr;

  struct timespec timeout;

#if OS == SOLARIS
  lwp_mutex_t  dummy_lwp_mutex;
  lwp_cond_t   dummy_lwp_cond;
  timestruc_t  lwp_timeout;
#endif
  
  chkpt_thr_tab = new_htable(MAX_CHKPT_THREADS);
  if(chkpt_thr_tab == NULL) {
    return -1;
  }

  main_thread_id = pthread_self();
#if OS == SOLARIS
  /* this is just for my info.  I think it should always be 1, but I want
   * to know if it is not.
   */
  if(main_thread_id != 1) {
    fprintf(stderr, "main_thread_id = %d\n", main_thread_id);
  }

  /* I want to call pthread_cond_timedwait to start up the "timer" thread,
   * but calling pthread_cond_timedwait will cause the only running LWP
   * to block.  Blocking the last running LWP will trigger a scheduler
   * activation that will start another LWP in case there are any unbound
   * threads that need an LWP to run.  The scheduler activation LWP
   * and the timer LWP will race to start up and may start in
   * different orders.  However, calling _lwp_cond_timedwait will
   * force the scheduler activation to happen first.
   */
  /* force the cond var "scheduler activation" before forcing timer thread */
  memset(&dummy_lwp_mutex, 0, sizeof(lwp_mutex_t));
  memset(&dummy_lwp_cond, 0, sizeof(lwp_cond_t));
  _lwp_mutex_lock(&dummy_lwp_mutex);
  lwp_timeout.tv_sec = time(NULL) + 1;
  lwp_timeout.tv_nsec = 0;
  _lwp_cond_timedwait(&dummy_lwp_cond, &dummy_lwp_mutex, &lwp_timeout);
  _lwp_mutex_unlock(&dummy_lwp_mutex);
#else
  /* this is just for my info.  I think it should always be 1, but I want
   * to know if it is not.
   */
  if(main_thread_id != 1024) {
    fprintf(stderr, "main_thread_id = %d\n", main_thread_id);
  }

  chkpt_exclude_region(&chkpt_no_restore, sizeof(norestore_t),
		       CHKPT_EXCL_NOREMAP);
#endif

  /* do a pthread_cond_timedwait to start up a timer lwp */
  pthread_mutex_lock(&dummy_timer_mutex);
  timeout.tv_sec = time(0) + 1;
  timeout.tv_nsec = 0;
  pthread_cond_timedwait(&dummy_timer_cond, &dummy_timer_mutex, &timeout);
  pthread_mutex_unlock(&dummy_timer_mutex);
  
  if(chkpt_opts.restore)
    return 0;

  add_thread_info(main_thread_id, NULL);
  /* add_thread_info increments the number of threads, but we are not
   * adding a new thread here, so decrement it back.
   */
  pthread_mutex_lock(&thread_ready_mutex);
  num_other_threads--;
  pthread_mutex_unlock(&thread_ready_mutex);

  /* by the assumption above, this must be true */
  assert(num_other_threads == 0);

  /* setup the signal handling */
#if HAVE_POSIX_RT_SIGNALS == 1
  /* use a realtime signal for checkpointing */
  /* TODO: is there a way to reserve a signal without interfering with
     the application? */
  __chkpt_signal = SIGRTMAX - 2;
#endif
  action.sa_sigaction = chkpt_sighandler;
  sigemptyset(&action.sa_mask);
  action.sa_flags = SA_SIGINFO|SA_RESTART;

  status = sigaction(CHKPT_SIG, &action, NULL);
  if (status != 0) {
    fprintf(stderr, "cannot set signal handler\n");
    perror("chkpt_thread_init");
    exit(-1);
  }

  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  status = pthread_create( &chkpt_thread_id, &attr, chkpt_thread, NULL );
  if( status != 0 ) {
    fprintf( stderr, "cannot start checkpoint thread\n" );
    fprintf( stderr, "chkpt_thread_init: %s\n", strerror(status) );
    exit(-1);
  }
  pthread_attr_destroy(&attr);

  return 0;
}

void *chkpt_thread(void *arg)
{
  int filename_alloced;
  int recovering;

  while(1) {
    pthread_mutex_lock(&chkpt_start_mutex);
    wait_for_checkpoint();

#ifdef MEASURE_PERF
    chkpt_start_time = gethrtime();
#endif
    filename_alloced = chkpt_get_filename();

    /* need to reinit barrier because number of threads may have changed */
    thr_tab_init_barrier();
    
    /* initialize globals used for synchronization */
#if OS == SOLARIS
    /* TODO: This initialization will work as long as a second checkpoint 
     * does not start before all the threads have continued from the last
     * checkpoint.  Should add more synchronization so that it works in
     * all cases.
     */
    pthread_mutex_lock(&thread_ready_mutex);
    other_threads_ready = 0;
    main_ready = 0;
    pthread_mutex_unlock(&thread_ready_mutex);
#endif

    /* Must allocate space for memmory mappings outside of the signal
     * handler because malloc is not reentrant.  Cannot allocate space
     * in checkpoint thread after stopping other threads because
     * another thread might be holding a lock in a malloc or free call.
     *
     * ASSUME: the number of mappings does not increase much between
     * here and the signal handler.  (allocate_map_info allocates
     * space for a few extra just in case.)
     */
    allocate_map_info(getpid());

    pthread_mutex_lock(&in_chkpt_mutex);
    suspend_threads();
    pthread_mutex_unlock(&in_chkpt_mutex);

    if (filename_alloced) {
      free(chkpt_filename);
      chkpt_filename = NULL;
    }
    recovering = chkpt_recovering;
    chkpt_recovering = 0;
    chkpt_start = 0;
    chkpt_done = 1;
    chkpt_count++;
    pthread_mutex_unlock(&chkpt_start_mutex);
    pthread_cond_broadcast(&chkpt_done_cond);

    if (chkpt_opts.async && !recovering) {
      chkpt_wait_for_async_save();
    }
#ifdef MEASURE_PERF
    chkpt_end_time = gethrtime();
    printf("time from checkpoint start to start of save:  %8f sec\n",
	   ((double)(chkpt_save_start - chkpt_start_time)) / 1000000000.0);
    printf("time to save:                                 %8f sec\n",
	   ((double)(chkpt_save_end - chkpt_save_start)) / 1000000000.0);
    printf("-------------------------------------------- -------------\n");
    if (chkpt_opts.async) {
      printf("total synchronous time                        %8f sec\n", 
	     ((double)(chkpt_save_end - chkpt_start_time)) / 1000000000.0);
      printf("total asynchronous time                       %8f sec\n", 
	     ((double)(chkpt_end_time - chkpt_start_time)) / 1000000000.0);
    } else {
      printf("total time                                    %8f sec\n", 
	     ((double)(chkpt_end_time - chkpt_start_time)) / 1000000000.0);
    }
#endif
    printf("checkpoint done\n");
  }
}

/* must be called with chkpt_start_mutex locked */
static void wait_for_checkpoint(void)
{
  struct timespec  timeout;
  int status;
#ifdef TIMEDWAIT_DEBUG
  char timestr[TM_BUF_SZ];
  time_t now;
#endif

  timeout.tv_sec = time(NULL) + chkpt_opts.period;
  timeout.tv_nsec = 0;
  while(!chkpt_start) {
#ifdef TIMEDWAIT_DEBUG
    now = time(NULL);
    ctime_r( &now, timestr, TM_BUF_SZ );
    printf( "chkpt thread blocking at %s", timestr );
    ctime_r( &timeout.tv_sec, timestr, TM_BUF_SZ );
    printf( "next timeout is at %s", timestr );
#endif
    if( chkpt_opts.period == 0 ) {
      /* never timeout if period is 0 */
      status = pthread_cond_wait( &chkpt_start_cond, &chkpt_start_mutex );
    } else {
      status = pthread_cond_timedwait( &chkpt_start_cond, &chkpt_start_mutex,
				       &timeout );
    }
#ifdef TIMEDWAIT_DEBUG
    now = time(NULL);
    ctime_r( &now, timestr, TM_BUF_SZ-1 );
    printf( "chkpt thread unblocked at %s", timestr );
#endif
    if( status == ETIME ) {
      printf( "checkpoint thread got an ETIME\n" );
      chkpt_start = 1;
    } else if( status  == ETIMEDOUT ) {
      DBG_PRINTF( "checkpoint thread got an ETIMEDOUT\n" );
      printf( "starting checkpoint (due to timeout)\n" );
      chkpt_start = 1;
    }
  }
}

static int chkpt_get_filename(void)
{
  if (chkpt_filename == NULL) {
    chkpt_filename = (char *)malloc(sizeof(char)*(strlen(chkpt_opts.filebase)
						  + strlen(CHKPT_EXT)
						  + MAX_INT_CHARS + 1));
    if(chkpt_filename == NULL) {
      fprintf(stderr, "could not allocate space for checkpoint filename\n");
	exit(-1);
    }
    sprintf(chkpt_filename, "%s"CHKPT_EXT"%d", chkpt_opts.filebase,
	    chkpt_count);
    return 1;
  } 
  return 0;
}

static void thr_tab_init_barrier(void)
{
  pthread_t *tids;
  pthread_t *next_tid;

  tids = (pthread_t *)malloc(sizeof(pthread_t) * (num_other_threads + 1));
  if (tids == NULL) {
    CRASH("cannot allocate tids array for %d threads\n", num_other_threads+1);
  }

  next_tid = tids;
  htable_forall(chkpt_thr_tab, add_tid, &next_tid);
  chkpt_barrier_init(chkpt_barrier, tids, num_other_threads + 1);
  free(tids);
}

static int add_tid(long key, void *value, void *arg)
{
  chkpt_thread_info_t *thr_info = (chkpt_thread_info_t *)value;
  pthread_t **next_tid = (pthread_t **)arg;

  **next_tid = thr_info->id;
  (*next_tid)++;

  return 0;
} 

int chkpt_now(char *filename)
{
  chkpt_filename = filename;
  pthread_mutex_lock(&chkpt_start_mutex);
  chkpt_done = 0;
  /* TODO: make sure it is not too soon since the last checkpoint */
  chkpt_start = 1;
  pthread_cond_signal(&chkpt_start_cond);

  while(!chkpt_done) {
    pthread_cond_wait(&chkpt_done_cond, &chkpt_start_mutex);
  }
  chkpt_filename = NULL;
  pthread_mutex_unlock(&chkpt_start_mutex);
 
  return 0;
}

void restore_threads( int fd )
{
  int 		       status;	/* return code from system calls	     */
  chkpt_thread_info_t *info;	/* thread information read from checkpoint   */
  int                  nmap;	/* number of memory mappings		     */
  memmap_t            *mappings; /* actual mapping data			     */
  pthread_t	       tid;	/* thread id of newly created thread	     */
  int 		       n_threads; /* number of threads			     */
  int 		       thr_count; /* loop index				     */
  pthread_attr_t       attr;	/* thread attributes of thread to be created */
  rep_thr_info_t      *rep_info; /* information needed by replacement thread */
  caddr_t              endds;	/* end of the heap (not used, but needed)    */
  caddr_t	       stkbase;

  read( fd, &n_threads, sizeof(int) );
  info = (chkpt_thread_info_t *)malloc(n_threads*sizeof(chkpt_thread_info_t));
  if( info == NULL ) {
    fprintf( stderr, "restore_threads: could not allocate info structure\n" );
    exit( -1 );
  }
  read( fd, info, sizeof(chkpt_thread_info_t) * n_threads );
  thr_info_init_barrier(info, n_threads);
#if OS == LINUX
  read( fd, &manager_env, sizeof(sigjmp_buf) );
#endif

  read( fd, &nmap, sizeof(int) );
  read( fd, &endds, sizeof(caddr_t) );
  read( fd, &stkbase, sizeof(caddr_t) );
  mappings = (memmap_t *)malloc( nmap * sizeof(memmap_t) );
  if( mappings == NULL ) {
    fprintf( stderr, "restore_threads: could not allocate memmap strcture\n" );
    exit(-1);
  }
  read( fd, mappings, nmap * sizeof(memmap_t) );

  /* move the file pointer back to where chkpt_restore_state expects it */
  lseek( fd, -(sizeof(int) + 2*sizeof(caddr_t) + nmap * sizeof(memmap_t)),
	 SEEK_CUR );
  
  pthread_attr_init( &attr );

  for( thr_count = 0 ; thr_count < n_threads ; thr_count++ ) {
    if( info[thr_count].id != pthread_self() ) {
      pthread_attr_setscope(      &attr, info[thr_count].attr.contentionscope);
      pthread_attr_setdetachstate(  &attr, info[thr_count].attr.detachstate );
#if HAVE_PTHREAD_ATTR_SETSTACKSIZE == 1
      pthread_attr_setstacksize(    &attr, info[thr_count].attr.stacksize );
      pthread_attr_setstackaddr(    &attr, info[thr_count].attr.stackaddr );
#endif
      pthread_attr_setschedparam(   &attr, &info[thr_count].attr.param );
      pthread_attr_setschedpolicy(  &attr, info[thr_count].attr.policy );
      pthread_attr_setinheritsched( &attr, info[thr_count].attr.inheritsched );

      /* the thread library may be unhappy because the thread's stack is
       * not in mapped memory.  Try manually mapping the thread's stack
       * with mmap.
       */
      map_thr_stack(info[thr_count].attr.stackaddr,
		    info[thr_count].attr.stacksize);
      
      /* I allocate this memory here, but never free it.  That is ok
       * because malloc's state will be overwritten when the checkpoint
       * is restored.  The threads using the information will read it
       * before signalling the condition variable below, so they
       * will not try to access it after it has be overwritten by
       * reloading the checkpoing.
       */
      rep_info = (rep_thr_info_t *)malloc( sizeof(rep_thr_info_t) );
      if( rep_info == NULL ) {
	fprintf( stderr, "could not allocate replacement thread info\n" );
	exit( -1 );
      }
      rep_info->info = info[thr_count];
      rep_info->nmap = nmap;
      rep_info->memmap = mappings;
      status = pthread_create(&tid, &attr, recovery_thread, (void *)rep_info);
      if(status != 0) {
	fprintf(stderr, "cannot create recovery thread\n");
	fprintf(stderr, "pthread_create: %s\n", strerror(status));
	exit(-2);
      }
    }
  }

  pthread_attr_destroy( &attr );

#if OS == SOLARIS
  pthread_mutex_lock( &thread_ready_mutex );
  /* n_threads-1 because we don't need to wait for the main thread.
   * This thread is the main thread.
   */
  while( other_threads_ready < n_threads-1 ) {
    pthread_cond_wait( &others_ready_cond, &thread_ready_mutex );
  }
  pthread_mutex_unlock( &thread_ready_mutex );
#else
  /* during the checkpoint the checkpointing library does two
     barrier_wait's before saving the addr space.  Do two here
     so that the barrier counts match when the addr space is loaded.
     Then wait to make sure they make it to the barrier before
     overwriting the address space.
  */
  chkpt_barrier_wait(chkpt_barrier);
  chkpt_barrier_wait(chkpt_barrier);
  chkpt_barrier_wait_for_others(chkpt_barrier);

  chkpt_no_restore.num_pids = MAX_CHKPT_THREADS;
  /* WARNING: pthread_chkpt_restart will cause manager thread to longjmp to
     a stack location in the heap, which may be in use by some other thread
     (until memory is restored).  No code after the call to
     pthread_chkpt_prerestart can safely use anything on the heap.
  */
  chkpt_restart_manager = 0;
  pthread_chkpt_prerestart(&chkpt_no_restore.thr_pids[0],
			   &chkpt_no_restore.num_pids, &manager_env);
#endif
}

static void thr_info_init_barrier(chkpt_thread_info_t *info, int num_threads)
{
  pthread_t *tids;
  int i;

  tids = (pthread_t *)malloc(sizeof(pthread_t) * num_threads);
  if (tids == NULL) {
    CRASH("cannot allocate tids array for %d threads\n", num_other_threads+1);
  }

  for(i = 0 ; i < num_threads ; i++) {
    tids[i] = info[i].id;
  }
  chkpt_barrier_init(chkpt_barrier, tids, num_threads);
  free(tids);
}



int map_thr_stack(caddr_t stackaddr, size_t stacksize)
{
  int fd;
  caddr_t result;

  fd = open("/dev/zero", O_RDWR);
  if (fd == -1) {
    fprintf(stderr, "could not open /dev/zero\n");
    perror("open");
    return -1;
  }

  /* When some threads are recovering, they seem to have a problem growing
   * their stacks beyond what is specified for the stack.  It may be that
   * if the user specifies a size and address for the stack, that the
   * system does not try to grow it automatically.  This is a problem
   * during recovery, because I move the stack pointer past the old
   * top of stack so that when the stack is reloaded from the checkpoint
   * it will not interfere with current stack frame.  Growing past the end
   * of the requested stack seems not to be a problem with 5 or less threads.
   * With 6 or more, however, it is a problem.
   * 
   * I will map several extra pages to allow the stack to grow past the
   * requested size without running into unmapped memory.  Hopefully,
   * the system will still be able to grow the stacks should they need
   * to grow even larger.  -wrd 09/25/98
   */
  stackaddr -= EXTRA_STACK_BYTES;
  stacksize += EXTRA_STACK_BYTES;

  result = mmap(stackaddr, stacksize, PROT_READ|PROT_WRITE|PROT_EXEC,
		MAP_PRIVATE|MAP_FIXED, fd, 0);
  if(result == MAP_FAILED) {
    fprintf(stderr, "failed to map a thread stack\n");
    perror("mprotect");
    close(fd);
    return -1;
  }
  if(result != stackaddr) {
    /* this should never happen */
    fprintf(stderr, "mmap succeeded, but at the wrong address\n");
    exit(-1);
  }

  close(fd);

  return 0;
}

/*
 * Recovery assumes that threads will be created exactly the same way
 * they were in the original program.  That is thread id's will be
 * given out in the same order, each thread will have a stack in the
 * same place, and the internal thread library data structures will be
 * happy even after they are reloaded from a checkpoint.
 */
void *recovery_thread(void *arg)
{
  int i;			/* loop index				    */
  rep_thr_info_t *rep_info;	/* info need to restore state of the thread */

  rep_info = (rep_thr_info_t *)arg;

  for( i = 0 ; i < rep_info->nmap ; i++ ) {

    if( rep_info->memmap[i].type == SEG_TSTK
	&& (rep_info->memmap[i].addr < (caddr_t)rep_info->info.stack_item)
	&& ((caddr_t)rep_info->info.stack_item
	    < rep_info->memmap[i].addr + rep_info->memmap[i].len) ) {
      /* this thread stack has the stack_item on it */
      restore_thread_stack(rep_info->memmap[i].addr, &(rep_info->info.jmp_buf));
      /* this line is never executed */
    }
  }
  /* this line should never be executed */
  assert(0);

  return NULL;
}

void add_thread_info(pthread_t tid, const pthread_attr_t *attr)
{
  chkpt_thread_info_t *new_info;
  chkpt_mutex_info_t *mutex_info;
  int mutex_index;
  
  new_info = (chkpt_thread_info_t *)malloc(sizeof(chkpt_thread_info_t));
  if( new_info == NULL ) {
    fprintf( stderr, "cannot allocate thread info structure\n" );
    exit(-1);
  }

  new_info->id = tid;
  new_info->held_mutexes = NULL;
  new_info->status = 0;
  pthread_mutex_init(&new_info->sig_mutex, NULL);
  new_info->free_mutexes =
    (chkpt_mutex_info_t *)malloc(MUTEX_INFO_INCR * sizeof(chkpt_mutex_info_t));
  if(new_info->free_mutexes != NULL) {
    mutex_info = new_info->free_mutexes;
    for(mutex_index = 0 ; mutex_index < (MUTEX_INFO_INCR-1) ; mutex_index++) {
      mutex_info[mutex_index].next = mutex_info + mutex_index + 1;
    }
    mutex_info[mutex_index].next = NULL;
  }
  memset(&new_info->attr, 0, sizeof(pthread_attr_t));
  /* linux does not like NULL attr passed to pthread_attr_xxx */
  if (attr != NULL) {
    pthread_attr_getscope(        attr, &new_info->attr.contentionscope );
    pthread_attr_getdetachstate(  attr, &new_info->attr.detachstate );
    /* stackaddr and stacksize will be overwriiten because we compute the 
     * stack address in check_for_thr_stack
     */
#if HAVE_PTHREAD_ATTR_SETSTACKSIZE == 1
    pthread_attr_getstacksize(    attr, &new_info->attr.stacksize );
    pthread_attr_getstackaddr(    attr, &new_info->attr.stackaddr );
#endif
    pthread_attr_getschedparam(   attr, &new_info->attr.param );
    pthread_attr_getschedpolicy(  attr, &new_info->attr.policy );
    pthread_attr_getinheritsched( attr, &new_info->attr.inheritsched );
  }

  if( htable_add( chkpt_thr_tab, tid, new_info ) != 0 ) {
    fprintf( stderr, "could not add new thread info\n" );
    exit(-1);
  }

  pthread_mutex_lock( &thread_ready_mutex );
  num_other_threads++;
  pthread_mutex_unlock( &thread_ready_mutex );
}

void remove_thread_info( pthread_t tid )
{
  chkpt_thread_info_t *info;

  if( htable_find( chkpt_thr_tab, tid, (void **)&info ) != 0 ) {
    fprintf( stderr, "remove_thread_info: cannot find thread info\n" );
    exit(-1);
  }

  htable_delete( chkpt_thr_tab, tid );
  free( info );

  pthread_mutex_lock( &thread_ready_mutex );
  num_other_threads--;
  pthread_mutex_unlock( &thread_ready_mutex );
#if OS == SOLARIS
  /* decrementing num_other_threads may have made the "all other threads
   * ready" condition true, so signal others_ready_cond
   */
  pthread_cond_signal( &others_ready_cond );
#endif
}

int save_thread_state(void)
{
  sigjmp_buf *thread_env;
  chkpt_thread_info_t *my_info;
  pthread_t my_id;
  
  my_id = pthread_self();

  if( htable_find( chkpt_thr_tab, my_id, (void **)&my_info ) != 0 ) {
    fprintf(stderr, "cannot find info for thread "PTHREAD_FMT"\n", my_id );
    exit( -1 );
  } 

  thread_env = &my_info->jmp_buf;

  my_info->stack_item = &my_info;

  chkpt_barrier_wait(chkpt_barrier);
  sigpending(&my_info->pending);
  if (sigsetjmp( *thread_env, 1 ) != 0) {
    /* need an extra barrier when recovering to compensate for the
       sigpending barrier_wait above.
    */
    chkpt_barrier_wait(chkpt_barrier);
  }
  /* WARNING: DO NOT USE ANY LOCAL VARIABLES BETWEEN HERE AND THE END OF
   * 	      THIS FUNCTION.  Setjmp does not guarantee that they are saved
   *          so things may happen (including core dumps).
   */
  
#if OS == SOLARIS
  pthread_mutex_lock( &thread_ready_mutex );
  other_threads_ready++;
  pthread_cond_signal( &others_ready_cond );
  while( !main_ready ) {
    pthread_cond_wait( &main_ready_cond, &thread_ready_mutex );
  }
  pthread_mutex_unlock( &thread_ready_mutex );
#else
  chkpt_barrier_wait(chkpt_barrier);
  chkpt_barrier_wait(chkpt_barrier);
#endif

  return chkpt_recovering;
}

void wait_for_other_threads(void)
{
#if OS == SOLARIS
  /* wait other threads to save thier stack pointer info (i.e.,call setjmp) */
  pthread_mutex_lock( &thread_ready_mutex );
  while( other_threads_ready < num_other_threads ) {
    pthread_cond_wait( &others_ready_cond, &thread_ready_mutex ); 
  }
  pthread_mutex_unlock( &thread_ready_mutex );

  /* all other threads have saved their local info; take the checkpoint */
#else
  chkpt_barrier_wait(chkpt_barrier);
  chkpt_barrier_wait_for_others(chkpt_barrier);
#endif
}

void continue_other_threads(void)
{
#if OS == SOLARIS
  /* let all threads continue */
  pthread_mutex_lock( &thread_ready_mutex );
  main_ready = 1;
  pthread_mutex_unlock( &thread_ready_mutex );
  pthread_cond_broadcast( &main_ready_cond );
#else
  chkpt_barrier_wait(chkpt_barrier);
#endif
}

#if OS == SOLARIS
extern int (*real_pthread_mutex_lock)(pthread_mutex_t *mp);
extern int (*real_pthread_mutex_unlock)(pthread_mutex_t *mp);

int threads_to_signal;

void suspend_threads(void)
{
  int status;
  chkpt_thread_info_t *thr_info;

  /* do not allow any mutex_lock calls to succeed until
   * all threads are in the signal handler
   */
  /* TODO: need to add synchronization around set of prevent_locks
   * to make sure it is flushed to memory on SMP machines?  Probably,
   * pthread_mutex_unlock after prevent_locks is enough.
   */
  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );
  thr_info->status |= THR_IN_SIGHANDLER;

  pthread_mutex_lock(&thread_ready_mutex);
  prevent_locks = 1;
  threads_to_signal = num_other_threads;
  pthread_mutex_unlock(&thread_ready_mutex);

  while(threads_to_signal > 0) {
    htable_forall( chkpt_thr_tab, signal_thread, (void *)CHKPT_SIG );
    sched_yield();
  }

  /* sent signal to all other threads, now send a signal to myself */
  pre_chkpt_callbacks(chkpt_count);
  status = pthread_kill(pthread_self(), CHKPT_SIG);
  if( status != 0 ) {
    fprintf(stderr, "cannot send sig %d to self (id = "PTHREAD_FMT")\n",
	    CHKPT_SIG, pthread_self());
    fprintf(stderr, "signal_thread: %s\n", strerror(status));
  }
  if (!chkpt_recovering) {
    post_chkpt_callbacks(chkpt_count);
  } else {
    recovery_callbacks(chkpt_count);
  }
}

int  signal_thread( long key, void *value, void *arg )
{
  chkpt_thread_info_t *thr_info;
  int sig;
  int status;
  int send_sig;

  sig = (int)arg;
  thr_info = (chkpt_thread_info_t *)value;

  /* don't send a signal to myself */
  if( thr_info->id == pthread_self() ) {
    return 0;
  }

  real_pthread_mutex_lock(&thr_info->sig_mutex);
  /*  send_sig = !(thr_info->status & (THR_LOCKING_MUTEX|THR_SIGNALLED)); */
  send_sig = ((thr_info->status & THR_SIGNALLED) != THR_SIGNALLED)
    && ( ( (thr_info->status & THR_LOCKING_MUTEX) != THR_LOCKING_MUTEX)
	 || ( (thr_info->status & THR_COND_WAIT) == THR_COND_WAIT));
  if(send_sig) {
    thr_info->status |= THR_SIGNALLED;
    threads_to_signal--;
    status = pthread_kill( thr_info->id, sig );
    if( status != 0 ) {
      fprintf( stderr, "cannot send sig %d to thread "PTHREAD_FMT"\n",
	       sig, thr_info->id );
      fprintf( stderr, "signal_thread: %s\n", strerror(status) );
    }
  } else {
    status = 0;
  }
  real_pthread_mutex_unlock(&thr_info->sig_mutex);

  return status;
}

#elif OS == LINUX

void suspend_threads(void)
{
  int status;

  htable_forall( chkpt_thr_tab, signal_thread, (void *)CHKPT_SIG );

  /* sent signal to all other threads, now send a signal to myself */
  if ( (status = pthread_kill(pthread_self(), CHKPT_SIG)) != 0 ) {
    fprintf(stderr, "cannot send sig %d to self (id = %ld)\n",
	    CHKPT_SIG, pthread_self());
    fprintf(stderr, "signal_thread: %s\n", strerror(status));
  }
  if (!chkpt_recovering) {
    post_chkpt_callbacks(chkpt_count);
  } else {
    recovery_callbacks(chkpt_count);
  }
  if ( (status = chkpt_barrier_wait(chkpt_barrier)) < 0) {
    fprintf(stderr, "barrier_wait retured %d\n", status);
    exit(-1);
  }
}

int  signal_thread( long key, void *value, void *arg )
{
  chkpt_thread_info_t *thr_info;
  int sig;
  int status;

  sig = (int)arg;
  thr_info = (chkpt_thread_info_t *)value;

  /* don't send a signal to myself */
  if( thr_info->id == pthread_self() ) {
    return 0;
  }
#ifdef SIGNAL_DEBUG
  printf("signalling thread %ld\n", thr_info->id);
  print_thr_info(thr_info);
#endif

  if ( (status = pthread_kill( thr_info->id, sig )) != 0) {
    fprintf( stderr, "cannot send sig %d to thread %ld\n", sig, thr_info->id );
    fprintf( stderr, "signal_thread: %s\n", strerror(status) );
  }

  return status;
}
#else
#error Unsupported OS.  Maybe try using the code for Linux?
#endif


void print_thr_info(chkpt_thread_info_t *info)
{
  printf("id = "PTHREAD_FMT"\n", info->id);
  printf("stack_item = %p\n", info->stack_item);
}

void save_pending_signals(void) 
{
  chkpt_thread_info_t *thr_info;
  
  thr_info = NULL;
  if( htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info ) != 0 ) {
    CRASH("cannot find info for thread "PTHREAD_FMT"\n", pthread_self());
  } 
  
  /* no thread will send any signals after everyone has entered the
     checkpoint signal handler */
  chkpt_barrier_wait(chkpt_barrier);
  sigpending(&thr_info->pending);
}  

/*
 * NOTE: During recovery, the address space is restored while the
 * calling thread is blocked on the lost call to chkpt_barrier_wait.
 * in restore_thread_stack.  As usual the return address from
 * chkpt_barrier_wait is pushed on the stack when the call is made.
 * When the address space gets restored the return address from the
 * call to chkpt_barrier_wait gets replaced with the address at
 * the time of the checkpoint.  The synchronization works out ok,
 * because the call returns to the same place regardless of whether
 * the process is checkpointing or recovering.
 *
 * We do not want to try making the the stack pointer go up past end
 * of the old stack because the new part of the stack will be seen
 * as a different memory segment and the checkpointing library will
 * end up writing over the stack for second generation checkpoints.
 */
void restore_thread_stack(caddr_t stkbase, sigjmp_buf *thread_env)
{
  sigset_t sigmask;

  /* block all signals until recovery is complete */
  sigfillset( &sigmask );
#if OS == LINUX
  /* the Linux thread library needs SIGUSR1 and SIGUSR2 to wake up threads */  
  sigdelset(&sigmask, SIGUSR1);
  sigdelset(&sigmask, SIGUSR2);
  sigaddset(&sigmask, CHKPT_SIG);
  sigaddset(&sigmask, BARRIER_SIG);
#endif
  pthread_sigmask(SIG_BLOCK, &sigmask, NULL);

  /* jumps to save_thread_state */
  siglongjmp(*thread_env, RECOVERY_RESTORE);
}

#if 0
/* restore_thread_stack used to grow the stack before calling longjmp,
 * however, the thread stack is always mapped (at least under
 * solaris), so this is not necessary.
 */
void restore_thread_stack( memmap_t *memmap, sigjmp_buf *thread_env )
{
  memmap_t  local_memmap;
  sigjmp_buf local_env;
  sigset_t sigmask;

  local_memmap = *memmap;

  /* grow the thread stack beyond what will be restored */
  if( (caddr_t)memmap > local_memmap.addr
      || (caddr_t)memmap < (caddr_t)&local_memmap ) {
    restore_thread_stack( &local_memmap, thread_env );
  }
  /* thread_env may (does) point into the stack.  Make a local
   * copy before loading the stack.  Otherwise, it will get
   * overwritten when the thread stack remapped
   */
  /* TODO: this should no longer be necessary because we do not remap
   * the stack until after the longjmp
   */

  memcpy(&local_env,thread_env,sizeof(local_env));

  /* block all signals until recovery is complete */
  sigfillset( &sigmask );
#if OS == LINUX
  /* the Linux thread library needs SIGUSR1 and SIGUSR2 to wake up threads */  
  sigdelset(&sigmask, SIGUSR1);
  sigdelset(&sigmask, SIGUSR2);
#endif
  pthread_sigmask( SIG_BLOCK, &sigmask, NULL );
  siglongjmp( local_env, RECOVERY_RESTORE );
}
#endif

#if 0

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <procfs.h>

int get_num_lwps(void)
{
  pstatus_t pstatus;
  int fd;
  int status;

  fd = open("/proc/self/status", O_RDONLY);
  if (fd == -1) {
    perror("cannot open /proc/self/status to read nlwps");
    exit(-1);
  }

  status = read(fd, &pstatus, sizeof(pstatus_t));
  if (status < sizeof(pstatus_t)) {
    perror("get_num_lwps: could not read entire file");
    exit(-1);
  }

  close(fd);

  return pstatus.pr_nlwp;
}

#endif
