/*
  memdebug.c

  Memory corruption debugging routines

  History
  -------
  $Log: memdebug.c,v $
  Revision 6.1  2000/05/02 20:09:42  dieter
  Released version 0.6.

  Revision 5.1  2000/02/01 23:38:13  dieter
  Release 0.5 plus some fixes

  Revision 4.2  2000/02/01 21:21:58  dieter
  print AllocCount inside mutex lock.

  Revision 4.1  1999/08/02 15:11:45  dieter
  Moving to version 4.1
  This is essentially the version reported in FTCS-29.

 * Revision 2.1  1998/12/22  15:27:46  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.2  1998/12/03  20:32:20  dieter
 * Use a mutex by default.
 *
 * Revision 1.1  1998/09/15  14:34:24  dieter
 * Initial revision
 *
 * Revision 1.1  1997/11/03  23:10:36  dieter
 * Initial revision
 *
 */

#define MEM_DEBUG_H		/* no macro definitions from memdebug.h here */

#define USE_A_MUTEX

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef USE_A_MUTEX
#include <pthread.h>
#endif

#define MEM_ALLOCATED   (0x00000001L)	/* this block is allocated */

typedef struct mem_debug_info {
  size_t                 size;
  char                  *file;
  int                    line;
  long			 count;
  long                   status;
  struct mem_debug_info *next;
  struct mem_debug_info *prev;
} MemDebugInfo;

int AllocCount = 0;		/* TODO: does this need a mutex?  */
int AllocCompare = 0;

int MemDebugLevel = 0;

unsigned long MemDebugTrash = 0xdeadbeef;
unsigned long MemAllocated = 0;
unsigned long DataAllocated = 0;

#ifdef USE_A_MUTEX
pthread_mutex_t MemDebugMutex;
#endif

MemDebugInfo *MemDebugList = NULL;

FILE *memd_outfile;

void  DebugMemCheck( void );
void  CheckBlock( MemDebugInfo *block );
int   CompareMemDebugInfo( MemDebugInfo *block1, MemDebugInfo *block2 );
void  PrintDebugInfo( MemDebugInfo *block, int PrintFile );
void  FillWithTrash( void *addr, int size );
void BreakOnAlloc( void ); 
void BreakOnFree( void );


void MemDebugInit( void )
{
#ifdef USE_A_MUTEX
  if( pthread_mutex_init( &MemDebugMutex, NULL ) < 0 ) {
    fprintf( stderr, "MemDebugInit: cannot init mutex\n" );
    exit(1);
  }
#endif

  MemDebugList = NULL;
}

void *DebugMalloc( size_t size, char *file, int line )
{
  MemDebugInfo *mem;
  int  dataSize;
  MemDebugInfo *end;

  /*  DebugMemCheck(); */

  if( (size % sizeof(long)) == 0 )
    dataSize = size;
  else
    dataSize = size + (sizeof(long) - size % sizeof(long));
  
  mem = (MemDebugInfo *)malloc( 2*sizeof(MemDebugInfo) + dataSize );
  if( mem == NULL )
    return NULL;

#ifdef USE_A_MUTEX
  _pthread_mutex_lock( &MemDebugMutex );
#endif
  
  AllocCount++;
  if( AllocCount == AllocCompare ) {
    BreakOnAlloc();
  }

  MemAllocated += 2*sizeof(MemDebugInfo) + dataSize;
  DataAllocated += dataSize;

  /* write the header */
  
  mem->size = dataSize;
  mem->file = file;
  mem->line = line;
  mem->count = AllocCount;
  mem->status = MEM_ALLOCATED;
  mem->next = MemDebugList;
  mem->prev = NULL;

  end = (MemDebugInfo *)(((char *)mem) + dataSize + sizeof(MemDebugInfo));

  end->size = dataSize;
  end->file = file;
  end->line = line;
  end->count = AllocCount;
  end->status = MEM_ALLOCATED;
  end->next = NULL;
  end->prev = NULL;

  if( MemDebugList != NULL ) {
    MemDebugList->prev = mem;
  }
  MemDebugList = mem;

#ifdef USE_A_MUTEX
  _pthread_mutex_unlock( &MemDebugMutex );
#endif

  if( MemDebugLevel > 5 ) {
    fprintf(stderr,
	    "malloc (%d): size %d, file %s, line %d, returned addr %lx\n",
	    AllocCount, size, file, line, (unsigned long)(mem + 1));
  }
  
  FillWithTrash( mem + 1, mem->size );

  return (void *)(mem + 1);
}

void *DebugCalloc( size_t nelem, size_t elsize, char *file, int line )
{
  MemDebugInfo *mem;
  MemDebugInfo *end;
  int  dataSize;
  int  size;

  size = nelem * elsize;
  if( (size % sizeof(long)) == 0 )
    dataSize = size;
  else
    dataSize = size + (sizeof(long) - size % sizeof(long));
  
  mem = (MemDebugInfo *)calloc( 2*sizeof(MemDebugInfo) + dataSize, 1 );
  if( mem == NULL )
    return NULL;

#ifdef USE_A_MUTEX
  _pthread_mutex_lock( &MemDebugMutex );
#endif
  
  AllocCount++;
  if( AllocCount == AllocCompare ) {
    BreakOnAlloc();
  }

  MemAllocated += 2*sizeof(MemDebugInfo) + dataSize;
  DataAllocated += dataSize;

  mem->size = dataSize;
  mem->file = file;
  mem->line = line;
  mem->count = AllocCount;
  mem->status = MEM_ALLOCATED;
  mem->next = MemDebugList;
  mem->prev = NULL;

  end = (MemDebugInfo *)(((char *)mem) + dataSize + sizeof(MemDebugInfo));

  end->size = dataSize;
  end->file = file;
  end->line = line;
  end->count = AllocCount;
  end->status = MEM_ALLOCATED;
  end->next = NULL;
  end->prev = NULL;

  if( MemDebugList != NULL ) {
    MemDebugList->prev = mem;
  }
  MemDebugList = mem;

#ifdef USE_A_MUTEX
  _pthread_mutex_unlock( &MemDebugMutex );
#endif

  if( MemDebugLevel > 5 ) {
    fprintf(stderr,
	    "calloc (%d): nelem %d, elsize %d, file %s, line %d, returned addr %lx\n",
	    AllocCount, nelem, elsize, file, line, (unsigned long)(mem + 1));
  }

  
  return (void *)(mem + 1);
}

void  DebugFree( void *ptr, char *file, int line )
{
  MemDebugInfo *mem;

  if( ptr == NULL ) {
    
    fprintf( stderr, "Free of NULL pointer at " );
    fprintf( stderr, "%s:%d\n", file, line );
    return;
  }
  
  mem = ((MemDebugInfo *)ptr) - 1;

  CheckBlock( mem );
  if( (mem->status & MEM_ALLOCATED) == 0 ) {
    fprintf( stderr, "Free of already freed block\n" );
    PrintDebugInfo( mem, 1 );
    abort();
  }
  mem->status = mem->status & ~MEM_ALLOCATED;

  if( mem->count == AllocCompare ) {
    BreakOnFree();
  }

#ifdef USE_A_MUTEX
  _pthread_mutex_lock( &MemDebugMutex );
#endif
  if( mem->next != NULL ) {
    mem->next->prev = mem->prev;
  }

  if( mem->prev != NULL ) {
    mem->prev->next = mem->next;
  } else {
    MemDebugList = mem->next;
  }

  MemAllocated -= 2*sizeof(MemDebugInfo) + mem->size;
  DataAllocated -= mem->size;

#ifdef USE_A_MUTEX
  _pthread_mutex_unlock( &MemDebugMutex );
#endif
  
  FillWithTrash( mem + 1, mem->size );

  if( MemDebugLevel > 5 ) {
    fprintf( stderr, "free: file %s, line %d, addr %lx\n",
	     file, line, (unsigned long)ptr);
  }

  free( mem );
}

void *DebugMemalign( size_t alignment, size_t size, char *file, int line )
{
  fprintf(stderr, "Warning: DebugMemalign may not work right\n" );
  fprintf(stderr, "memalign called from %s:%d\n", file, line );
  return memalign( alignment, size );
}

void *DebugRealloc( void *ptr, size_t size, char *file, int line )
{
  MemDebugInfo *mem;
  MemDebugInfo *newMem;
  MemDebugInfo *end;
  int  dataSize;

  mem = ((MemDebugInfo *)ptr) - 1;

  CheckBlock( mem );
  if( (mem->status & MEM_ALLOCATED) == 0 ) {
    fprintf( stderr, "Realloc of already freed block\n" );
    PrintDebugInfo( mem, 1 );
    abort();
  }

  if( (size % sizeof(MemDebugInfo)) == 0 )
    dataSize = size;
  else
    dataSize = size + (sizeof(MemDebugInfo) - size % sizeof(MemDebugInfo));
  
  newMem = (MemDebugInfo *)realloc( mem, 2*sizeof(MemDebugInfo) + dataSize );
  if( newMem == NULL )
    return NULL;

#ifdef USE_A_MUTEX
  _pthread_mutex_lock( &MemDebugMutex );
#endif
  
  MemAllocated -= mem->size;
  DataAllocated -= mem->size;

  MemAllocated += dataSize;
  DataAllocated += dataSize;

  /* only update the file, line, and size info */

  if( newMem != mem ) {
    if( newMem->next != NULL ) {
      newMem->next->prev = newMem;
    }

    if( newMem->prev != NULL ) {
      newMem->prev->next = newMem;
    } else {
      MemDebugList = newMem;
    }
  }

  newMem->size = dataSize;
  newMem->file = file;
  newMem->line = line;

  end = (MemDebugInfo *)(((char *)newMem) + dataSize + sizeof(MemDebugInfo));

  end->size = dataSize;
  end->file = file;
  end->line = line;
  
#ifdef USE_A_MUTEX
  _pthread_mutex_unlock( &MemDebugMutex );
#endif
  
  return (void *)(newMem + 1);
}

void *DebugValloc( size_t size, char *file, int line )
{
  fprintf(stderr, "Warning: DebugMemalign may not work right\n" );
  fprintf(stderr, "memalign called from %s:%d\n", file, line );
  return valloc( size );
}

void  DebugMemCheck( void )
{
  MemDebugInfo *mem;

#ifdef USE_A_MUTEX
  _pthread_mutex_lock( &MemDebugMutex );
#endif

  mem = MemDebugList;
  while( mem != NULL ) {
    CheckBlock( mem );
    mem = mem->next;
  }

#ifdef USE_A_MUTEX
  _pthread_mutex_unlock( &MemDebugMutex );
#endif
  
}

void  CheckBlock( MemDebugInfo *block )
{
  MemDebugInfo *end;

  end = (MemDebugInfo *)(((char *)block) + block->size + sizeof(MemDebugInfo));
  if( block->size != end->size ) {
    fprintf( stderr, "Size mismatch in block starting at %p\n", block );
    fprintf( stderr, "Block Header:\n" );
    PrintDebugInfo( block, 1 );
    fprintf( stderr, "Block Trailer:\n" );
    PrintDebugInfo( end, 0 );
    abort();
  }
  if( !CompareMemDebugInfo( block , end ) ) {
    fprintf( stderr, "Block header and block trailer do not match\n" );
    fprintf( stderr, "Block Header:\n" );
    PrintDebugInfo( block, 1 );
    fprintf( stderr, "Block Trailer:\n" );
    PrintDebugInfo( end, 0 );
    abort();
  }
}

/* return true if same, false if different */
int CompareMemDebugInfo( MemDebugInfo *block1, MemDebugInfo *block2 )
{
  return ( block1->size == block2->size
	   && block1->file == block2->file
	   && block1->line == block2->line
	   && block1->count == block2->count );
}

void PrintDebugInfo( MemDebugInfo *block, int PrintFile )
{
  if (PrintFile)
    fprintf( stderr, "Block allocated at %s:%d\n", block->file, block->line );
  else
    fprintf( stderr, "Block allocated at %s:%d\n", block->file, block->line );
  fprintf( stderr, "size = %d\n", block->size );
  fprintf( stderr, "count = %ld\n", block->count );
}

void  FillWithTrash( void *addr, int size )
{
  memset( addr, MemDebugTrash, size );
}

void BreakOnAlloc( void ) 
{
  return;
}

void BreakOnFree( void ) 
{
  return;
}
