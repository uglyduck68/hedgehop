/*
 * exclude.h
 *
 * Internal interface to memory exclusion.
 *
 * History
 * -------
 * $Log: exclude.h,v $
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 1.2  1999/01/20  00:16:26  dieter
 * Added prototype for chkpt_intersect_map
 *
 * Revision 1.1  1999/01/13  20:00:45  dieter
 * Initial revision
 *
 */

#ifndef EXCLUDE_H
#define EXCLUDE_H

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int  chkpt_num_exclude_regions(void);
int chkpt_count_excl_maps(int nmap, memmap_t *mapping);
void chkpt_intersect_map(int *nmap, memmap_t *mapping);

#endif /* EXCLUDE_H */
