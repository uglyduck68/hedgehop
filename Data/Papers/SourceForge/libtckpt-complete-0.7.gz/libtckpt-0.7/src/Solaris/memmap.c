/*
 * memmap.c
 *
 * This file contains functions that get the memory mapping
 * information from Solaris and put it in a machine independent
 * format.
 *
 * History
 * -------
 * $Log: memmap.c,v $
 * Revision 6.2  2000/05/08 19:10:29  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:13:09  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:39:11  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 4.3  2000/01/31 15:50:15  dieter
 * Fixed typo in allocate_map_info.
 *
 * Revision 4.2  2000/01/28  21:15:31  dieter
 * Added allocate_map_info to match Linux changes.
 *
 * Revision 4.1  1999/08/02 15:37:14  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:25:02  dieter
 * Made release 0.02
 *
 * Revision 2.3  1999/01/20  00:18:14  dieter
 * Set stack size when reading process status information.
 * In get_state_info, allocate enough mappings to handle the worst case with
 * excluded regions.
 *
 * Revision 2.2  1999/01/13  15:48:22  dieter
 * Use mprotect to allow write_mapping_data to directly write each
 * segment.  This should be faster than reading from the proc file for
 * the process then writing to the checkpoint file.
 *
 * Revision 2.1  1998/12/22  15:40:41  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.5  1998/09/15  14:38:19  dieter
 * Added memdebug support.
 *
 * Revision 1.4  1998/08/25  20:33:00  dieter
 * Cleaned up a bit.
 *
 * Revision 1.3  1998/08/25  20:20:58  dieter
 * Added support for file I/O
 *
 * Revision 1.2  1998/07/31  20:18:31  dieter
 * Use the mmap protections for the prot field in the memmap structure.
 * Added stkbase to the proc_status structure.
 * file_offset, not offset, is the field that has the offset into
 * the checkpoint file.
 *
 * Revision 1.1  1998/07/31  13:32:30  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/procfs.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

#include "debug.h"
#include "memdebug.h"
#include "machif.h"
#include "save.h"
#include "sysio.h"
#include "exclude.h"

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define NMAP_FUDGE 4
#define BUF_SZ  65536

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

static prmap_t  *chkpt_prmap = NULL;
static memmap_t *chkpt_maps = NULL;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int open_proc_file( pid_t pid )
{
  char proc_file[32];
  
  sprintf( proc_file, "/proc/%ld", pid );
  return sys_open( proc_file, O_RDONLY );
}

int get_state_info( pid_t pid, proc_status_t *proc_status, int *nmap,
		    memmap_t **mapping )
{
  prstatus_t  prstatus;		/* process status read from proc file system */
  prmap_t    *prmap;		/* process memory mappings from proc fs      */
  int         fd;		/* file descriptor associated with process   */
  int         status;		/* return status from system calls	     */
  int         i;		/* generic loop index		 	     */

  fd = open_proc_file( pid );
  if( fd == -1 ) {
    fprintf( stderr, "error opening proc file for pid %ld\n", pid );
    perror( "open" );
    return fd;
  }

  status = ioctl( fd, PIOCNMAP, nmap );
  if( status == -1 ) {
    fprintf( stderr, "ioctl PIOCNMAP\n" );
    sys_close( fd );
    return status;
  }

  prmap = chkpt_prmap;
  *mapping = chkpt_maps;

  status = ioctl( fd, PIOCMAP, prmap );
  if( status == -1 ) {
    fprintf( stderr, "ioctl PIOCMAP\n" );
    *mapping = NULL;
    sys_close( fd );
    return status;
  }

  /* for some strange reason sometimes nmap is coming out 1 less than it
   * should??
   */
  /* maybe calling malloc increased the number of segments?
   */

  for( i = 0 ; i < *nmap+NMAP_FUDGE && prmap[i].pr_vaddr != NULL ; i++ )
    ;

  if( prmap[i].pr_vaddr != NULL ) {
    printf( "PIOCNMAP said %d prmaps, but there are at least %d\n",
	    *nmap+NMAP_FUDGE, i );
    printf( "Aborting now\n" );
    exit(-1);
  } else if( i != *nmap ) {
    printf( "PIOCNMAP said %d prmaps, but there are %d\n", *nmap, i );
    *nmap = i;
  }

  /* copy memory mapping info to memmap structure */
  for( i = 0 ; i < *nmap ; i++ ) {
    (*mapping)[i].addr     = prmap[i].pr_vaddr;
    (*mapping)[i].len      = prmap[i].pr_size;
    (*mapping)[i].pagesize = prmap[i].pr_pagesize;
    (*mapping)[i].offset   = prmap[i].pr_off;
    (*mapping)[i].prot = PROT_NONE;
    (*mapping)[i].prot |= (prmap[i].pr_mflags & MA_READ)  ? (PROT_READ)  : 0;
    (*mapping)[i].prot |= (prmap[i].pr_mflags & MA_WRITE) ? (PROT_WRITE) : 0;
    (*mapping)[i].prot |= (prmap[i].pr_mflags & MA_EXEC)  ? (PROT_EXEC)  : 0;
    (*mapping)[i].remap = 1;

  /* initialize now so that compute_mapping_offets can look at type */
    (*mapping)[i].type = 0;
    /* do not really need to set these now, but initialize them anyway */
    (*mapping)[i].offset = 0;
  }

  /* need to call prstatus after the mallocs because calling malloc
   * may have changed the brk 
   */
  status = ioctl( fd, PIOCSTATUS, &prstatus );
  if( status == -1 ) {
    fprintf( stderr, "ioctl PIOCSTATUS\n" );
    sys_close( fd );
    return status;
  }

  if (proc_status != NULL) {
    proc_status->brkbase = prstatus.pr_brkbase;
    proc_status->brklen = prstatus.pr_brksize;
    proc_status->stkbase = prstatus.pr_stkbase;
    proc_status->stksize = prstatus.pr_stksize;
  }

  sys_close( fd );

  return 0;
}

/* need to allocate a big enough array to handle all the mappings even
 * after regions have been excluded.  Each excluded region might add
 * one additional mapping.
 */
int allocate_map_info(pid_t pid)
{
  int nmap;
  int total_nmap;
  int fd;
  size_t size;
  int status;

  fd = open_proc_file(pid);
  if (fd == -1) {
    fprintf(stderr, "error opening proc file for pid %ld\n", pid);
    perror("open");
    return fd;
  }

  /* determine the number of mappings */
  status = ioctl(fd, PIOCNMAP, &nmap);
  if (status == -1) {
    fprintf(stderr, "ioctl PIOCNMAP\n");
    sys_close(fd);
    return status;
  }

  size = (nmap + 1 + NMAP_FUDGE) * sizeof(prmap_t);
  if (chkpt_prmap == NULL) {
    chkpt_prmap = (prmap_t *)malloc(size);
  } else {
    chkpt_prmap = realloc(chkpt_prmap, size);
  }
  if (chkpt_prmap == NULL) {
    fprintf( stderr, "could not allocate prmap list\n" );
    sys_close( fd );
    return -1;
  }

  /* need to allocate a big enough array to handle all the mappings even
   * after regions have been excluded.  Each excluded region might add
   * one additional mapping.
   */
  size = (nmap + 1 + NMAP_FUDGE) * sizeof(memmap_t);
  if (chkpt_maps == NULL) {
    chkpt_maps = (memmap_t *)malloc(size);
  } else {
    chkpt_maps = realloc(chkpt_maps, size);
  }
  if (chkpt_maps == NULL) {
    fprintf(stderr, "could not allocate mapping list\n");
    free(chkpt_prmap);
    chkpt_prmap = NULL;
    sys_close(fd);
    return -1;
  }

  sys_close(fd);

  if ( (get_state_info(getpid(), NULL, &nmap, &chkpt_maps)) < 0) {
    CRASH_ERR("error reading maps\n");
  }
  
  total_nmap = chkpt_count_excl_maps(nmap, chkpt_maps);

  if (total_nmap != nmap) {
    size = (total_nmap + 1 + NMAP_FUDGE) * sizeof(memmap_t);
    if ( (chkpt_maps = (memmap_t *)realloc(chkpt_maps, size)) == NULL) {
      CRASH_ERR("cannot allocate maps\n");
    }
  }

  return 0;
}

int  write_mapping_data( int chkpt_fd, pid_t pid, int nmap, memmap_t *mapping )
{
  int map;

  for( map = 0 ; map < nmap ; map++ ) {
    if( mapping[map].type != SEG_CODE && mapping[map].type != SEG_EXCL ) {

      /* need to make sure the memory is readable before writing it */
      if( (mapping[map].prot & PROT_READ) == 0 ) {
	mprotect( mapping[map].addr, mapping[map].len, PROT_READ );
      }

      lseek( chkpt_fd, mapping[map].file_offset, SEEK_SET );
      write( chkpt_fd, mapping[map].addr, mapping[map].len );

      if( (mapping[map].prot & PROT_READ) == 0 ) {
	mprotect( mapping[map].addr, mapping[map].len, mapping[map].prot );
      }

    }
  }

  return 0;
}


