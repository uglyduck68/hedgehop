/*
 * machine dependent I/O stuff
 *
 * History
 * -------
 * $Log: libcio.c,v $
 * Revision 6.1  2000/05/02 20:13:09  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:39:11  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 1.1  1999/10/21 22:51:49  dieter
 * Initial revision
 *
 */


#include <stdio.h>

int get_file_fd(FILE *fp)
{
  return fp->_file;
}
