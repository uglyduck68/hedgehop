/*
 * save.h
 *
 * History
 * -------
 * $Log: save.h,v $
 * Revision 6.3  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 * Revision 6.2  2001/02/06 18:48:21  dieter
 * Use chkpt_write_all to save mappings.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.2  1999/08/02  14:41:31  dieter
 * Modified to not save the thread library state in the checkpoint.
 * This version does not work because the thread library is unaware of the
 * fact that the thread stacks of the restarted threads overlap with space
 * it has allocated.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:34:56  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.2  1998/07/31  20:15:14  dieter
 * Pretty much everything is moved over from the old version of checkpointing.
 *
 * Revision 1.1  1998/07/31  13:37:09  dieter
 * Initial revision
 *
 */
#ifndef SAVE_H_
#define SAVE_H_

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int chkpt_save_init(void);

int save_chkpt( char *filename, pid_t pid, proc_status_t *status,
		 int nmap, memmap_t *mapping );
int chkpt_async_save(char *filename, pid_t pid, proc_status_t *status,
		      int nmap, memmap_t *mapping);

void chkpt_wait_for_async_save(void);

int chkpt_write_all(int fd, const void *buf, size_t count);
void chkpt_lwp_init(void);

#endif /* SAVE_H_ */
