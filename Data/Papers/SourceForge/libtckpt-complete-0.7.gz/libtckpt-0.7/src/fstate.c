/*
 * fstate.c
 *
 * Code to keep track of the state of open files
 *
 * History
 * -------
 * $Log: fstate.c,v $
 * Revision 6.4  2000/10/20 20:48:13  dieter
 * Added better handling of reopening tty files.  (just ignore it on error
 * open rather than exitting).
 *
 * Revision 6.3  2000/05/15 22:13:14  dieter
 * minor change in error message formatting in fstate_restore.
 *
 * Revision 6.2  2000/05/08 19:44:11  dieter
 * Added fixes from Unify version.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.2  2000/05/02 14:33:06  dieter
 * Handle pipes, stdin, and stdout.
 *
 * Revision 5.1  2000/02/01  23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.4  2000/02/01 23:30:32  dieter
 * Truncate write-only files to their length at the last checkpoint
 * during recovery.
 *
 * Revision 4.3  2000/01/25 20:43:43  dieter
 * In fstate_restore, make sure status is initialized.
 *
 * Revision 4.2  2000/01/19 22:43:37  dieter
 * Added support for pipes.
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:25:03  dieter
 * verstion that worked for ftcs paper.
 *
 * Revision 1.4  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.3  1998/09/01  15:56:54  dieter
 * Added changes to support libc I/O (fopen, fclose).
 *
 * Revision 1.2  1998/08/31  12:31:22  dieter
 * Do not use O_TRUNC or O_CREAT flags during recovery.  They may cause
 * the file to be truncated.
 *
 * Revision 1.1  1998/08/25  20:18:04  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>

#include "memdebug.h"
#include "fstate.h"
#include "sysio.h"
#include "debug.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/* status flags for the file_info structure */
#define FINFO_IN_USE  	0x01L	/* set if this entry is in use		     */
#define FINFO_DUP_FD	0x02L	/* set if entry created by a dup             */
#define FINFO_FILENAME_MALLOCED 0x04L /* filename was allocated with malloc  */

#define CHKPT_FILE_MAX OPEN_MAX

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef enum {
  chkpt_regular_file,
  chkpt_pipe_file
} chkpt_file_t;

/* This structure holds all the info needed to reopen sequential files during
 * checkpoint recovery.
 */
typedef struct file_info {
  /* next_dup and prev_dup make a doubly linked circular list */
  struct file_info *next_dup;	/* next file dup'ed from this file	     */
  struct file_info *prev_dup;	/* prev file dup'ed from this file	     */
  int     filedes;		/* file descriptor of the file		     */
  unsigned long  status;	/* status information about this entry	     */
  chkpt_file_t type;
  union {
    struct {
      char   *filename;		/* name of the file			     */
      int     oflag;		/* flags to pass to open (read, write, etc)  */
      mode_t  mode;		/* mode flags to pass to open                */
      off_t   offset;		/* current offset of the file pointer	     */
      FILE   *fp;		/* pointer to file stream if opened w/ fopen */
    } regular;
    struct {
      int     other_end;	/* filedes of other end of the pipe */
      mode_t  mode;
    } pipe;
  } info;
} file_info_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/* file_info_table has one file_info_t for each file descriptor */
file_info_t file_info_table[CHKPT_FILE_MAX] = {
  /* need to initialize stdin, stdout, and stderr in case someone decides
   * to dup them later.
   */
  {&file_info_table[0],
   &file_info_table[0],
   0,
   FINFO_IN_USE,
   chkpt_regular_file,
   {{"/dev/tty", O_RDONLY, 0, 0, NULL}}},
  {&file_info_table[1],
   &file_info_table[1],
   1,
   FINFO_IN_USE,
   chkpt_regular_file,
   {{"/dev/tty", O_WRONLY, 0, 0, NULL}}},
  {&file_info_table[2],
   &file_info_table[2],
   2,
   FINFO_IN_USE,
   chkpt_regular_file,
   {{"/dev/tty", O_WRONLY, 0, 0, NULL}}},
  {NULL, NULL, 0, 0, 0, {{NULL, 0, 0, 0, NULL}}}
};

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static void fstate_pipe_rename_other_end(int filedes, int new_other_fd);
static int fstate_reopen_regular_file(file_info_t *finfo);
static int fstate_reopen_pipe(file_info_t *finfo);
static int fstate_restore_dup(file_info_t *dup_info);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

/* add info for a regular file to file_info_table */
int  fstate_add_file(const char *filename, int oflag, mode_t mode,
		     int filedes)
{
  char *filestr;
  file_info_t *finfo;

  filestr = (char *)malloc(strlen(filename) + 1);
  if (filestr == NULL) {
    fprintf(stderr, "fstate_add_file: cannot allocate filename\n");
    fprintf(stderr, "file info not saved\n");
    return -1;
  }
  strcpy(filestr, filename);

  finfo = &file_info_table[filedes];
  finfo->next_dup = finfo;
  finfo->prev_dup = finfo;
  finfo->filedes  = filedes;
  finfo->status   = FINFO_IN_USE|FINFO_FILENAME_MALLOCED;
  finfo->type = chkpt_regular_file;
  finfo->info.regular.filename = filestr;
  finfo->info.regular.oflag    = oflag;
  finfo->info.regular.mode     = mode;
  finfo->info.regular.fp       = NULL;

  return filedes;
}

/* add info for pipe file descriptors to file_info_table */
int  fstate_add_pipe(int filedes[2])
{
  file_info_t *finfo;

  finfo = &file_info_table[filedes[0]];
  finfo->next_dup = finfo;
  finfo->prev_dup = finfo;
  finfo->filedes  = filedes[0];
  finfo->status   = FINFO_IN_USE;
  finfo->type = chkpt_pipe_file;
  finfo->info.pipe.other_end = filedes[1];
  finfo->info.pipe.mode = O_RDONLY;

  finfo = &file_info_table[filedes[1]];
  finfo->next_dup = finfo;
  finfo->prev_dup = finfo;
  finfo->filedes  = filedes[1];
  finfo->status   = FINFO_IN_USE;
  finfo->type = chkpt_pipe_file;
  finfo->info.pipe.other_end = filedes[0];
  finfo->info.pipe.mode = O_WRONLY;

  return 0;
}

/* remove a the entry corresponding to filedes from file_info_table */
int  fstate_delete_file(int filedes)
{
  file_info_t *finfo;

  if (filedes < 0 || filedes >= CHKPT_FILE_MAX) {
    return -1; 
  }

  finfo = &file_info_table[filedes];
  if ((finfo->status & FINFO_IN_USE) == 0) {
    fprintf(stderr, "tried to close filedes %d not in table\n", filedes);
    return -1;
  }

  if (finfo->next_dup == finfo) {
    /* if this is the last reference to the file ... */
    if ( (finfo->type == chkpt_regular_file)
	 && (finfo->status & FINFO_FILENAME_MALLOCED) ) {
      /* ... free the filename */
      free(finfo->info.regular.filename);
    } else if (finfo->type == chkpt_pipe_file
	       && finfo->info.pipe.other_end != -1) {
      /* ... mark this end as unused in the other end's entry(s) */
      fstate_pipe_rename_other_end(finfo->info.pipe.other_end, -1);
    }
  } else {
    /* the next_dup/prev_dup list is circular so neither should ever by NULL */
    ASSERT(finfo->next_dup != NULL);
    ASSERT(finfo->prev_dup != NULL);
    finfo->next_dup->prev_dup = finfo->prev_dup;
    finfo->prev_dup->next_dup = finfo->next_dup;
    if ((finfo->status & FINFO_DUP_FD) == 0) {
      /* this entry was not created by dup;
       * make one of the dups the "original"
       */
      finfo->next_dup->status &= ~FINFO_DUP_FD;
    }
    if (finfo->type == chkpt_pipe_file && finfo->info.pipe.other_end != -1) {
      fstate_pipe_rename_other_end(finfo->info.pipe.other_end,
				   finfo->next_dup->filedes);
    }
  }

  finfo->status = 0;

  return 0;
}

/* reset the other_end of filedes and all its dups to new_other_fd */
static void fstate_pipe_rename_other_end(int filedes, int new_other_fd)
{
  file_info_t *start_info;
  file_info_t *finfo;

  start_info = &file_info_table[filedes];
  finfo = start_info;
  do {
    /* this is only valid for pipes */
    ASSERT(finfo->type == chkpt_pipe_file);
    finfo->info.pipe.other_end = new_other_fd;
    finfo = finfo->next_dup;
  } while(finfo != start_info);
}

/* duplicate a file descriptor */
int  fstate_add_dup_file(int orig_fd, int new_fd)
{
  int status;
  file_info_t *orig_info;
  file_info_t *new_info;

  orig_info = &file_info_table[orig_fd];
  new_info = &file_info_table[new_fd];

  if ((orig_info->status & FINFO_IN_USE) == 0) {
    /* the user passed in some type of file we don't know about
     * (probably a socket), so just return and happily report success
     */
    return 0;
  }

  if ((new_info->status & FINFO_IN_USE) != 0) {
    status = fstate_delete_file(new_fd);
    if (status == -1)
      return -1;
  }

  *new_info = *orig_info;
  new_info->prev_dup = orig_info;
  new_info->next_dup = orig_info->next_dup;
  new_info->next_dup->prev_dup = new_info;
  orig_info->next_dup = new_info;
  new_info->status |= FINFO_DUP_FD;

  return 0;
}

/* calculate all the info needed to recover from a checkpoint */
int  fstate_save(void)
{
  int filedes;
  file_info_t *finfo;

  for (filedes = 0 ; filedes < CHKPT_FILE_MAX ; filedes++) {
    finfo = &file_info_table[filedes];
    if (finfo->status & FINFO_IN_USE ) {
      if (finfo->type == chkpt_regular_file) {
	finfo->info.regular.offset = lseek(finfo->filedes, 0, SEEK_CUR);
      }
    }
  }

  return 0;
}

/* restore (reopen) files after a checkpoint */
int  fstate_restore(void)
{
  int filedes;
  file_info_t *finfo;
  int status = 0;

  /* handle all the non-dup'ed regular files (but not stdin, stdout, stderr) */
  for (filedes = 0 ; filedes < CHKPT_FILE_MAX ; filedes++) {
    finfo = &file_info_table[filedes];
    if ( (finfo->status & FINFO_IN_USE)
	 && ((finfo->status & FINFO_DUP_FD) == 0) ) {
      if (finfo->type == chkpt_regular_file) {
	status = fstate_reopen_regular_file(finfo);
      } else if (finfo->type == chkpt_pipe_file
		 && finfo->info.pipe.other_end > filedes) {
	/* opening a pipe always gets two file descriptors.
	 * since the file descriptor table is always opened in 
	 * increasing order, open both file descriptors when the
	 * first one is encountered.
	 */
	status = fstate_reopen_pipe(finfo);
      } else if (finfo->type != chkpt_regular_file
		 && finfo->type != chkpt_pipe_file) {
	/* unkown file type */
	fprintf(stderr, "cannot reopen filedes %d: unknown file type %d\n",
		filedes, finfo->type);
	status = -1;
      }
      if (status != 0) {
	return status;
      }
    }
  }

  /* handle dup'ed files */
  for (filedes = 0 ; filedes < CHKPT_FILE_MAX ; filedes++) {
    finfo = &file_info_table[filedes];
    if ((finfo->status & FINFO_IN_USE) &&
	((finfo->status & FINFO_DUP_FD) != 0) ) {
      status = fstate_restore_dup(finfo);
      if (status != 0) {
	fprintf(stderr, "cannot re-dup fildes %d: %s\n",
		filedes, strerror(errno));
      }
    }
  }

  return 0;
}

/* open a file after a checkpoint and seek to where it was */
static int fstate_reopen_regular_file(file_info_t *finfo)
{
  int   restore_fd;
  off_t restored_offset;
  int   status;

  /* need to turn off O_TRUNC and O_CREAT flags because they will cause
   * the file to be truncated during recovery.
   */
  restore_fd = sys_open(finfo->info.regular.filename,
			finfo->info.regular.oflag & ~(O_TRUNC|O_CREAT),
			finfo->info.regular.mode);
  if (restore_fd == -1) {
    if (strcmp("/dev/tty", finfo->info.regular.filename) == 0) {
      /* silently give up if cannot open /dev/tty.  With PVM /dev/tty might
       * not exist...
       */
      return 0;
    }
    fprintf(stderr, "cannot open %s during restore\n",
	    finfo->info.regular.filename);
    perror("fstate_restore");
    exit(-1);
  }
  
  /* seek to the position at the time of the checkpoint */
  restored_offset = lseek(restore_fd, finfo->info.regular.offset, SEEK_SET);
  if (restored_offset != finfo->info.regular.offset) {
    fprintf(stderr, "cannot seek to %ld in file %s actual offset is %ld\n",
	    finfo->info.regular.offset, finfo->info.regular.filename,
	    restored_offset);
    perror("fstate_restore");
  }

  if ((finfo->info.regular.oflag & O_WRONLY)
      && (strcmp("/dev/tty", finfo->info.regular.filename) != 0)
      /* || (finfo->info.regular.oflag & O_RDWR)*/) {
    if ( (status = ftruncate(restore_fd, finfo->info.regular.offset)) == -1) {
      fprintf(stderr, "cannot truncate fd %d, filename: %s\n",
	      restore_fd, finfo->info.regular.filename);
      perror("ftruncate failed");
      exit(-1);
    }
  }
  
  /* reassign to correct file descriptor */
  if (restore_fd != finfo->filedes) {
    status = sys_dup2(restore_fd, finfo->filedes);
    if (status == -1) {
      fprintf(stderr, "cannot remap file descriptor %d to %d\n",
	      restore_fd, finfo->filedes);
      perror("fstate_restore");
      return -1;
    }
    /* close the temporary file descriptor */
    sys_close(restore_fd);
  }

  return 0;
}

/* reopen a pipe after a checkpoint */
static int fstate_reopen_pipe(file_info_t *finfo)
{
  int restore_fds[2];
  int temp_fd;
  int status;
  file_info_t *read_info;
  file_info_t *write_info;

  if ( (status = sys_pipe(restore_fds)) != 0) {
    return status;
  }

  
  if ((finfo->info.pipe.mode & O_RDONLY) == O_RDONLY) {
    /* finfo is the read end */
    read_info = finfo;
    if (finfo->info.pipe.other_end != -1) {
      write_info = &file_info_table[finfo->info.pipe.other_end];
    } else {
      write_info = NULL;
    }
  } else if((finfo->info.pipe.mode & O_WRONLY) == O_WRONLY) {
    /* finfo is the write end */
    write_info = finfo;
    if (finfo->info.pipe.other_end != -1) {
      read_info = &file_info_table[finfo->info.pipe.other_end];
    } else {
      read_info = NULL;
    }
  } else {
    fprintf(stderr, "%s:%d: pipe descriptor with no read/write mode set\n",
	    __FILE__, __LINE__);
    return -1;
  }

  /* restore the read end */
  if (read_info != NULL) {
    /* avoid duping over the write end of the pipe (if necessary) */
    if (restore_fds[1] == read_info->filedes) {
      if( (temp_fd = sys_dup(restore_fds[1])) != 0) {
	return -1;
      }
      sys_close(restore_fds[1]);
      restore_fds[1] = temp_fd;
    }

    /* move the file descriptor if necessary */
    if (restore_fds[0] != read_info->filedes) {
      status = sys_dup2(restore_fds[0], read_info->filedes);
      if (status == -1) {
	fprintf(stderr, "%s:%d: cannot remap pipe read from %d to %d\n",
		__FILE__, __LINE__, restore_fds[0], read_info->filedes);
	return -1;
      }
      sys_close(restore_fds[0]);
    }
  }

  /* restore the write end */
  if (write_info != NULL) {
    /* move the file descriptor if necessary */
    if (restore_fds[1] != write_info->filedes) {
      status = sys_dup2(restore_fds[1], write_info->filedes);
      if (status == -1) {
	fprintf(stderr, "%s:%d: cannot remap pipe read from %d to %d\n",
		__FILE__, __LINE__, restore_fds[1], write_info->filedes);
	return -1;
      }
      sys_close(restore_fds[1]);
    }
  }

  return 0;
}

/* restore a file descriptor created with dup */
static int fstate_restore_dup(file_info_t *dup_info)
{
  file_info_t *finfo;

  finfo = dup_info->next_dup;
  while((finfo->status & FINFO_DUP_FD) != 0 && finfo != dup_info) {
    finfo = finfo->next_dup;
  }

  if (finfo == dup_info) {
    CRASH(("no original found in dup list\n"));
  }

  return sys_dup2(finfo->filedes, dup_info->filedes);
}
