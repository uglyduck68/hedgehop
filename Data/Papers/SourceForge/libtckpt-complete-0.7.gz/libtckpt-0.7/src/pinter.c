/*
 * pinter.c
 *
 * Intercept calls to the pthreads interface so that
 * checkpointing can asynchronously interrupt threads without
 * deadlocking.
 *
 * History
 * -------
 * $Log: pinter.c,v $
 * Revision 6.3  2001/06/06 21:25:13  wrdieter
 * Fixed bug when with restart.
 *
 * Revision 6.2  2000/10/20 20:57:46  dieter
 * Cleaned up restoration of pending signals a bit.
 * Restore errno to its value at the start of the sighandler.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.2  2000/05/02 14:35:10  dieter
 * Moved callbacks to checkpoint thread.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.9  2000/02/01 21:38:30  dieter
 * cleaned up some comments.
 *
 * Revision 4.8  2000/01/31 19:32:23  dieter
 * Removed unnecessary pthread_exit handling code.
 *
 * Revision 4.7  2000/01/31  19:31:05  dieter
 * #ifdef'ed out unnecessary pthread_exit code.
 *
 * Revision 4.6  2000/01/28  21:11:58  dieter
 * Cleaned up crash and debug print macros.
 *
 * Revision 4.5  2000/01/25 20:42:50  dieter
 * Removed noise printf when threads exit.
 *
 * Revision 4.4  2000/01/19 22:45:55  dieter
 * Many changes to support Linux.
 *
 * Revision 4.3  1999/11/01 19:49:52  dieter
 * More linux changes.
 *
 * Revision 4.2  1999/10/21 22:47:49  dieter
 * Changes to compile with Linux.
 * Call real pthread calls if chkpt thread code not initialized.
 *
 * Revision 4.1  1999/08/02 15:27:02  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.6  1999/04/20  17:56:00  dieter
 * Added header files to remove warnings for sysio.h and libcio.h.
 *
 * Revision 3.5  1999/04/20  15:31:42  dieter
 * In pthread_mutex_lock, do not look at mutex_info if it is not set
 * (i.e., _mutex_lock is called by pthread_cond_wait).
 *
 * Revision 3.4  1999/04/20  15:08:56  dieter
 * Use mutexes instead of pthread_sigmask to prevent signals when
 * locking a mutex.
 * Intercept _mutex_lock and _mutex_unlock to handle libraries that use mutexes.
 *
 * Revision 3.3  1999/04/19  16:33:29  dieter
 * Eliminated deadlock with locks.
 *
 * Revision 3.3  1999/03/25  21:22:07  dieter
 * Changed from pthread_sigmask to mutex calls to block signals during
 * pthread_mutex_lock bookkeepping.
 *
 * Revision 3.2  1999/03/15  18:19:28  dieter
 * avoid sigemptyset and sigaddset calls in pthread_mutex_*lock functions.
 * It is questionable how much this really helps performance, but it
 * should not hurt it.
 * Added instrumentation to measure time spent in locks.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.3  1999/01/06  00:29:18  dieter
 * Removed real_pthread_cond_broadcast variable.  It was unused.
 *
 * Revision 2.2  1998/12/22  15:30:11  dieter
 * Allocate mutex info in clumps.
 * Try getcontext/setcontext instead of sigsetjmp/siglongjmp.
 *
 * Revision 2.1  1998/12/22  15:29:36  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.23  1998/12/03  19:34:56  dieter
 * changed some printf's
 *
 * Revision 1.22  1998/11/25  15:36:53  dieter
 * Use pthread_sigmask to remove race in pthread_mutex_unlock.
 *
 * Revision 1.21  1998/11/23  22:42:26  dieter
 * Best algorithm yet.  Should be race free.  (except for pthread_detach,
 * which should not be a problem in most apps).
 *
 * Revision 1.20  1998/11/23  21:57:09  dieter
 * Added prevent_locks.
 *
 * Revision 1.19  1998/11/23  20:31:55  dieter
 * A better, but still imperfect algorithm.
 * Also, wait for all threads to be signalled before running in sighandler.
 *
 * Revision 1.18  1998/11/23  19:18:32  dieter
 * Another broken synchronization algorithm.
 *
 * Revision 1.17  1998/11/19  17:09:18  dieter
 * Warn if race happens trying to unlock a lock during checkpointing.
 *
 * Revision 1.16  1998/11/19  14:45:39  dieter
 * Removed one set of deadlock conditions when restarting, but still
 * fails for the general case and there is a race.
 *
 * Revision 1.15  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.14  1998/09/08  21:05:44  dieter
 * Save the stack address separately so that I can restore the stack pointer
 * before loading any segments.  Then load all segments the same way
 * (including the stack segment.)  Otherwise must handle case where the
 * stack consists of multiple segments.
 *
 * Revision 1.13  1998/09/01  19:54:07  dieter
 * Free mutex_info when it is no longer needed.
 *
 * Revision 1.12  1998/09/01  17:11:56  dieter
 * Got rid of race between threads being created or exiting during a
 * checkpoint.
 *
 * Revision 1.11  1998/08/31  21:51:21  dieter
 * Record changes to a thread's detach state.
 *
 * Revision 1.10  1998/08/31  21:24:33  dieter
 * Use a cleanup handler to make sure that state that the checkpointing
 * library saves is updated when a thread exits either because of a call
 * to pthread_exit, an implicit return from the function that started the
 * thread, or thread cancellation.
 *
 * Revision 1.9  1998/08/31  12:21:03  dieter
 * Adjusted spacing in comments.
 *
 * Revision 1.8  1998/08/28  13:30:10  dieter
 * Reset global variables so the program can take multiple checkpoints.
 *
 * Revision 1.7  1998/08/26  21:24:42  dieter
 * Checkpointing works with timer, but only once.
 *
 * Revision 1.6  1998/08/25  20:32:44  dieter
 * Added to a comment.
 *
 * Revision 1.5  1998/08/25  20:18:04  dieter
 * Added support for sequential I/O files.
 *
 * Revision 1.4  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.3  1998/08/16  17:32:48  dieter
 * Removed some unnecessary printf's.
 *
 * Revision 1.2  1998/08/16  16:42:17  dieter
 * Made changes so that threads checkpoint when they get a SIGUSR1.
 * Recovery does not work yet.
 *
 * Revision 1.1  1998/08/10  15:43:07  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <pthread.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <assert.h>

#include "memdebug.h"
#include "cpglobal.h"
#include "hash.h"
#include "cppthread.h"
#include "sysio.h"		/* for sysio_init */
#include "libcio.h"		/* for libcio_init */
#include "restore.h"		/* for restore_pending_signals */

#include "debug.h"


/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#if OS == SOLARIS
#define MUTEX_RELEASED   0x01L	/* mutex released during checkpointing    */
#define MUTEX_COND_WAIT  0x02L	/* mutex released by pthread_cond_wait    */
#define MUTEX_LOCKING    0x04L	/* checkpoint started while thread was
				 * locking the mutex
				 */
#endif

#define INIT_REAL_PTHREAD_FUNCS() \
{if( !real_funcs_initted ) init_real_pthread_funcs();}

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct thread_args {
  void *(*start_func)(void *);
  void *arg;
} thread_args_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

pthread_mutex_t chkpt_sighandler_mutex = MUTEX_INITIALIZER;
#if OS == SOLARIS
pthread_cond_t  chkpt_sighandler_cond = COND_INITIALIZER;

				/* number of threads that have unlocked all
				 * their mutexes
				 */
int             thr_unlock_cnt = 0;
				/* number of threads that have re-locked all
				 * their mutexes
				 */
int             thr_lock_cnt = 0;
#endif

int real_funcs_initted = 0;

int (*real_pthread_create)(pthread_t *new_thread_ID,
			   const pthread_attr_t *attr,
			   void * (*start_func)(void *), void *arg) = NULL;

#if OS == SOLARIS
int (*real_pthread_mutex_init)(pthread_mutex_t *mp,
			       const pthread_mutexattr_t *mutexattr) = NULL;
int (*real_pthread_mutex_lock)(pthread_mutex_t *mp) = NULL;
int (*real_pthread_mutex_trylock)(pthread_mutex_t *mp) = NULL;
int (*real_pthread_mutex_unlock)(pthread_mutex_t *mp) = NULL;

int (*real_pthread_cond_wait)(pthread_cond_t *cond,
			      pthread_mutex_t *mutex) = NULL;
int (*real_pthread_cond_timedwait)(pthread_cond_t *cond,
				   pthread_mutex_t *mutex,
				   const struct timespec *abstime) = NULL;
int (*real_pthread_cond_signal)(pthread_cond_t *cond) = NULL;
int (*real_pthread_detach)(pthread_t threadID) = NULL;

#ifdef PTHREAD_SELF_INTERCEPT_TEST
pthread_t (*real_pthread_self)(void) = NULL;
#endif
#elif OS == LINUX
/* yes, I know, technically these are macros not variables, but they are
 * here because they match the above variables.
 */
#define real_pthread_mutex_lock(mp)	assert(EDEADLK != pthread_mutex_lock(mp))
#define real_pthread_mutex_unlock(mp)   assert(EDEADLK != pthread_mutex_unlock(mp))
#endif
/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void *chkpt_thread_start(void *arg);
void chkpt_cleanup(void *arg);
int  pthread_copy_attr(pthread_attr_t *dest, const pthread_attr_t *src);
int init_real_pthread_funcs( void );

#if OS == SOLARIS
int add_held_mutex( pthread_mutex_t *mp, chkpt_thread_info_t *thr_info,
		    chkpt_mutex_info_t **ret_info );
int delete_held_mutex( pthread_mutex_t *mp );
chkpt_mutex_info_t *find_held_mutex(chkpt_thread_info_t *thr_info,
				    pthread_mutex_t *mp);

int clear_thr_flags(long key, void *value, void *arg);
#endif

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int pthread_create(pthread_t *new_thread_ID, const pthread_attr_t *attr,
		   void * (*start_func)(void *), void *arg)
{
  int status;
  pthread_t tid;
  pthread_attr_t thr_attr;
  thread_args_t *thr_args;

  INIT_REAL_PTHREAD_FUNCS();

  thr_args = (thread_args_t *)malloc(sizeof(thread_args_t));
  if (thr_args == NULL) {
    return ENOMEM;
  }
  thr_args->start_func = start_func;
  thr_args->arg        = arg;

  /* The thread must be PTHREAD_SCOPE_SYSTEM because otherwise Solaris
   * will dynamically allocate threads to lwp's.  Dynamically creating
   * threads is bad because I have no way to save the mapping between
   * threads and lwps other than by saving the entire address space.
   * During recovery, creating the same number of threads that existed
   * before may not create the same number of lwps that existed before
   * and there will be a mismatch between the state of the threads library
   * and the operating system.
   *
   * TODO: maybe try to find a way to save the lwp info without having
   *       to force all threads to be PTHREAD_SCOPE_SYSTEM.
   */
  pthread_attr_init(&thr_attr);
  if (attr != NULL) {
    pthread_copy_attr(&thr_attr, attr);
  }
  pthread_attr_setscope(&thr_attr, PTHREAD_SCOPE_SYSTEM);

  /* do not allow a checkpoint to start between the time the thread is
   * created and the call to add_thread_info
   */
  real_pthread_mutex_lock(&chkpt_start_mutex);
  status = real_pthread_create (&tid, &thr_attr, chkpt_thread_start, thr_args);

  if (status == 0) {
    add_thread_info(tid, &thr_attr);
  }
  real_pthread_mutex_unlock(&chkpt_start_mutex);

  pthread_attr_destroy(&thr_attr);

  if( new_thread_ID != NULL ) {
    *new_thread_ID = tid;
  }

  return status;
}

/*
 * chkpt_thread_start
 *
 * The checkpointing version of pthread_create always calls this function
 * to start a thread.  This function installs a cleanup handler so that
 * when the thread exits or is cancelled, state information about the
 * thread is updated
 */
void *chkpt_thread_start(void *arg)
{
  thread_args_t *thr_args;
  void *(*start_func)(void *);
  void *func_arg;

  void *rc;

  thr_args = (thread_args_t *)arg;
  start_func = thr_args->start_func;
  func_arg = thr_args->arg;
  free(thr_args);

  pthread_cleanup_push(chkpt_cleanup, NULL);
  rc = start_func(func_arg);
  pthread_cleanup_pop(1);

  return rc;
}

void chkpt_cleanup(void *arg)
{
  /* prevent the thread from exiting during a checkpoint */
  /* If the thread could exit during a checkpoint there would be a race.
   * The checkpoint thread might read the thread ID, send it a signal,
   * and wait for all threads.  The waiting thread will deadlock if the
   * thread exits before it receives the signal.
   */
  pthread_mutex_lock(&chkpt_start_mutex);
#if PTHREAD_EXIT_DEBUG
  printf("thread "PTHREAD_FMT" exiting\n", pthread_self());
#endif
  remove_thread_info(pthread_self());
  pthread_mutex_unlock(&chkpt_start_mutex);
}

int  pthread_copy_attr(pthread_attr_t *dest, const pthread_attr_t *src)
{
  int     contentionscope;	/* thread contention scope */
  int     detachstate;		/* thread detachstate */
#if HAVE_PTHREAD_ATTR_SETSTACKSIZE == 1
  size_t  stacksize;		/* thread stack size */
  void   *stackaddr;		/* thread stack address */
#endif
  struct sched_param  param;	/* thread scheduling parameters */
  int     policy;		/* thread scheduling policy */
  int     inheritsched;		/*  */

  pthread_attr_getscope(src, &contentionscope);
  pthread_attr_setscope(dest, contentionscope);
  pthread_attr_getdetachstate(src, &detachstate);
  pthread_attr_setdetachstate(dest, detachstate);
#if HAVE_PTHREAD_ATTR_SETSTACKSIZE == 1
  pthread_attr_getstacksize(src, &stacksize);
  pthread_attr_setstacksize(dest, stacksize);
  pthread_attr_getstackaddr(src, &stackaddr);
  pthread_attr_setstackaddr(dest, stackaddr);
#endif
  pthread_attr_getschedparam(src, &param);
  pthread_attr_setschedparam(dest, &param);
  pthread_attr_getschedpolicy(src, &policy);
  pthread_attr_setschedpolicy(dest, policy);
  pthread_attr_getinheritsched(src, &inheritsched);
  pthread_attr_setinheritsched(dest, inheritsched);
  
  return 0;
}

#if OS == SOLARIS

/* #define MEASURE_LOCK_PERF */
#ifdef MEASURE_LOCK_PERF
hrtime_t mask_time = 0;
hrtime_t hash_access_time = 0;
hrtime_t unmask_time = 0;
hrtime_t mutex_lock_time = 0;
int      lock_cnt = 0;
pthread_mutex_t  timer_mutex = MUTEX_INITIALIZER;
#endif

int _mutex_lock(pthread_mutex_t *mp)
{
  if(init_done) {
    return pthread_mutex_lock(mp);
  } else {
    INIT_REAL_PTHREAD_FUNCS();
    return real_pthread_mutex_lock(mp);
  }
}

int _mutex_unlock(pthread_mutex_t *mp)
{
  if(init_done) {
    return pthread_mutex_unlock(mp);
  } else {
    INIT_REAL_PTHREAD_FUNCS();
    return real_pthread_mutex_unlock(mp);
  }
}

int pthread_mutex_lock(pthread_mutex_t *mp)
{
  int status;
  chkpt_mutex_info_t *mutex_info;
  chkpt_thread_info_t *thr_info;
#ifdef MEASURE_LOCK_PERF
  hrtime_t lock_start;
  hrtime_t signals_masked;
  hrtime_t read_table;
  hrtime_t signals_unmasked;
  hrtime_t mutex_locked;
#endif

  INIT_REAL_PTHREAD_FUNCS();

  if (!init_done)
    return real_pthread_mutex_lock(mp);

#ifdef MEASURE_LOCK_PERF
  lock_start = gethrtime();
#endif
  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );

  if(thr_info != NULL) {
    /* prevent checkpoint signals while locking the mutex */
    real_pthread_mutex_lock( &thr_info->sig_mutex );
    if(prevent_locks && !(thr_info->status & (THR_IN_SIGHANDLER|THR_COND_WAIT))){
      real_pthread_mutex_unlock(&thr_info->sig_mutex);
      while(prevent_locks) {
	sched_yield();
      }
      real_pthread_mutex_lock(&thr_info->sig_mutex);
    }
    thr_info->status |= THR_LOCKING_MUTEX;
    real_pthread_mutex_unlock( &thr_info->sig_mutex );

#ifdef MEASURE_LOCK_PERF
    signals_masked = gethrtime();
#endif

    if (!(thr_info->status & THR_COND_WAIT)) {
      if (add_held_mutex( mp, thr_info, &mutex_info ) != 0) {
	CRASH(("pthread_mutex_lock: cannot add mutex\n"));
      }
    } else {
      mutex_info = NULL;
    }
#ifdef MEASURE_LOCK_PERF
    read_table = gethrtime();
#endif

    status = real_pthread_mutex_lock( mp );
#ifdef MEASURE_LOCK_PERF
    mutex_locked = gethrtime();
#endif

    if(prevent_locks && mutex_info != NULL) {
      mutex_info->status |= MUTEX_LOCKING;
    }
    
    real_pthread_mutex_lock( &thr_info->sig_mutex );
    thr_info->status &= ~(THR_LOCKING_MUTEX);
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
    if(prevent_locks && !(thr_info->status & (THR_IN_SIGHANDLER|THR_COND_WAIT))){
      while(prevent_locks) {
	sched_yield();
      }
    }
  } else {
#ifdef MEASURE_LOCK_PERF
    signals_masked = gethrtime();
    read_table = gethrtime();
    mutex_locked = gethrtime();
#endif
    status = real_pthread_mutex_lock( mp );
  }
#ifdef MEASURE_LOCK_PERF
  signals_unmasked = gethrtime();

  real_pthread_mutex_lock(&timer_mutex);
  mask_time += signals_masked - lock_start;
  hash_access_time += read_table - signals_masked;
  mutex_lock_time += mutex_locked - read_table;
  unmask_time += signals_unmasked - mutex_locked;
  lock_cnt++;
  real_pthread_mutex_unlock(&timer_mutex);
#endif

  return status;
}

int pthread_mutex_trylock(pthread_mutex_t *mp)
{
  int status;
  chkpt_mutex_info_t *mutex_info;
  chkpt_thread_info_t *thr_info;

  INIT_REAL_PTHREAD_FUNCS();

  if (!init_done)
    return real_pthread_mutex_trylock(mp);

  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );

  if(thr_info != NULL) {
    /* prevent checkpoint signals while locking the mutex */
    real_pthread_mutex_lock( &thr_info->sig_mutex );
    if(prevent_locks && !(thr_info->status & THR_IN_SIGHANDLER)) {
      real_pthread_mutex_unlock( &thr_info->sig_mutex );
      while(prevent_locks) {
	sched_yield();
      }
      real_pthread_mutex_lock( &thr_info->sig_mutex );
    }
    thr_info->status |= THR_LOCKING_MUTEX;
    real_pthread_mutex_unlock( &thr_info->sig_mutex );

    if( add_held_mutex( mp, thr_info, &mutex_info ) != 0 ) {
      CRASH(("pthread_mutex_lock: cannot add mutex\n"));
    }
    
    status = real_pthread_mutex_trylock( mp );

    if (status == 0) {
      if(prevent_locks && mutex_info != NULL) {
	mutex_info->status |= MUTEX_LOCKING;
      }
      real_pthread_mutex_lock(&thr_info->sig_mutex);
      thr_info->status &= ~(THR_LOCKING_MUTEX);
      real_pthread_mutex_unlock(&thr_info->sig_mutex);
      if(prevent_locks && !(thr_info->status & THR_IN_SIGHANDLER)) {
	while(prevent_locks) {
	  sched_yield();
	}
      }
    } else {
      delete_held_mutex( mp );
    }
  } else {
    status = real_pthread_mutex_trylock( mp );
  }

  return status;
}

int pthread_mutex_unlock(pthread_mutex_t *mp)
{
  int status;
  chkpt_thread_info_t *thr_info;

  INIT_REAL_PTHREAD_FUNCS();

  if (!init_done)
    return real_pthread_mutex_unlock(mp);

  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );

  if(thr_info != NULL) {
    /* prevent checkpoint signals while locking the mutex */
    real_pthread_mutex_lock(&thr_info->sig_mutex);
    thr_info->status |= THR_LOCKING_MUTEX;
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
    
    status = real_pthread_mutex_unlock( mp );
    if (!(thr_info->status & THR_COND_WAIT)) {
      delete_held_mutex( mp );
    }
    
    real_pthread_mutex_lock(&thr_info->sig_mutex);
    thr_info->status &= ~THR_LOCKING_MUTEX;
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
  } else {
    status = real_pthread_mutex_unlock( mp );
  }

  return status;
}

/* In linux the std C library locks a mutex, then does pthread_mutex_init
 * on it without unlocking it when closing a file.  Thus I will free the
 * mutex info structure  if it exists when a program calls
 * pthread_mutex_init.
 */
int pthread_mutex_init(pthread_mutex_t *mp,
		       const pthread_mutexattr_t *mattr)
{
  int status;
  chkpt_thread_info_t *thr_info;

  INIT_REAL_PTHREAD_FUNCS();

  if (!init_done)
    return real_pthread_mutex_init(mp, mattr);

  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );
  if(thr_info != NULL) {
    /* prevent checkpoint signals while locking the mutex */
    real_pthread_mutex_lock(&thr_info->sig_mutex);
    thr_info->status |= THR_LOCKING_MUTEX;
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
      
    status = real_pthread_mutex_init(mp, mattr);
    delete_held_mutex( mp );
      
    real_pthread_mutex_lock(&thr_info->sig_mutex);
    thr_info->status &= ~THR_LOCKING_MUTEX;
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
  } else {
    status = real_pthread_mutex_init(mp, mattr);
  }

  return status;
}


int add_held_mutex( pthread_mutex_t *mp, chkpt_thread_info_t *thr_info,
		    chkpt_mutex_info_t **ret_info )
{
  chkpt_mutex_info_t *mutex_info;
  int mutex_ind;

  /* find info for this thread */
  if( thr_info != NULL ) {
    /* add this mutex to the list of mutexes this thread holds */
    /* malloc locks and unlocks a mutex, so we want to avoid calling it
     * to avoid serialization of all threads calling mutex lock and unlock
     */
    if( thr_info->free_mutexes == NULL) {
      /* malloc locks a mutex, locking a mutex will attempt to malloc memory,
       * which will attempt to lock a mutex, which will attempt to malloc
       * memory, which will attempt to lock a mutex, ...
       */
      assert(0);
      mutex_info =
	(chkpt_mutex_info_t *)malloc(MUTEX_INFO_INCR*sizeof(chkpt_mutex_info_t));
      if(thr_info->free_mutexes != NULL) {
	mutex_info = thr_info->free_mutexes;
	for(mutex_ind = 0 ; mutex_ind < (MUTEX_INFO_INCR-1) ; mutex_ind++) {
	  mutex_info[mutex_ind].next = mutex_info + mutex_ind + 1;
	}
	mutex_info[mutex_ind].next = NULL;
      } else {
	return -1;
      }
    }
    mutex_info = thr_info->free_mutexes;
    thr_info->free_mutexes = thr_info->free_mutexes->next;
    mutex_info->mutex = mp;
    mutex_info->next = thr_info->held_mutexes;
    thr_info->held_mutexes = mutex_info;

    if( ret_info != NULL ) {
      *ret_info = mutex_info;
    }
  } else {
    /* if not found, then this is happening during pthread_create */
    if( ret_info != NULL ) {
      *ret_info = NULL;
    }
  }
    

  return 0;
}

int delete_held_mutex( pthread_mutex_t *mp )
{
  chkpt_thread_info_t *thr_info;
  chkpt_mutex_info_t *mutex_info;
  chkpt_mutex_info_t *prev_info;

  if (pthread_self() == 0)
    return 0;

  /* find info for this thread */
  if (htable_find(chkpt_thr_tab, pthread_self(), (void **)&thr_info) == 0) {

    if(pthread_self() != thr_info->id) {
      CRASH("thread "PTHREAD_FMT" found thread info entry for thread "PTHREAD_FMT"\n",
	    pthread_self(), thr_info->id);
    }

    /* if not found, then this is happening during pthread_create */
    /* remove this mutex from the list of mutexes this thread holds */
    prev_info = NULL;
    mutex_info = thr_info->held_mutexes;
    while(mutex_info != NULL && mutex_info->mutex != mp) {
      prev_info = mutex_info;
      mutex_info = mutex_info->next;
    }
    
    if(mutex_info == NULL) {
      /* mutex not found */
      return -1;
    }
    
    if(prev_info == NULL) {
      thr_info->held_mutexes = mutex_info->next;
    } else {
      prev_info->next = mutex_info->next;
    }
    mutex_info->next = thr_info->free_mutexes;
    thr_info->free_mutexes = mutex_info;
    /* TODO: at some point we should free old blocks of mutexes */
    /*     free(mutex_info); */
  }

  return 0;
}

chkpt_mutex_info_t *find_held_mutex(chkpt_thread_info_t *thr_info,
				    pthread_mutex_t *mp)
{
  chkpt_mutex_info_t *mutex_info;

  mutex_info = NULL;
  if (thr_info != NULL) {
    mutex_info = thr_info->held_mutexes;
    while( mutex_info != NULL && mutex_info->mutex != mp ) {
      mutex_info = mutex_info->next;
    }
  } 

  return mutex_info;
}

int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex)
{
  int status;
  chkpt_mutex_info_t *mutex_info1;
  chkpt_mutex_info_t *mutex_info2;
  chkpt_thread_info_t *thr_info;

  INIT_REAL_PTHREAD_FUNCS();

  if (!init_done)
    return real_pthread_cond_wait(cond, mutex);

  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );

  mutex_info1 = find_held_mutex(thr_info, mutex);
  if (mutex_info1 != NULL) {
    mutex_info1->status |= MUTEX_COND_WAIT;
  } else {
    DBG_PRINTF(("cond with no mutex\n"));
  }

  if (thr_info != NULL) {
    thr_info->status |= THR_COND_WAIT;
  }

  status = real_pthread_cond_wait(cond, mutex);

  /* prevent the thread from continuing if checkpointing is happening */
  if (thr_info != NULL) {
    real_pthread_mutex_lock(&thr_info->sig_mutex);
    if (prevent_locks && !(thr_info->status & THR_IN_SIGHANDLER)) {
      real_pthread_mutex_unlock(&thr_info->sig_mutex);
      while (prevent_locks) {
	sched_yield();
      }
      real_pthread_mutex_lock(&thr_info->sig_mutex);
    }
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
    thr_info->status &= ~THR_COND_WAIT;
  }
  
  mutex_info2 = find_held_mutex(thr_info, mutex);
  if (mutex_info2 != NULL) {
    mutex_info2->status &= ~MUTEX_COND_WAIT;
  } else {
    DBG_PRINTF(("cond with no mutex 2\n"));
  }

  return status;
}

int pthread_cond_timedwait(pthread_cond_t *cond, pthread_mutex_t *mutex,
			   const struct timespec *abstime)
{
  int status;
  chkpt_mutex_info_t *mutex_info;
  chkpt_thread_info_t *thr_info;

  INIT_REAL_PTHREAD_FUNCS();

  if (!init_done)
    return real_pthread_cond_timedwait(cond, mutex, abstime);

  thr_info = NULL;
  htable_find( chkpt_thr_tab, pthread_self(), (void **)&thr_info );

  mutex_info = find_held_mutex(thr_info, mutex);
  if (mutex_info != NULL) {
    mutex_info->status |= MUTEX_COND_WAIT;
  }

  if (thr_info != NULL) {
    thr_info->status |= THR_COND_WAIT;
  }

  status = real_pthread_cond_timedwait( cond, mutex, abstime );

  /* prevent the thread from continuing if checkpointing is happening */
  if (thr_info != NULL) {
    real_pthread_mutex_lock(&thr_info->sig_mutex);
    if (prevent_locks && !(thr_info->status & THR_IN_SIGHANDLER)) {
      real_pthread_mutex_unlock(&thr_info->sig_mutex);
      while (prevent_locks) {
	sched_yield();
      }
      real_pthread_mutex_lock(&thr_info->sig_mutex);
    }
    real_pthread_mutex_unlock(&thr_info->sig_mutex);
    thr_info->status &= ~THR_COND_WAIT;
  }
  
  mutex_info = find_held_mutex(thr_info, mutex);
  if (mutex_info != NULL) {
    mutex_info->status &= ~MUTEX_COND_WAIT;
  }

  return status;
}

int init_real_pthread_funcs( void )
{
  sysio_init();
  libcio_init();

  if( !real_funcs_initted ) {
    real_pthread_create =
      (int (*)(pthread_t *, const pthread_attr_t *, void *(*)(void *), void *))
      dlsym( RTLD_NEXT, "pthread_create" );
    if( real_pthread_create == NULL ) {
      CRASH("cannot find pthread_create in shared library\n%s\n", dlerror());
    }

    real_pthread_mutex_lock =
      (int (*)(pthread_mutex_t *))dlsym( RTLD_NEXT, "pthread_mutex_lock" );
    if( real_pthread_mutex_lock == NULL ) {
      CRASH("cannot find pthread_mutex_lock in shared lib\n%s\n", dlerror());
    }

    real_pthread_mutex_trylock =
      (int (*)(pthread_mutex_t *))dlsym( RTLD_NEXT, "pthread_mutex_trylock" );
    if( real_pthread_mutex_trylock == NULL ) {
      CRASH("cannot find pthread_mutex_trylock in shared lib\n%s\n", dlerror());
    }

    real_pthread_mutex_unlock =
      (int (*)(pthread_mutex_t *))dlsym( RTLD_NEXT, "pthread_mutex_unlock" );
    if( real_pthread_mutex_unlock == NULL ) {
      CRASH("cannot find pthread_mutex_unlock in shared lib\n%s\n", dlerror());
    }

    real_pthread_mutex_init =
      (int (*)(pthread_mutex_t *, const pthread_mutexattr_t *))
      dlsym( RTLD_NEXT, "pthread_mutex_init" );
    if( real_pthread_mutex_init == NULL ) {
      CRASH("cannot find pthread_mutex_init in shared libr\n%s\n", dlerror());
    }

    real_pthread_cond_wait = (int (*)(pthread_cond_t *, pthread_mutex_t *))
      dlsym( RTLD_NEXT, "pthread_cond_wait" );
    if( real_pthread_cond_wait == NULL ) {
      CRASH("cannot find pthread_cond_wait in shared lib\n%s\n", dlerror());
    }

    real_pthread_cond_timedwait =
      (int (*)(pthread_cond_t *, pthread_mutex_t *, const struct timespec *))
      dlsym( RTLD_NEXT, "pthread_cond_timedwait" );
    if( real_pthread_cond_timedwait == NULL ) {
      CRASH("cannot find pthread_cond_timedwait in shared lib\n%s\n", dlerror());
    }

    real_pthread_cond_signal =
      (int (*)(pthread_cond_t *))dlsym( RTLD_NEXT, "pthread_cond_signal" );
    if( real_pthread_cond_signal == NULL ) {
      CRASH("cannot find pthread_cond_signal in shared lib\n%s\n", dlerror());
    }

    real_pthread_detach =
      (int (*)(pthread_t))dlsym( RTLD_NEXT, "pthread_detach" );
    if( real_pthread_detach == NULL ) {
      CRASH("cannot find pthread_detach in shared library\n%s\n", dlerror());
    }

#ifdef PTHREAD_SELF_INTERCEPT_TEST
    real_pthread_self =
      (pthread_t (*)(void))dlsym( RTLD_NEXT, "pthread_self" );
    if( real_pthread_self == NULL ) {
      CRASH("cannot find pthread_self in shared library\n%s\n", dlerror());
    }
#endif
  }

  real_funcs_initted = 1;

  return 0;
}

void chkpt_sighandler( int sig, siginfo_t *siginfo, void *ucontext )
{
  pthread_t thr_id;
  chkpt_thread_info_t *thr_info;
  chkpt_mutex_info_t *mutex_info;
  int my_handler_cnt;
  int status;

  sigset_t mask;


  INIT_REAL_PTHREAD_FUNCS();

  thr_id = pthread_self();

  if(htable_find( chkpt_thr_tab, thr_id, (void **)&thr_info ) != 0) {
    CRASH("sigusr2_action: cannot find self\n");
  }
  thr_info->status |= THR_IN_SIGHANDLER;

  real_pthread_mutex_lock(&chkpt_sighandler_mutex);
  my_handler_cnt = thr_unlock_cnt++;
  real_pthread_mutex_unlock(&chkpt_sighandler_mutex);
  
  sigfillset(&mask);
  /* for debugging allow SIGINT (i.e., ctrl-C) */
  sigdelset(&mask, SIGINT);
  pthread_sigmask( SIG_SETMASK, &mask, &thr_info->sigmask );

  /* go through list of mutexes to see if another process is waiting on
   * a condition variable with that mutex
   */
  if (thr_id == main_thread_id) {
    SIGHDLR_DBG("main thread in chkpt_sighandler\n");
  }
  mutex_info = thr_info->held_mutexes;
  while( mutex_info != NULL ) {
    /* unlock all the mutexes whether necessary or not */
#ifdef SIGHANDLER_DEBUG 
    SIGHDLR_DBG(PTHREAD_FMT": unlocking mutex %p", thr_id, mutex_info->mutex);
    if (mutex_info->status & MUTEX_COND_WAIT) {
      SIGHDLR_DBG(" (condition wait)");
    }
    SIGHDLR_DBG("\n");
#endif
    status = real_pthread_mutex_unlock( mutex_info->mutex );
    if( status == 0 ) {
      /* Only mark as released if I really had the lock.  It is possible
       * that in some cases a thread will be interrupted before it
       * actually gets the lock.  In that case, the thread should not
       * try to lock it in the signal hander because it will try to lock it
       * when it returns from the signal handler.
       */
      mutex_info->status |= MUTEX_RELEASED;
    } else {
      fprintf(stderr, "mutex not locked, so not unlocking it\n");
    }
     
    mutex_info = mutex_info->next;
  }

  pthread_mutex_lock(&chkpt_sighandler_mutex);
  if( thr_unlock_cnt == num_other_threads+1) {
    pthread_cond_broadcast(&chkpt_sighandler_cond);
  }
  while(thr_unlock_cnt < num_other_threads+1) {
    pthread_cond_wait(&chkpt_sighandler_cond, &chkpt_sighandler_mutex);
  }
  pthread_mutex_unlock(&chkpt_sighandler_mutex);

  /* all threads have unlocked all their mutexes.  It is safe to allow
   * pthread_mutex_lock calls to proceed
   */
  prevent_locks = 0;
  htable_forall(chkpt_thr_tab, clear_thr_flags, NULL);

  if (thr_id == main_thread_id) {
    /* I can zero thr_lock_cnt here because I know that the other threads
     * will block waiting for this thread in save_thread_state which is
     * called before thr_lock_cnt is accessed
     */
    thr_lock_cnt = 0;
    do_checkpoint(chkpt_filename);
    all_threads_signalled = 0;
  } else {
    save_thread_state();
  }

  /*   printf( "%d my turn is %d current turn is %d\n", */
  /* 	  thr_id, my_handler_cnt, thr_lock_cnt ); */

  /* assume this gets set before the next checkpoint */
  if (my_handler_cnt == 0) {
    thr_unlock_cnt = 0;
  }

  /* relock mutexes; there should be no contention... */
  mutex_info = thr_info->held_mutexes;
  while( mutex_info != NULL ) {
    if((mutex_info->status & MUTEX_RELEASED)
       && !(mutex_info->status & MUTEX_LOCKING)
       && !(mutex_info->status & MUTEX_COND_WAIT)) {

      SIGHDLR_DBG(PTHREAD_FMT": locking held mutex %p\n",
	      thr_id, mutex_info->mutex);
      status = real_pthread_mutex_lock( mutex_info->mutex );
      if( status == 0 ) {
	mutex_info->status &= ~MUTEX_RELEASED;
      } else if( status != EBUSY ) {
	fprintf(stderr, "re-lock failed\n");
      }
    } else if(!(mutex_info->status & MUTEX_RELEASED)) {
	fprintf(stderr, "mutex not released, so not reacquiring it\n");
    }
    
    mutex_info = mutex_info->next;
  }

  /* wait for threads to lock all mutexes for which they do not contend */  
  pthread_mutex_lock(&chkpt_sighandler_mutex);
  SIGHDLR_DBG("thread "PTHREAD_FMT" waiting for others\n", thr_id);
  thr_lock_cnt++;
  if(thr_lock_cnt == num_other_threads+1) {
    SIGHDLR_DBG("thread "PTHREAD_FMT" calling pthread_cond_broadcast\n", thr_id);
    pthread_cond_broadcast(&chkpt_sighandler_cond);
  }
  while(thr_lock_cnt < num_other_threads+1) {
    SIGHDLR_DBG("thread "PTHREAD_FMT" is %d of %d\n",
		thr_id, thr_lock_cnt, num_other_threads+1);
    real_pthread_cond_wait(&chkpt_sighandler_cond, &chkpt_sighandler_mutex);
  }
  SIGHDLR_DBG("thread "PTHREAD_FMT" unblocked\n", thr_id);
  pthread_mutex_unlock(&chkpt_sighandler_mutex);

  /* lock remaining mutexes */
  mutex_info = thr_info->held_mutexes;
  while( mutex_info != NULL ) {
    if((mutex_info->status & MUTEX_RELEASED)
       && ((mutex_info->status & MUTEX_LOCKING)
	   || (mutex_info->status & MUTEX_COND_WAIT))) {
      SIGHDLR_DBG(PTHREAD_FMT": locking cond_wait mutex %p\n",
	      thr_id, mutex_info->mutex);
      status = real_pthread_mutex_lock( mutex_info->mutex );
      SIGHDLR_DBG(PTHREAD_FMT": locked cond_wait mutex %p\n",
	      thr_id, mutex_info->mutex);
      if( status == 0 ) {
	mutex_info->status &= ~(MUTEX_RELEASED|MUTEX_LOCKING);
      } else if( status != EBUSY ) {
	fprintf(stderr, "re-lock failed\n");
      }
    }
    
    mutex_info = mutex_info->next;
  }
  /* now that all mutexes and memory are restored it should be ok to handle
   * signals
   */
  pthread_sigmask( SIG_SETMASK, &thr_info->sigmask, NULL );
}

int clear_thr_flags(long key, void *value, void *arg)
{
  chkpt_thread_info_t *thr_info;

  thr_info = (chkpt_thread_info_t *)value;
  thr_info->status &= ~(THR_SIGNALLED|THR_IN_SIGHANDLER);
  return 0;
}

int pthread_detach(pthread_t threadID)
{
  pthread_t myID;
  int status;
  chkpt_thread_info_t *thr_info;
  

  INIT_REAL_PTHREAD_FUNCS();

  /* want detach to be atomic wrt checkpointing */
#if 0
  real_pthread_mutex_lock(&chkpt_start_mutex);
#endif
  status = real_pthread_detach(threadID);
  if (status == 0) {
    myID = pthread_self();
    /* Need to lock the hash table when I am looking for another thread's
     * entry.  Locking the table prevents the thread from exiting before
     * I am done with its hash table entry.
     */
    if(threadID != myID) {
      htable_lock(chkpt_thr_tab);
    }

    if(htable_find(chkpt_thr_tab, threadID, (void **)&thr_info) != 0) {
      CRASH("pthread_detach: cannot find thread %d\n", threadID);
    }
    thr_info->attr.detachstate = PTHREAD_CREATE_DETACHED;

    if(threadID != myID) {
      htable_unlock(chkpt_thr_tab);
    }
  }
#if 0
  real_pthread_mutex_unlock(&chkpt_start_mutex);
#endif
  
  return status;
}

#ifdef PTHREAD_SELF_INTERCEPT_TEST
pthread_t pthread_self(void)
{
  INIT_REAL_PTHREAD_FUNCS();

  return real_pthread_self();
}
#endif

#elif OS == LINUX

void chkpt_sighandler( int sig, siginfo_t *siginfo, void *ucontext )
{
  pthread_t thr_id;
  chkpt_thread_info_t *thr_info;
  sigset_t mask;
  int status;
  int recovering;
  int orig_errno;

  /* As Stevens points out in APUE, errno should be saved if the
   * signal handler makes calls that could affect it.
   */
  orig_errno = errno;

  thr_id = pthread_self();
  if(htable_find( chkpt_thr_tab, thr_id, (void **)&thr_info ) != 0) {
    CRASH("sigusr2_action: cannot find self\n");
  }

  sigfillset(&mask);
  /* for debugging allow SIGINT (i.e., ctrl-C) */
  sigdelset(&mask, SIGINT);
  pthread_sigmask( SIG_BLOCK, &mask, &thr_info->sigmask );

  if (thr_id == main_thread_id) {
    recovering = do_checkpoint(chkpt_filename);
  } else {
    recovering = save_thread_state();
  }

  if (thr_id != chkpt_thread_id) {
    /* wait for checkpoint thread to run callbacks */
    if ( (status = chkpt_barrier_wait(chkpt_barrier)) < 0) {
      fprintf(stderr, "barrier_wait retured %d\n", status);
      exit(-1);
    }
  } else {
    /* need to wait for others to read chkpt_recovering before
     * chkpt_thread returns.  Otherwise, chkpt_thread could reset
     * chkpt_recovering before one of the other threads sees that it
     * is set.
     */
    chkpt_barrier_wait_for_others(chkpt_barrier);
  }

  /* should only restore pending signals during recovery */
  if (recovering) {
    restore_pending_signals(&thr_info->pending);
  }
  pthread_sigmask( SIG_SETMASK, &thr_info->sigmask, NULL );

  errno = orig_errno;
}

int init_real_pthread_funcs( void )
{
  sysio_init();
  libcio_init();

  if( !real_funcs_initted ) {
    real_pthread_create =
      (int (*)(pthread_t *, const pthread_attr_t *, void *(*)(void *), void *))
      dlsym( RTLD_NEXT, "pthread_create" );
    if( real_pthread_create == NULL ) {
      CRASH("cannot find pthread_create in shared library\n%s\n", dlerror());
    }
  }

  real_funcs_initted = 1;

  return 0;
}
#else
#error Unsupported OS.  Maybe try the code for Linux?
#endif
