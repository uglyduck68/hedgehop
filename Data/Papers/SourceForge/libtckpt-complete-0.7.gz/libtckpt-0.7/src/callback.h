/*
 * callback.h
 *
 * Prototypes and definitions to help manage checkpoint callback functions
 *
 * History
 * -------
 * $Log: callback.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:37:32  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1999/01/06  23:43:42  dieter
 * Files were created after FTCS paper so move to version 2 to
 * be consistent with other library code files.
 *
 * Revision 1.1  1999/01/06  23:21:00  dieter
 * Initial revision
 *
 */

#ifndef CHKPT_CALLBACK_H
#define CHKPT_CALLBACK_H

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void pre_chkpt_callbacks(int chkpt_num);
void post_chkpt_callbacks(int chkpt_num);
void recovery_callbacks(int chkpt_num);

#endif /* CHKPT_CALLBACK_H */
