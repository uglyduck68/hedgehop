/*
 * save.c
 *
 * save the checkpoint file to disk
 *
 * History
 * -------
 * $Log: save.c,v $
 * Revision 6.6  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 * Revision 6.5  2000/10/25 23:27:05  dieter
 * Improved handling of disk full errors.
 *
 * Revision 6.4  2000/10/20 21:20:12  dieter
 * Fixed some typos.
 *
 * Revision 6.3  2000/10/20 20:38:24  dieter
 * Handle disk full errors more robustly.
 *
 * Revision 6.2  2000/05/08 19:07:51  dieter
 * Remap excluded segments from /dev/zero, unless the user specifically
 * requests that they not be restored.
 *
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.5  2000/02/01 23:32:57  dieter
 * Truncate the the checkpoint file when opening it.
 *
 * Revision 4.4  2000/01/28 22:53:15  dieter
 * include config.h
 *
 * Revision 4.3  2000/01/28  21:09:12  dieter
 * Only deal with manager state in Linux.
 *
 * Revision 4.2  2000/01/19 22:47:04  dieter
 * Write manager enviroment to checkpoint file.
 *
 * Revision 4.1  1999/08/02 15:27:02  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:15:48  dieter
 * Made release 0.02
 *
 * Revision 2.2  1999/01/20  00:13:10  dieter
 * label any segment that is part of the stack as a stack segment.
 *
 * Revision 2.1  1998/12/22  15:34:56  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.9  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.8  1998/09/08  21:05:44  dieter
 * Save the stack address separately so that I can restore the stack pointer
 * before loading any segments.  Then load all segments the same way
 * (including the stack segment.)  Otherwise must handle case where the
 * stack consists of multiple segments.
 *
 * Revision 1.7  1998/08/31  12:20:48  dieter
 * Save stack size and address for the thread stacks so they will be
 * available during recovery.
 *
 * Revision 1.6  1998/08/25  20:32:53  dieter
 * Cleaned up a bit.
 *
 * Revision 1.5  1998/08/25  20:18:04  dieter
 * Added support for sequential I/O files.
 *
 * Revision 1.4  1998/08/17  17:03:15  dieter
 * Added the main thread to the thread table.
 *
 * Revision 1.3  1998/08/10  19:18:12  dieter
 * Switched from thread info list to hash table of thread info.
 *
 * Revision 1.2  1998/07/31  20:15:14  dieter
 * Pretty much everything is moved over from the old version of checkpointing.
 *
 * Revision 1.1  1998/07/31  13:36:37  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
/* should be in sched.h */
extern int  __clone(int (*fn) (void *arg), void *child_stack,
		    int flags, void *arg);
#include <semaphore.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "debug.h"
#include "memdebug.h"
#include "machif.h"
#include "cppthread.h"
#include "cpstate.h"
#include "save.h"
#include "sysio.h"

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/* This struct contains all the arguments to be passed to save_chkpt.  It is
   used to pass them through the __clone system call.
*/
typedef struct save_args {
  char *filename;
  pid_t pid;
  proc_status_t *status;
  int nmap;
  memmap_t *mapping;
} save_args_t;

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define CHILD_STACK_SIZE 2 * 1024 * 1024

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

static int dummy;		/* a variable in the data segment	     */
static pid_t save_pid = -1;
static save_args_t g_save_args;
static sem_t async_save_sem;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static void sigchld_handler(int sig, siginfo_t *info, void *uc);
static int async_child(void *arg);
int  write_thread_info( int chkpt_fd );
int  write_thr_entry( long key, void *value, void *arg );
#if OS == LINUX
int  write_manager_info( int chkpt_fd );
#endif
int  compute_mapping_offsets( proc_status_t *proc_status,
			      int nmap, memmap_t *mapping );
int  check_for_thr_stack( long key, void *value, void *arg );
int  write_mapping_header( int chkpt_fd, proc_status_t *status,
			   int nmap, memmap_t *mapping);
int chkpt_write_all(int fd, const void *buf, size_t count);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int chkpt_save_init(void) 
{
  struct sigaction action;
  int status;

  /* setup a sig handler for the child thread */
  action.sa_sigaction = sigchld_handler;
  action.sa_flags = SA_SIGINFO|SA_RESTART|SA_NOCLDSTOP;
  sigemptyset(&action.sa_mask);
  if ( (status = sigaction(SIGCHLD, &action, NULL)) < 0) {
    return status;
  }
  status = sem_init(&async_save_sem, 0, 0);
  
  return status;
}

static void sigchld_handler(int sig, siginfo_t *info, void *uc)
{
  int   status;
  pid_t pid;

  if ( (pid = waitpid(save_pid, &status, 0)) != save_pid) {
    fprintf(stderr, "waitpid returned %d\n", pid);
    CRASH_ERR("sigchld_handler: waitpid failed");
  }
  if (status != 0) {
    CRASH("async save clone child exited with bad status\n");
  }
  save_pid = -1;
  sem_post(&async_save_sem);
  
  return;
}

int chkpt_async_save(char *filename, pid_t pid, proc_status_t *status,
		      int nmap, memmap_t *mapping)
{
  void *child_stack;
  
  /* Point child_stack at the current stack.  Overlap is ok because
   * the child is getting a copy of VM (ie, it is not sharing with
   * the parent.  Without the overlap the child crashes on the first
   * system call because the thread library cannot figure out which
   * thread this is.  Just use the address of a variable on this
   * thread's stack as the new stack pointer.
   *
   * (We end up longjmp'ing back to the frame below this on the stack
   * so even if this function's stack frame gets hosed we should still
   * be ok.)
   */
  child_stack = (char *)&child_stack - 1024;
  g_save_args.filename = filename;
  g_save_args.pid = pid;
  g_save_args.status = status;
  g_save_args.nmap = nmap;
  g_save_args.mapping = mapping;
  save_pid = __clone(async_child, child_stack, SIGCHLD, &g_save_args);
  if (save_pid == -1) {
    CRASH_ERR("clone failed for async save\n");
  }
  
  return 0;
}

static int async_child(void *arg)
{
  save_args_t *save_args = (save_args_t *)arg;

  return save_chkpt(save_args->filename, save_args->pid, save_args->status,
		    save_args->nmap, save_args->mapping);
}

void chkpt_wait_for_async_save(void)
{

  /* cannot call waitpid here because it was the main thread that
   * created the async save process and this is the checkpointing
   * thread.  Only the parent can wait for a process.
   */
  /* wait for child pid */
  sem_wait(&async_save_sem);
}

int save_chkpt( char *filename, pid_t pid, proc_status_t *status,
		int nmap, memmap_t *mapping )
{
  int  chkpt_fd;
  int  write_status;		/* status of writing data to checkpoint */

  /* open checkpoint file */
  chkpt_fd = sys_open( filename, O_CREAT|O_WRONLY|O_TRUNC, 0644 );
  if( chkpt_fd == -1 ) {
    fprintf( stderr, "error opening checkpoint file %s\n", filename );
    perror( filename );
    return -1;
  }

  /* setup memory mapping header */
  compute_mapping_offsets( status, nmap, mapping );

  /* write thread info */
  if ( (write_status = write_thread_info( chkpt_fd )) != 0)
    goto err_out;
#if OS == LINUX
  if ( (write_status = write_manager_info( chkpt_fd )) != 0)
    goto err_out;
  
#endif
  
  /* write memory mapping header */
  write_status = write_mapping_header( chkpt_fd, status, nmap, mapping );
  if (write_status != 0) 
    goto err_out;

  /* write memory mappings */
  if ( (write_status = write_mapping_data( chkpt_fd, pid, nmap, mapping )) != 0)
    goto err_out;

  /* close checkpoint file */
  sys_close( chkpt_fd );

  return 0;

err_out:
  if (write_status < 0) {
    fprintf(stderr, "error writing checkpoint file: write returned 0\n");
  } else {
    fprintf(stderr, "error writing checkpoint file: %s\n", strerror(write_status));
  }
  return -1;
}

/* WARNING: Change the offset computation in compute_mapping_offsets if
 * 	    you change write_thread_info or write_thr_entry.
 */
int  write_thread_info(int chkpt_fd)
{
  int n_threads;
  int status;
  
  /* count number of additional threads (i.e., not including main) */
  n_threads = htable_entry_cnt(chkpt_thr_tab);

  if ( (status = chkpt_write_all(chkpt_fd, &n_threads, sizeof(int))) != 0) {
    ERROR("error writing num threads (%d) to thread header\n", n_threads);
    return status;
  }
  
  status = htable_forall(chkpt_thr_tab, write_thr_entry, (void *)chkpt_fd);
  if (status != 0) {
    ERROR("error writing thread table to thread header\n");
    return status;
  }

  return 0;
}

int write_thr_entry( long key, void *value, void *arg )
{
  int chkpt_fd;
  int status;

  chkpt_fd = (int)arg;
  status = chkpt_write_all(chkpt_fd, value, sizeof(chkpt_thread_info_t));
  if (status != 0) {
    ERROR("error writing thread %ld's entry to header\n",
	  ((chkpt_thread_info_t *)value)->id);
  }

  return status;
}

#if OS == LINUX
int write_manager_info( int chkpt_fd )
{
  int status;

  if ( (status = chkpt_write_all(chkpt_fd, &manager_env, sizeof(sigjmp_buf))) ) {
    ERROR("error writing thread manager info to header\n");
  }
  return status;
}
#endif

int  compute_mapping_offsets( proc_status_t *proc_status,
			      int nmap, memmap_t *mapping )
{
  unsigned long  offset;
  int            pagesize;
  int            i;
  int 		 n_threads;

  /* compute amount of space taken by thread info table */
  n_threads = htable_entry_cnt(chkpt_thr_tab);
  offset = sizeof(int) + n_threads * sizeof(chkpt_thread_info_t)
    + sizeof(sigjmp_buf);

  /* compute amount of space taken by memory mapping table */
  offset = offset + sizeof(int) + 2*sizeof(caddr_t) + nmap * sizeof(memmap_t);

  /* maybe use page size out of fmap? */
  pagesize = sysconf(_SC_PAGESIZE);
  if( offset % pagesize != 0 )
    offset = ((offset + pagesize) / pagesize) * pagesize;

  for( i = 0 ; i < nmap ; i++ ) {
    /* determine memory mapping type */
    if (mapping[i].type != SEG_EXCL) {
      /* mapping[i].type set to SEG_EXCL in chkpt_intersect_map  */
      if( proc_status->stkbase <= mapping[i].addr
	  && mapping[i].addr < proc_status->stkbase + proc_status->stksize ) {
	mapping[i].type = SEG_STCK;
      } else if( (char *)&dummy >= mapping[i].addr
		 && (char *)&dummy < mapping[i].addr + mapping[i].len ) {
	mapping[i].type = SEG_DATA;
      } else if( (char *)mapping >= mapping[i].addr
		 && (char *)mapping < mapping[i].addr + mapping[i].len ) {
	mapping[i].type = SEG_HEAP;
      } else if( (char *)compute_mapping_offsets >= mapping[i].addr
		 && ((char *)compute_mapping_offsets
		     < mapping[i].addr + mapping[i].len)  ) {
	mapping[i].type = SEG_CODE;
	mapping[i].remap = 0;
      } else {
	mapping[i].type = SEG_DYNM;
	/* check for thread stack segment */
	htable_forall( chkpt_thr_tab, check_for_thr_stack, mapping + i );
      }
    }

    /* determine memory mapping offset; code segments and excluded segments
       are not written to file */
    if( mapping[i].type != SEG_CODE && mapping[i].type != SEG_EXCL) {
      mapping[i].file_offset = offset;

      offset += mapping[i].len;
      if( offset % pagesize != 0 )
	offset = ((offset + pagesize) / pagesize) * pagesize;
    }
  }

  return 0;
}

int  check_for_thr_stack( long key, void *value, void *arg )
{
  memmap_t *mapping;
  chkpt_thread_info_t *thr_info;

  mapping = (memmap_t *)arg;
  thr_info = (chkpt_thread_info_t *)value;

  if( thr_info->id == main_thread_id )
    return 0;
  
  if( mapping->addr <= (char *)thr_info->stack_item &&
      (char *)thr_info->stack_item < mapping->addr + mapping->len ) {
    mapping->type = SEG_TSTK;
    thr_info->attr.stackaddr = mapping->addr;
    thr_info->attr.stacksize = mapping->len;
    return 1;
  }

  return 0;
}

int  write_mapping_header( int chkpt_fd, proc_status_t *status, int nmap,
			   memmap_t *mapping)
{
  int i;
  caddr_t brkaddr;
  int write_status;

  write_status = chkpt_write_all(chkpt_fd, &nmap, sizeof(int));
  if (write_status != 0) {
    ERROR("error writing number of memory segments to mapping header\n");
    return write_status;
  }
  brkaddr = status->brkbase + status->brklen;
  write_status = chkpt_write_all(chkpt_fd, &brkaddr, sizeof(caddr_t));
  if (write_status != 0) {
    ERROR("error writing brkaddr to mapping header\n");
    return write_status;
  }
  write_status = chkpt_write_all(chkpt_fd, &status->stkbase, sizeof(caddr_t));
  if (write_status != 0) {
    ERROR("error writing stack base to checkpoint header\n");
    return write_status;
  }
  for( i = 0 ; i < nmap && (write_status == 0) ; i++ ) {
    write_status = chkpt_write_all(chkpt_fd, &mapping[i], sizeof(memmap_t));
    if (write_status != 0) {
      ERROR("error writing mapping %d (%p-%p) to checkpoint header\n",
	    i, mapping[i].addr, mapping[i].addr + mapping[i].len);
    }
  }

  return write_status;
}

/* chkpt_write_all
 *
 * Write all the data passed, retrying and recovering from interrupts.
 * Return errno if an error occurred, -1 if write returns 0, or 0 on success.
 */
int chkpt_write_all(int fd, const void *buf, size_t count)
{
  ssize_t n_written;

  while(count > 0) {
    n_written = write(fd, buf, count);
    if (n_written <= 0) {
      if (errno == EINTR) {
	n_written = 0;
      } else {
	return (n_written < 0) ? errno : -1;
      }
    }
    count -= n_written;
    buf += n_written;
  }

  return 0;
}
