/*
 * cpserver.c
 *
 * A simple checkpoint server.  This is based on Klat2's setup where
 * k65 (the node with a disk) has four nics and the FNN is setup so
 * that four sequentially numbered machines write to k65 on different
 * nics.  K65 is fast enough to handle four incoming connections at
 * wire speed so I'll start four threads, one per NIC, and allow four
 * connections at once.
 *
 * History
 * -------
 * $Log: cpserver.c,v $
 * Revision 6.1  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h> 
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "debug.h"
#include "cpserver.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/* Number of threads should equal number of interfaces.  This server
 * is designed for the klat2 setup where each of the four interfaces
 * is connected to 1/4 of the machines.  The machines are setup so that
 * all the machines with (id % 4 == 0) connect to k65 through eth0,
 * all the machines with (id % 4 == 1) conndect through eth1, etc.
 * Thus any four machines with different (id % 4) numbers can write
 * to k65 at the same time without interfering with each other.
 */
#define NUM_THREADS 4		/* number of threads */
#define MAX_CP_BASE 128		/* maximum checkpoint file basename */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct req {
  int fd;			/* file descriptor for which to handle req */
  cpserv_req_t req;		/* the request */
  struct req *next;
} req_node_t;

typedef struct req_head {
  req_node_t     *first;	/* first request in the list */
  pthread_mutex_t mutex;	/* mutex for accessing the queue */
  pthread_cond_t  available;	/* condition signalled what data is added */
} req_head_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

static req_head_t queues[NUM_THREADS];

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

static void queue_init(void);
static void queue_req(int fd, cpserv_req_t req_type, int wid);

static void thread_init(void);
static void *worker_thread(void *arg);

int write_all(int fd, const void *buf, size_t count);
int read_all(int fd, void *buf, size_t count);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  int listen_fd;
  int conn_fd;
  struct sockaddr_in my_addr;
  cpserv_msg_t msg;

  queue_init();
  thread_init();

  /* initialize socket */
  if ( (listen_fd = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
    CRASH_ERR("socket");
  }
  memset(&my_addr, 0, sizeof(my_addr));
  my_addr.sin_family = AF_INET;
  my_addr.sin_port = htons(CP_SERVER_PORT);
  my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if (bind(listen_fd, &my_addr, sizeof(my_addr)) < 0) {
    CRASH_ERR("server bind failed");
  }
  if (listen(listen_fd, MAX_HOSTS) < 0) {
    CRASH_ERR("listen faild");
  }
  while(1) {
    if ((conn_fd = accept(listen_fd, NULL, NULL)) < 0) {
      CRASH_ERR("accept failed");
    }
    read_all(conn_fd, &msg, sizeof(msg));
    printf("got msg version = %d, req = %d, wid = %ld\n",
	   msg.version, msg.req, msg.wid);
    /*    if (msg.version == CP_SERVER_VERSION) */
    queue_req(conn_fd, msg.req, msg.wid);
  }
}

static void queue_init(void)
{
  int i;

  for(i = 0 ; i < NUM_THREADS ; i++) {
    queues[i].first = NULL;
    pthread_mutex_init(&queues[i].mutex, NULL);
    pthread_cond_init(&queues[i].available, NULL);
  }
}

/* queue request in appropriate thread's queue */
static void queue_req(int fd, cpserv_req_t req_type, int wid)
{
  req_node_t *req;		/* an incoming request */

  if ( (req = (req_node_t *)malloc(sizeof(req_node_t))) == NULL) {
    CRASH_ERR("cannot allocate space for request\n");
  }
  req->fd = fd;
  req->req = req_type;

  pthread_mutex_lock(&queues[wid % NUM_THREADS].mutex);
  req->next = queues[wid % NUM_THREADS].first;
  queues[wid % NUM_THREADS].first = req;
  pthread_mutex_unlock(&queues[wid % NUM_THREADS].mutex);
  pthread_cond_signal(&queues[wid % NUM_THREADS].available);
}

static void thread_init(void)
{
  int i;
  pthread_attr_t attr;
  pthread_t tid;
  int status;

  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  for(i = 0 ; i < NUM_THREADS ; i++) {
    status = pthread_create(&tid, &attr, worker_thread, &queues[i]);
    if (status < 0) {
      fprintf(stderr, "pthread_create: %s", strerror(status));
      CRASH("pthread_create cannot create thread");
    }
  }
  pthread_attr_destroy(&attr);
}

static void *worker_thread(void *arg)
{
  req_head_t *my_queue= (req_head_t *)arg;
  req_node_t *req;
  char foo[100];

  while(1) {
    pthread_mutex_lock(&my_queue->mutex);
    while(my_queue->first == NULL) {
      pthread_cond_wait(&my_queue->available, &my_queue->mutex);
    }
    /* pull next request off my queue */
    req = my_queue->first;
    my_queue->first = req->next;
    pthread_mutex_unlock(&my_queue->mutex);
    
    /* handle request */
    write(req->fd, "hello, world!\n", sizeof("hello, world!\n"));
    snprintf(foo, 100, "I am thread %ld\n", pthread_self());
    write_all(req->fd, foo, strlen(foo));
    sleep(1);

    /* clean up */
    close(req->fd);
    free(req);
  }
}

/* write_all
 *
 * Write all the data passed, retrying and recovering from interrupts.
 * Return errno if an error occurred, -1 if write returns 0, or 0 on success.
 */
int write_all(int fd, const void *buf, size_t count)
{
  ssize_t n_written;

  while(count > 0) {
    n_written = write(fd, buf, count);
    if (n_written <= 0) {
      if (errno == EINTR) {
	n_written = 0;
      } else {
	return (n_written < 0) ? errno : -1;
      }
    }
    count -= n_written;
    buf += n_written;
  }

  return 0;
}

/* read_all
 *
 * Read the specified amount data passed, retrying and recovering from
 * interrupts.  Return errno if an error occurred, -1 if read returns 0,
 * or 0 on success.
 */
int read_all(int fd, void *buf, size_t count)
{
  ssize_t n_read;

  while(count > 0) {
    n_read = read(fd, buf, count);
    if (n_read <= 0) {
      if (errno == EINTR) {
	n_read = 0;
      } else {
	return (n_read < 0) ? errno : -1;
      }
    }
    count -= n_read;
    buf += n_read;
  }

  return 0;
}
