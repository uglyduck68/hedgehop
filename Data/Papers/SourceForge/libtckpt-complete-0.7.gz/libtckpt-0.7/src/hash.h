/*
 * hash.h
 *
 * interface to hash table functions
 *
 * History
 * -------
 * $Log: hash.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:25:03  dieter
 * verstion that worked for ftcs paper.
 *
 * Revision 1.2  1998/08/31  21:51:49  dieter
 * Added htable_lock and htable_unlock.
 *
 * Revision 1.1  1998/08/10  19:18:12  dieter
 * Initial revision
 *
 */

#ifndef HASH_H
#define HASH_H
/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct htable  htable_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

htable_t *new_htable(size_t size);
void  destroy_htable(htable_t *htable);

int   htable_add(htable_t *htable, long key, void *value);
int   htable_delete(htable_t *htable, long key);
int   htable_find(htable_t *htable, long key, void **value);

int   htable_entry_cnt(htable_t *htable );
int   htable_forall(htable_t *htable,
		    int (*func)(long key, void *value, void *arg), void *arg);

int   htable_lock(htable_t *htable);
int   htable_unlock(htable_t *htable);

#endif /* HASH_H */
