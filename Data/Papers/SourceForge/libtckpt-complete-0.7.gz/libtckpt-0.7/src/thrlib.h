/*
 * thrlib.h
 *
 * Function prototypes for functions that deal with the thread libraries.
 *
 * History
 * -------
 * $Log: thrlib.h,v $
 * Revision 6.1  2000/05/02 20:09:42  dieter
 * Released version 0.6.
 *
 * Revision 5.1  2000/02/01 23:38:13  dieter
 * Release 0.5 plus some fixes
 *
 * Revision 4.1  1999/08/02 15:11:45  dieter
 * Moving to version 4.1
 * This is essentially the version reported in FTCS-29.
 *
 * Revision 1.2  1999/08/02  14:41:31  dieter
 * Modified to not save the thread library state in the checkpoint.
 * This version does not work because the thread library is unaware of the
 * fact that the thread stacks of the restarted threads overlap with space
 * it has allocated.
 *
 * Revision 1.1  1999/07/07  21:24:24  dieter
 * Initial revision
 *
 */

#ifndef THRLIB_H
#define THRLIB_H

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

int exclude_thr_libs(void);
void exclude_thrlib_stacks(void);

#endif /* THRLIB_H */
