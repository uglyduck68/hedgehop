/*
 * display.c
 *
 * The gtk process to display the data.
 *
 * History
 * -------
 * $Log: display.c,v $
 * Revision 1.1  2000/10/20 20:17:23  dieter
 * Initial revision
 *
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <gtk/gtk.h>

#include "display.h"
#include "io.h"

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

#define kExitText		"Quit"

#define kDefaultBdWidth		4

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

typedef struct image_info {
  int width;
  int height;
  guchar *data;
} ImageInfo;

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

ImageInfo Image;

GtkWidget *CurrentWindow = NULL;
GtkWidget *DArea = NULL;

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

void InitImage(int width, int height);
void GraphicsInit(int *argc, char **argv[]);
void InitDisplayThread(int imageFD);

gint DeleteEvent(GtkWidget *widget, GdkEvent *event, gpointer data);
gboolean OnDAreaExpose(GtkWidget *widget, GdkEventExpose *event,
		       gpointer user_data);

void *ReadImageData(void *arg);

void RestoreGTKState(int num, void *arg);

/*****************************************************************************/
/*				Function Definitions			     */
/*****************************************************************************/

int display_main(int width, int height, int imageFD, int *argc, char **argv[])
{
  /* initialization */
  g_thread_init(NULL);

  InitImage(width, height);
  GraphicsInit(argc, argv);
  gtk_widget_show_all(CurrentWindow);

  /* create thread to read image data from a filedescriptor */
  InitDisplayThread(imageFD);
  
  /* read tiles and run gui */
  gdk_threads_enter();
  gtk_main();
  gdk_threads_leave();
  
  return 0;  
}

void InitImage(int width, int height)
{
  int row;
  int col;
  int rowBit;
  int colBit;
  guchar color;
  guchar *data;

  Image.width = width;
  Image.height = height;
  Image.data = (guchar *)malloc(sizeof(guchar) * width * height * 3);
  if (Image.data == NULL) {
    fprintf(stderr, "cannot allocate %d bytes for image display buffer\n",
	    sizeof(guchar) * Image.width * Image.height * 3);
    exit(-1);
  }
  
  /* initialize image with 4x4 checkerboard pattern */
  data = Image.data;
  for (row = 0 ; row < height ; row++) {
    for(col = 0 ; col < width ; col++) {
      rowBit = (row >> 2) & 0x01;
      colBit = (col >> 2) & 0x01;
      color = ((!rowBit && !colBit) || (rowBit && colBit)) ? 0xff : 0x00;
      data[3*col] = color;
      data[3*col+1] = color;
      data[3*col+2] = color;
    }
    data += 3 * width;
  }

}

void GraphicsInit(int *argc, char **argv[])
{
  GtkWidget *button;
  GtkWidget *vbox;
#ifdef CHECKPOINT
  chkpt_callback_t funcs;
  RecoveryData *recoveryData;

  if (!MBrotRecovering) {
    chkpt_block();
    recoveryData = (RecoveryData *)malloc(sizeof(RecoveryData));
    if(recoveryData == NULL) {
      fprintf(stderr, "cannot allocate recovery data\n");
      exit(-1);
    }
  }
#endif

  /* initialize GTK and GDK */
  gtk_init(argc, argv);
  gdk_rgb_init();
  gdk_rgb_set_min_colors(256);
  gtk_widget_set_default_colormap(gdk_rgb_get_cmap());
  gtk_widget_set_default_visual(gdk_rgb_get_visual());

  /* setup the main window */
  CurrentWindow = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(CurrentWindow), "simple image");
  gtk_signal_connect(GTK_OBJECT(CurrentWindow), "delete_event",
		     GTK_SIGNAL_FUNC(DeleteEvent), NULL);
  gtk_container_set_border_width(GTK_CONTAINER(CurrentWindow), 10);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(CurrentWindow), vbox);
  
  DArea = gtk_drawing_area_new();
  gtk_drawing_area_size (GTK_DRAWING_AREA (DArea), Image.width, Image.height);
  gtk_box_pack_start (GTK_BOX (vbox), DArea, TRUE, TRUE, 0);
  gtk_signal_connect (GTK_OBJECT (DArea), "expose_event",
		      GTK_SIGNAL_FUNC (OnDAreaExpose), NULL);

  button = gtk_button_new_with_label("quit");
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
		     GTK_SIGNAL_FUNC(DeleteEvent), NULL);
  gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);


#ifdef CHECKPOINT
  if (!MBrotRecovering) {
    funcs.pre_chkpt = NULL;
    funcs.post_chkpt = NULL;
    funcs.recovery = RestoreGTKState;
    chkpt_callback_push(&funcs, recoveryData);
    chkpt_unblock();
  }
#endif
}

/*****************************************************************************/
/*			Signal (Event) Handlers				     */
/*****************************************************************************/
gint DeleteEvent(GtkWidget *widget, GdkEvent *event, gpointer data) {
  gtk_main_quit();
  return FALSE;
}

gboolean OnDAreaExpose(GtkWidget *widget, GdkEventExpose *event,
		       gpointer user_data)
{
  long imageOffset;

  imageOffset = event->area.y * Image.width * 3 + event->area.x * 3;
  gdk_draw_rgb_image(widget->window, widget->style->fg_gc[GTK_STATE_NORMAL],
		     event->area.x, event->area.y,
		     event->area.width, event->area.height,
		     GDK_RGB_DITHER_MAX,
		     Image.data + imageOffset, Image.width * 3);

  return TRUE;
}

/*****************************************************************************/
/*			Display Thread 					     */
/*****************************************************************************/

void InitDisplayThread(int imageFD)
{
  int status;
  pthread_t tid;

  status = pthread_create(&tid, NULL, ReadImageData, (void *)imageFD);
  if (status != 0) {
    fprintf(stderr, "could not create image display thread: %s\n",
	    strerror(status));
    exit(-1);
  }
  pthread_detach(tid);
}

/* the block header format is (block x, block y, block width, block height),
   the size of the data to read is calculated from width and height)
*/
void *ReadImageData(void *arg)
{
  int imageFD = (int)arg;

  int blockX;
  int blockY;
  int blockWidth;
  int blockHeight;

  guchar *data;

  while(1) {
    read(imageFD, &blockX, sizeof(int));
    read(imageFD, &blockY, sizeof(int));
    read(imageFD, &blockWidth, sizeof(int));
    read(imageFD, &blockHeight, sizeof(int));

    printf("reading at (%d,%d) size %dx%d\n",
	   blockX, blockY, blockWidth, blockHeight);
    /* range checking */
    if ((blockX < 0)
	|| (blockX + blockWidth > Image.width)
	|| (blockY < 0)
	|| (blockY + blockHeight > Image.height)) {
      fprintf(stderr, "block does not fit in image\n");
      exit(-1);
    }
    /* read image data */
    data = Image.data + (blockY * Image.width + blockX) * 3;
    while(blockHeight > 0) {
      read_all(imageFD, data, blockWidth * 3);
      data += Image.width * 3;
      blockHeight--;
    }
    /* TODO: redraw image? */
    printf("drawing image\n");
    gdk_threads_enter();
    gdk_draw_rgb_image(DArea->window,
		       CurrentWindow->style->fg_gc[GTK_STATE_NORMAL],
		       blockX, blockY, blockWidth, blockHeight, 
		       GDK_RGB_DITHER_MAX,
		       Image.data + (blockY * Image.width + blockX) * 3,
		       Image.width * 3);
    gdk_threads_leave();
  }
  return NULL;
}


#ifdef CHECKPOINT
void RestoreGTKState(int num, void *arg)
{
  RecoveryData *recoveryData;

  recoveryData = (RecoveryData *)arg;
  MBrotRecovering = 1;
  GraphicsInit(&recoveryData->argc, &recoveryData->argv);
  /*  gtk_widget_show_all(CurrentWindow); */
  MBrotRecovering = 0;
}
#endif
