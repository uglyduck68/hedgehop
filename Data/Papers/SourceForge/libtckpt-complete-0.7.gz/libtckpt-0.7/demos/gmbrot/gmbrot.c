/* Copyright 1999, William R. Dieter, University of Kentucky */
/*
 * gmbrot.c
 *
 * I converted the original mbrot program to use GTK+ and renamed it to
 * gmbrot.  GTK+ deals with the colormap, visuals, etc for me, which
 * greatly simplifies the program.  gmbrot should work on more machines
 * and therefore supersedes mbrot.
 *
 * This program draws part of the Mandlebrot set in a window using
 * multiple threads.  It makes a good demo if you let it run until
 * it takes a checkpoint, then kill it and restart from the checkpoint.
 * The crowd can see that it restarts from part-way through rather than
 * from the beginning.  On my 125 MHz Sparc-20 a 7-10 second checkpointing
 * period is about right.  If your machine is too fast, you might need to
 * zoom in some place else in the set that takes longer to compute.  If
 * that does not work you can cheat and add a sleep to MandlebrotTile.
 * The program does work when compiled with optimization turned on, but
 * it finishes so fast that there is not time to take a checkpoint.
 *
 * When the window is covered then exposed the entire window is redrawn.
 * It would be better if only the exposed tiles were redrawn.
 *
 *
 * GTK needs to be reinitialized after recovering from a checkpoint.
 * However, GTK also uses mutexes, etc for synchronization.  That can
 * cause deadlocks during recovery.  To avoid this the GUI part is
 * a separate program that just draws tiles sent to it by the compute
 * engine.  Only the compute engine checkpoints.  When the compute
 * process recovers it will start a new display process to display
 * its output.  So the compute process will need to remember the
 * and resend them do the display process after recovery.
 *
 * History
 * -------
 * $Log: gmbrot.c,v $
 * Revision 1.3  2000/10/20 20:17:23  dieter
 * Switch from single multithreaded process to multithreaded process for
 * compute with separate display process.
 *
 * Revision 1.2  2000/09/28 16:37:15  dieter
 * Added recovery code.
 *
 * Revision 1.1  2000/02/11 19:35:36  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include <unistd.h>


#ifdef CHECKPOINT
#include "checkpoint.h"
#endif

#include "gtype.h"
#include "tile.h"
#include "display.h"
#include "io.h"

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

#define kTileWidth     32
#define kTileHeight    32

#define kHorizTiles    32
#define kVerticalTiles 24

#define kImageWidth    (kHorizTiles * kTileWidth)
#define kImageHeight   (kVerticalTiles * kTileHeight)

#define kNumWorkerThreads       2

#define kNumColors 128
#define kMidpoint  (kNumColors/2)

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

typedef struct Params_t {
  char *name;			/* parameter name */
  char *altName;		/* alternate parameter name */
  char **valueStr;		/* pointer to the parameter value */
} Params;

#if 0
typedef struct recovery_data_t {
  int argc;
  char **argv;
} RecoveryData;
#endif

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

CRegion WholeSetRegion = {
  {{-2.25, -1.8}, 3.0, 3.6}, kImageWidth, kImageHeight
};

CRegion DefaultRegion1 = {
  {{0.26, 0.0}, 0.01, 0.01}, kImageWidth, kImageHeight
};

CRegion DefaultRegion2 = {
  {{-0.76, 0.01}, 0.02, 0.02}, kImageWidth, kImageHeight
};

CRegion DefaultRegion3 = {
  {{-1.26, 0.01}, 0.02, 0.02}, kImageWidth, kImageHeight
};

CRegion DefaultRegion = {
  {{0.275, -0.0085}, 0.0025, 0.0025}, kImageWidth, kImageHeight
};

unsigned char *ImageData;

Tile ScreenTiles[kVerticalTiles][kHorizTiles];

TileList WorkList;
TileList DoneList;

/* List of command-line options */
Params Options[] = {
#if 0
  {"-display",   "-d", &GState.displayName},
  {"-geometry",  "-g", &GeomCline},
#endif
};
int NumOptions = sizeof(Options) / sizeof(Params);

char *AppName = NULL;
char *WindowTitle = "mbrot";

int DoneFlag = 0;
int ManagerDone;
pthread_mutex_t DoneMutex;
pthread_cond_t ManagerDoneCond;

int MBrotRecovering = 0;

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

void ParseCmdLine(int argc, char *argv[]);

int TileInit(void);
int InitScreenTiles(CRegion *region);

void Cleanup(void);
void Usage(void);

void StartThreads(int displayPipeFd);
void *ManagerThread(void *arg);
void SendTile(int displayPipeFd, Tile *tile);
int CheckForManagerExit(void);
void *WorkerThread(void *arg);

void MandelbrotTile(Tile *tile);

/*****************************************************************************/
/*				Function Definitions			     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  pid_t child;
  int status;
  int pipe_fd[2];

#ifdef CHECKPOINT
  checkpoint_init(&argc, argv, NULL);
#endif
  ParseCmdLine(argc, argv);

  if ( (status = pipe(pipe_fd)) < 0) {
    perror("cannot open pipe\n");
    exit(-1);
  }
  if ( (child = fork()) == 0) {
    close(pipe_fd[1]);
    display_main(kImageWidth, kImageHeight, pipe_fd[0], &argc, &argv);
  } else {
    close(pipe_fd[0]);
    
    TileInit();
    StartThreads(pipe_fd[1]);
    wait(&status);
    Cleanup();
    printf("child exitted with status %d\n", status);
    exit(1);
  }

  return 0;
}

void ParseCmdLine(int argc, char *argv[])
{
  int arg;
  int opt;

  AppName = argv[0];
  for(arg = 1 ; arg < argc ; arg += 2) {
    for(opt = 0 ; opt < NumOptions ; opt++) {
      if (strcmp(Options[opt].name, argv[arg]) == 0
	  || strcmp(Options[opt].altName, argv[arg]) == 0) {
	*Options[opt].valueStr = argv[arg+1];
	break;
      }
    }
    if (opt >= NumOptions)
      Usage();
  }
}


int TileInit(void)
{
  InitScreenTiles(&DefaultRegion);

  return 0;
}

int InitScreenTiles(CRegion *wholeRegion)
{
  int row;
  int col;
  char *data;
  CRegion region;
  double x;
  double y;
  Rect   bbox;
  double newSize;

  ImageData = (unsigned char *)malloc(sizeof(unsigned char)*kImageWidth*kImageHeight*3);
  if (ImageData == NULL) {
    fprintf(stderr, "cannot allocate %d bytes for image data buffer\n",
	    sizeof(unsigned char)*kImageWidth*kImageHeight*3);
    exit(-1);
  }

  /* preserve aspect ratio by enlarging whole region if it is not square */
  if(kImageWidth * wholeRegion->complexArea.height
     > kImageHeight * wholeRegion->complexArea.width) {
    /* image is too narrow; add to both sides to make it fit */
    newSize = (kImageWidth * wholeRegion->complexArea.height) / kImageHeight;
    wholeRegion->complexArea.corner.x -=
      (newSize - wholeRegion->complexArea.width) / 2;
    wholeRegion->complexArea.width = newSize;
  } else {
    /* image is not tall enough; add to top and bottom to make it fit */
    newSize = (kImageHeight * wholeRegion->complexArea.width) / kImageWidth;
    wholeRegion->complexArea.corner.y -=
      (newSize - wholeRegion->complexArea.height) / 2;
    wholeRegion->complexArea.width = newSize;
  }

  region.complexArea.width = wholeRegion->complexArea.width / kHorizTiles;
  region.complexArea.height = wholeRegion->complexArea.height /kVerticalTiles;
  region.xSteps = wholeRegion->xSteps / kHorizTiles;
  region.ySteps = wholeRegion->ySteps / kVerticalTiles;
  bbox.width = region.xSteps;
  bbox.height = region.ySteps;

  bbox.corner.y = 0;
  y = wholeRegion->complexArea.corner.y;
  for (row = 0 ; row < kVerticalTiles ; row++) {
    x = wholeRegion->complexArea.corner.x;
    bbox.corner.x = 0;
    region.complexArea.corner.y = y;
    for(col = 0 ; col < kHorizTiles ; col++) {
      region.complexArea.corner.x = x;
      data = ImageData + row * kTileHeight * kImageWidth * 3
	+ col * kTileWidth * 3;
      InitTile(&ScreenTiles[row][col], &region, &bbox, data, kImageWidth * 3);
      x += region.complexArea.width;
      bbox.corner.x += bbox.width;
    }
    y += region.complexArea.height;
    bbox.corner.y += bbox.height;
  }
      
  return 0;
}



void StartThreads(int displayPipeFd)
{
  int status;
  int thr;
  pthread_t tid;
  pthread_attr_t attr;

  InitTileList(&WorkList);
  InitTileList(&DoneList);

  pthread_attr_init(&attr);
  pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
  
  status = pthread_create(&tid, &attr, ManagerThread, (void *)displayPipeFd);
  if(status < 0) {
    fprintf(stderr, "Error creating thread: %s\n", strerror(status));
    exit(-1);
  }
  pthread_detach(tid);

  for(thr = 0 ; thr < kNumWorkerThreads ; thr++ ) {
    status = pthread_create(&tid, &attr, WorkerThread, NULL);
    if(status < 0) {
      fprintf(stderr, "Error creating thread: %s\n", strerror(status));
      exit(-1);
    }
    pthread_detach(tid);
  }
  pthread_attr_destroy(&attr);
}

void *ManagerThread(void *arg)
{
  int row;
  int col;
  int tileCnt;
  Tile *tile;
  int done;
  int displayPipeFd = (int)arg;

  done = 0;
  if(!done) {
    /* this sleep is just for effect, so that the empty window comes up
     * first and you get to see the tiles drawn.  If you just want
     * maximum speed omit the sleep
     */
    sleep(5);
    for(row = 0 ; row < kVerticalTiles ; row++) {
      for(col = 0 ; col < kHorizTiles ; col++) {
	PutTile(&WorkList, &ScreenTiles[row][col]);
      }
    }
    
    tileCnt = kVerticalTiles * kHorizTiles;
    while(tileCnt > 0) {
      GetTile(&DoneList, &tile);
      SendTile(displayPipeFd, tile);
      tileCnt--;
      tileCnt -= CheckForManagerExit();
    }

    pthread_mutex_lock(&DoneMutex);
    if (DoneFlag) {
      done = 1;
    }
    pthread_mutex_unlock(&DoneMutex);
  }

  pthread_mutex_lock(&DoneMutex);
  ManagerDone = 1;
  pthread_mutex_unlock(&DoneMutex);
  pthread_cond_signal(&ManagerDoneCond);

  return NULL;
}

void SendTile(int displayPipeFd, Tile *tile)
{
  int row;
  char *data;

  write_all(displayPipeFd, &tile->bbox.corner.x, sizeof(int));
  write_all(displayPipeFd, &tile->bbox.corner.y, sizeof(int));
  write_all(displayPipeFd, &tile->bbox.width, sizeof(int));
  write_all(displayPipeFd, &tile->bbox.height, sizeof(int));
  data = tile->data;
  for(row = 0 ; row < tile->bbox.height ; row++) {
    write_all(displayPipeFd, data, tile->bbox.width * 3);
    data += tile->bytes_per_row;
  }
}

int CheckForManagerExit(void)
{
  int numTiles = 0;

  pthread_mutex_lock(&DoneMutex);
  if(DoneFlag) {
    numTiles = ClearTileList(&WorkList);
  }
  pthread_mutex_unlock(&DoneMutex);

  return numTiles;
}

void *WorkerThread(void *arg)
{
  Tile *tile;

  while(1) {
    GetTile(&WorkList, &tile);
    MandelbrotTile(tile);
    PutTile(&DoneList, tile);
  }
  
  return NULL;
}

void MandelbrotTile(Tile *tile)
{
  int numIterations;
  double x, y;
  double xSqr, ySqr;
  double a, b;
  double aIncr, bIncr;
  char *result;
  int row, col;
  struct timespec delay;
  
  aIncr = tile->region.complexArea.width / tile->bbox.width;
  bIncr = tile->region.complexArea.height / tile->bbox.height;
  result = tile->data;

  b = tile->region.complexArea.corner.y;
  for(row = 0 ; row < tile->bbox.height ; row++) {
    a = tile->region.complexArea.corner.x;
    for(col = 0 ; col < tile->bbox.width ; col++) {
      x = 0;
      y = 0;
      xSqr = 0;
      ySqr = 0;
      numIterations = 0;
      while((numIterations < kNumColors) && (xSqr + ySqr < 10000)) {
	y = 2 * x * y + b;
	x = xSqr - ySqr + a;
	xSqr = x * x;
	ySqr = y * y;
	numIterations++;
      }
      if (numIterations >= kNumColors) {
	*result++ = 0;
      } else {
	*result++ = (unsigned char)(256 * sqrt(((double)numIterations) / kNumColors));
      }
      *result++ = 0;
      *result++ = 0;
      a += aIncr;
    }
    result += tile->bytes_per_row - tile->bbox.width * 3;
    b += bIncr;
  }

  delay.tv_sec = 0;
  delay.tv_nsec = 10000000;
  /*  nanosleep(&delay, NULL); */
}

void Cleanup(void)
{
  /* wait for manager thread to finish.  When manager is finished no threads
   * are drawing into tiles
   */
  pthread_mutex_lock(&DoneMutex);
  DoneFlag = 1;
  while(!ManagerDone)
    pthread_cond_wait(&ManagerDoneCond, &DoneMutex);
  pthread_mutex_unlock(&DoneMutex);
}


void Usage(void)
{
  fprintf(stderr, "usage: %s [ -display host:display ] [ -geometry geom ]\n",
	  AppName);
  exit(1);
}
