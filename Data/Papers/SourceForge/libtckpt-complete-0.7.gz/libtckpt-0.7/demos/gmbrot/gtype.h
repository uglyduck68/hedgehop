/*
 * gtype.h
 *
 * graphical types
 *
 * History
 * -------
 * $Log: gtype.h,v $
 * Revision 1.1  2000/02/11 19:35:36  dieter
 * Initial revision
 *
 * Revision 1.1  1999/03/15 17:17:53  dieter
 * Initial revision
 *
 * Revision 1.1  1999/02/19  15:55:59  dieter
 * Initial revision
 *
 */

#ifndef GTYPE_H
#define GTYPE_H

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

typedef struct point_t {
  int x;
  int y;
} Point;

typedef struct rect_t {
  Point corner;
  unsigned int width;
  unsigned int height;
} Rect;

typedef struct dpoint_t {
  double x;
  double y;
} DPoint;

typedef struct drect_t {
  DPoint corner;
  double width;
  double height;
} DRect;

/* a region on the complex plane */
typedef struct cregion_t {
  DRect complexArea;
  int xSteps;
  int ySteps;
} CRegion;

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

#define SetRect(rect, xcorn, ycorn, w, h)  \
{ \
  (rect)->corner.x = (xcorn); \
  (rect)->corner.y = (ycorn); \
  (rect)->width    = (w); \
  (rect)->height   = (h); \
}

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

#endif /* GTYPE_H */
