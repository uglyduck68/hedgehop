/*
 * io.c
 *
 * I/O functions that do not give up just because no data is available.
 *
 * History
 * -------
 * $Log: io.c,v $
 * Revision 1.1  2000/10/20 20:17:23  dieter
 * Initial revision
 *
 */

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "io.h"

ssize_t read_all(int fd, void *buf, size_t count)
{
  ssize_t n_read;

  while(count > 0) {
    n_read = read(fd, buf, count);
    if (n_read <= 0) {
      if (errno == EINTR) {
	n_read = 0;
      } else {
	if (n_read < 0) {
	  fprintf(stderr, "read from pipe failed: %s\n", strerror(errno));
	} else {
	  fprintf(stderr, "no data read from pipe: other end closed?\n");
	}
	exit(-1);
      }
    }
    count -= n_read;
    buf += n_read;
  }

  return 0;
}

ssize_t write_all(int fd, const void *buf, size_t count)
{
  ssize_t n_written;

  while(count > 0) {
    n_written = write(fd, buf, count);
    if (n_written <= 0) {
      if (errno == EINTR) {
	n_written = 0;
      } else {
	if (n_written < 0) {
	  fprintf(stderr, "write to pipe failed: %s\n", strerror(errno));
	} else {
	  fprintf(stderr, "no data written from pipe: other end closed?\n");
	}
	exit(-1);
      }
    }
    count -= n_written;
    buf += n_written;
  }

  return 0;
}
