/*
 *
 * History
 * -------
 * $Log: tile.c,v $
 * Revision 1.2  2000/10/20 20:17:23  dieter
 * Switch from single multithreaded process to multithreaded process for
 * compute with separate display process.
 *
 * Revision 1.1  2000/02/11 19:35:36  dieter
 * Initial revision
 *
 * Revision 1.1  1999/03/15  17:17:53  dieter
 * Initial revision
 *
 * Revision 1.4  1999/02/20  18:38:09  dieter
 * Allocate colors for a nicer display
 * Adjust aspect ratio.
 *
 * Revision 1.3  1999/02/19  22:23:32  dieter
 * Can draw mandlebrot set now.
 *
 * Revision 1.2  1999/02/19  20:30:21  dieter
 * Can redraw screen tiles.
 *
 * Revision 1.1  1999/02/19  15:47:09  dieter
 * Initial revision
 *
 */

#include <assert.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>

#include "gtype.h"
#include "tile.h"

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

#define kTileWidth     16
#define kTileHeight    16

#define kHorizTiles    32
#define kVerticalTiles 32

#define kImageWidth    (kHorizTiles * kTileWidth)
#define kImageHeight   (kVerticalTiles * kTileHeight)

#define ASSERT(x)      assert(x)

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Definitions			     */
/*****************************************************************************/

int InitTileList(TileList *list)
{
  list->head = NULL;
  list->len = 0;
  pthread_mutex_init(&list->mutex, NULL);
  pthread_cond_init(&list->cond, NULL);

  return 0;
}

/* remove everything from the list without freeing anything */
int ClearTileList(TileList *list)
{
  int len;

  pthread_mutex_lock(&list->mutex);
  list->head = NULL;
  len = list->len;
  list->len = 0;
  pthread_mutex_unlock(&list->mutex);

  ASSERT(len >= 0);
  
  return len;
}

int NewTile(CRegion *region, Rect *bbox, Tile **tile)
{
  char *data;

  *tile = (Tile *)malloc(sizeof(Tile));
  if (tile == NULL) {
    return -errno;
  }

  data = malloc(sizeof(char) * region->xSteps * region->ySteps);
  if (data == NULL) {
    free(*tile);
    return -errno;
  }
  
  InitTile(*tile, region, bbox, data, region->xSteps);

  return 0;
}

/* GState must be initialized before calling this function */
int InitTile(Tile *tile, CRegion *region, Rect *bbox, unsigned char *data,
	     int bytes_per_row)
{
  tile->region = *region;
  tile->bbox = *bbox;
  tile->data = data;
  tile->bytes_per_row = bytes_per_row;
  tile->next = NULL;

  return 0;
}

int PutTile(TileList *list, Tile *tile)
{
  pthread_mutex_lock(&list->mutex);
  tile->next = list->head;
  list->head = tile;
  if(list->len == 0)
    pthread_cond_signal(&list->cond);
  list->len++;
  pthread_mutex_unlock(&list->mutex);

  return 0;
}

int GetTile(TileList *list, Tile **tile)
{
  pthread_mutex_lock(&list->mutex);
  while(list->len == 0)
    pthread_cond_wait(&list->cond, &list->mutex);
  ASSERT(list->head != NULL);
  *tile = list->head;
  list->head = list->head->next;
  list->len--;
  if(list->len > 0)
    pthread_cond_signal(&list->cond);
  pthread_mutex_unlock(&list->mutex);

  return 0;
}
