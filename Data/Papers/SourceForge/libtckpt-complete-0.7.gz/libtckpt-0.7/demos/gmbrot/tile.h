/*
 * tile.h
 *
 * Interface to tile routines
 *
 * History
 * -------
 * $Log: tile.h,v $
 * Revision 1.2  2000/10/20 20:17:23  dieter
 * Switch from single multithreaded process to multithreaded process for
 * compute with separate display process.
 *
 * Revision 1.1  2000/02/11 19:35:36  dieter
 * Initial revision
 *
 * Revision 1.1  1999/03/15  17:17:53  dieter
 * Initial revision
 *
 * Revision 1.2  1999/02/19  20:30:21  dieter
 * Can redraw screen tiles.
 *
 * Revision 1.1  1999/02/19  15:55:59  dieter
 * Initial revision
 *
 */

#ifndef TILE_H
#define TILE_H

#include <pthread.h>

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

typedef struct tile_t {
  CRegion        region;
  Rect           bbox;
  char          *data;
  int            bytes_per_row;
  struct tile_t *next;
} Tile;

typedef struct tile_list_t {
  Tile *head;			   /* head of the list */
  int   len;			   /* length of the list */
  pthread_mutex_t mutex;	   /* mutex locking head and len */
  pthread_cond_t  cond;		   /* cond signalled when len non-zero */
} TileList;

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

int InitTileList(TileList *list);
int ClearTileList(TileList *list);

int NewTile(CRegion *region, Rect *bbox, Tile **tile);
int InitTile(Tile *tile, CRegion *region, Rect *bbox, unsigned char *data,
	     int bytes_per_row);
/* void DrawTile(GtkWidget *window, GtkWidget *darea, Tile *tile); */

int PutTile(TileList *list, Tile *tile);
int GetTile(TileList *list, Tile **tile);

#endif /* TILE_H */
