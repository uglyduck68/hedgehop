/*
 * display.h
 *
 * History
 * -------
 * $Log: display.h,v $
 * Revision 1.1  2000/10/20 20:17:23  dieter
 * Initial revision
 *
 */

#ifndef DISPLAY_H
#define DISPLAY_H

int display_main(int width, int height, int imageFD, int *argc, char **argv[]);

#endif
