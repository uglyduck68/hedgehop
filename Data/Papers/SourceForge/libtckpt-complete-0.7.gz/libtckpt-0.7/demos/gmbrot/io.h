/*
 * io.h
 *
 * History
 * -------
 * $Log: io.h,v $
 * Revision 1.1  2000/10/20 20:17:23  dieter
 * Initial revision
 *
 */

#ifndef IO_H
#define IO_H

ssize_t read_all(int fd, void *buf, size_t count);
ssize_t write_all(int fd, const void *buf, size_t count);

#endif
