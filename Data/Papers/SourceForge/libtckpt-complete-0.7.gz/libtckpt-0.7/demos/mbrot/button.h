/*
 * button.h
 *
 * History
 * -------
 * $Log: button.h,v $
 * Revision 1.1  1999/03/15 17:17:53  dieter
 * Initial revision
 *
 * Revision 1.1  1999/02/19  15:55:59  dieter
 * Initial revision
 *
 */

#ifndef BUTTON_H
#define BUTTON_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

typedef struct text_button_t {
  Rect           bbox;
  int            borderWidth;
  Window         winId;
  GC      	 context;
  Window         parentId;
  char		*text;
  int            textLen;
  Rect           textBbox;
#if 0				/* use values from GState */
  char          *bgColorName;
  unsigned long  bgPixel;
  char          *fgColorName;
  unsigned long  fgPixel;
  char          *fontName;
  XFontStruct   *fontStruct;
#endif
} TextButton;

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

int AddTextButton(TextButton *button, AppWindow *window,
		  int xCorner, int yCorner, int bdWidth, char *text);
void DrawTextButton(TextButton *button);

#endif /* BUTTON_H */
