/*
 * button.c
 *
 * Routines to make a button with a text string in it.
 *
 * History
 * -------
 * $Log: button.c,v $
 * Revision 1.1  1999/03/15 17:17:53  dieter
 * Initial revision
 *
 * Revision 1.1  1999/02/19  15:47:09  dieter
 * Initial revision
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>

#include "gtype.h"
#include "button.h"

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Definitions			     */
/*****************************************************************************/


int AddTextButton(TextButton *button, AppWindow *window,
		  int xCorner, int yCorner, int bdWidth, char *text)
{
  int x, y;
  int width, height;
  XGCValues  gcValues;

  button->text = text;
  button->textLen = strlen(text);
  button->borderWidth = bdWidth;
  button->parentId = window->winId;

  x = GState.font->max_bounds.width / 2;
  y = GState.font->max_bounds.ascent + GState.font->max_bounds.descent;
  width = XTextWidth(GState.font, button->text, button->textLen);
  height = GState.font->max_bounds.ascent + GState.font->max_bounds.descent;
  SetRect(&button->textBbox, x, y, width, height);

  SetRect(&button->bbox, xCorner, yCorner, x + width + x, y + 4);

  x = button->bbox.corner.x;
  y = button->bbox.corner.y;
  width = button->bbox.width;
  height = button->bbox.height;
  button->winId = XCreateSimpleWindow(GState.display, window->winId,
				      x, y, width, height, button->borderWidth,
				      GState.fgPixel, GState.bgPixel);
  XSelectInput(GState.display, button->winId, ExposureMask | ButtonPressMask);
  XMapWindow(GState.display, button->winId);

  gcValues.font = GState.font->fid;
  gcValues.foreground = GState.fgPixel;
  gcValues.background = GState.bgPixel;
  button->context = XCreateGC(GState.display, button->winId,
			      (GCFont | GCForeground | GCBackground),
			      &gcValues);

  return 0;
}

void DrawTextButton(TextButton *button) 
{
  XClearWindow(GState.display, button->winId);
  XDrawString(GState.display, button->winId, button->context,
	      button->textBbox.corner.x,
	      button->textBbox.corner.y,
	      button->text, button->textLen);
}

