/* Copyright 1999, William R. Dieter, University of Kentucky */
/*
 * mbrot.c
 *
 * This program draws part of the Mandlebrot set in a window using
 * multiple threads.  It makes a good demo if you let it run until
 * it takes a checkpoint, then kill it and restart from the checkpoint.
 * The crowd can see that it restarts from part-way through rather than
 * from the beginning.  On my 125 MHz Sparc-20 a 7-10 second checkpointing
 * period is about right.  If your machine is too fast, you might need to
 * zoom in some place else in the set that takes longer to compute.  If
 * that does not work you can cheat and add a sleep to MandlebrotTile.
 * The program does work when compiled with optimization turned on, but
 * it finishes so fast that there is not time to take a checkpoint.
 *
 * This is the first X program I have written.  I did not have an example
 * to follow and the man pages were not all that clear to me.  Apparently
 * generating images is a really weird thing to do because there were no
 * examples of how to do it in the X book I found.  No doubt I have broken
 * some rules of X programming to make mbrot work.
 *
 * When the window is covered then exposed the entire window is redrawn.
 * It would be better if only the exposed tiles were redrawn.
 *
 * There are several bugs that I have not fixed because they are intermittent
 * and I have no idea what causes them.  Some times some of the last tiles are
 * not drawn.  This problem seems worse with -O2.  I know the tiles are being
 * computed because if you force the window to redraw by putting another
 * window in front of it they are redrawn correctly.
 *
 * Occasionally the program will crash with an X error.  The offending
 * X operation is often some operation that I never try to use, so I
 * expect this is some sort of memory corruption problem.
 *
 * History
 * -------
 * $Log: mbrot.c,v $
 * Revision 1.3  2000/10/20 20:07:59  dieter
 * Added new options parameter to checkpoint_init.
 *
 * Title passed to XSetWMProperties should be a pointer to an XTextProperty,
 * not an XTextProperty.
 *
 * Revision 1.2  1999/03/15  17:50:57  dieter
 * Added big comment in the header
 *
 * Revision 1.1  1999/03/15  17:17:53  dieter
 * Initial revision
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>

#ifdef CHECKPOINT
#include "checkpoint.h"
#endif

#include "gtype.h"
#include "tile.h"
#include "button.h"

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

#define kTileWidth     16
#define kTileHeight    16

#define kHorizTiles    48
#define kVerticalTiles 36

#define kImageWidth    (kHorizTiles * kTileWidth)
#define kImageHeight   (kVerticalTiles * kTileHeight)

#define kExitText		"Exit"

#define kDefaultBgColor		"white"
#define kDefaultFgColor		"black"
#define kDefaultBdWidth		1
#define kDefaultFont		"fixed"

#define kRsrcBase		"mbrot"
#define kRsrcAltBase		"MBrot"

#define kNumWorkerThreads       8

#define ClassOfVisual(v)  	((v)->class)

#define kNumColors 128
#define kMidpoint  (kNumColors/2)

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

typedef struct Params_t {
  char *name;			/* parameter name */
  char *altName;		/* alternate parameter name */
  char **valueStr;		/* pointer to the parameter value */
} Params;

typedef struct recovery_data_t {
  int argc;
  char **argv;
} RecoveryData;

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

CRegion WholeSetRegion = {
  {{-2.25, -1.8}, 3.0, 3.6}, kImageWidth, kImageHeight
};

CRegion DefaultRegion1 = {
  {{0.26, 0.0}, 0.01, 0.01}, kImageWidth, kImageHeight
};

CRegion DefaultRegion2 = {
  {{-0.76, 0.01}, 0.02, 0.02}, kImageWidth, kImageHeight
};

CRegion DefaultRegion3 = {
  {{-1.26, 0.01}, 0.02, 0.02}, kImageWidth, kImageHeight
};

CRegion DefaultRegion = {
  {{0.275, -0.0085}, 0.0025, 0.0025}, kImageWidth, kImageHeight
};

Tile ScreenTiles[kVerticalTiles][kHorizTiles];

TileList WorkList;
TileList DoneList;

/* options */
char *GeomRsrc     = NULL;
char *GeomCline    = NULL;


/* graphical elements */
TextButton ExitButton;
AppWindow  MainWindow;

GraphicsState GState = {
  NULL,				/* display name */
  NULL,				/* display */
  kDefaultBgColor,		/* bgColorName */
  0,				/* bgPixel */
  kDefaultFgColor,		/* fgColorName */
  1,				/* fgPixel */
  kDefaultFont,			/* fontName */
  NULL,				/* font */
  NULL,				/* sizeHints */
  NULL,				/* geometry */
  NULL				/* classHint */
};

char DefaultGeometry[80];

Params Resources[] = {
  {kRsrcBase".background", kRsrcAltBase".Background", &GState.bgColorName},
  {kRsrcBase".foreground", kRsrcAltBase".Foreground", &GState.fgColorName},
  {kRsrcBase".font",	   kRsrcAltBase".Font",	      &GState.fontName},
  {kRsrcBase".geometry",   kRsrcAltBase".Geometry",   &GeomRsrc},
};
int NumResources = sizeof(Resources) / sizeof(Params);

/* List of command-line options */
Params Options[] = {
  {"-display",   "-d", &GState.displayName},
  {"-geometry",  "-g", &GeomCline},
};
int NumOptions = sizeof(Options) / sizeof(Params);

char *AppName = NULL;
char *WindowTitle = "mbrot";

unsigned long ImageLut[kNumColors];


int DoneFlag;
int ManagerDone;
pthread_mutex_t DoneMutex;
pthread_cond_t ManagerDoneCond;

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

void ParseCmdLine(int argc, char *argv[]);

int TileInit(void);
int InitScreenTiles(CRegion *region);

void GraphicsInit(int argc, char *argv[]);

void GetResources(void);
void InitFonts(void);
void InitColors(void);
void InitWindowPosition(void);

void WindowInit(AppWindow *window, int argc, char *argv[]);
void SetProperties(AppWindow *window, int argc, char *argv[]);
void InitContext(AppWindow *window);
void SetWindowAttr(AppWindow *window);

void EventLoop(void);
void HandleExitEvent(XEvent *theEvent, int *done);
void DrawMainWindow(XExposeEvent *event, int *done);
void HandleMainEvent(XEvent *theEvent, int *done);

void Cleanup(void);
void Usage(void);

void StartThreads(void);
void *ManagerThread(void *arg);
int CheckForManagerExit(void);
void *WorkerThread(void *arg);

void MandelbrotTile(Tile *tile);

void RestoreXState(int num, void *arg);

/*****************************************************************************/
/*				Function Definitions			     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
#ifdef CHECKPOINT
  checkpoint_init(&argc, argv, NULL);
#endif

  ParseCmdLine(argc, argv);
  GraphicsInit(argc, argv);
  StartThreads();
  EventLoop();
  Cleanup();

  return 0;
}

void ParseCmdLine(int argc, char *argv[])
{
  int arg;
  int opt;

  AppName = argv[0];
  for(arg = 1 ; arg < argc ; arg += 2) {
    for(opt = 0 ; opt < NumOptions ; opt++) {
      if (strcmp(Options[opt].name, argv[arg]) == 0
	  || strcmp(Options[opt].altName, argv[arg]) == 0) {
	*Options[opt].valueStr = argv[arg+1];
	break;
      }
    }
    if (opt >= NumOptions)
      Usage();
  }
}


int TileInit(void)
{
  InitScreenTiles(&DefaultRegion);

  return 0;
}

int InitScreenTiles(CRegion *wholeRegion)
{
  int row;
  int col;
  char *data;
  CRegion region;
  double x;
  double y;
  Rect   bbox;
  double newSize;

  /* preserve aspect ratio by enlarging whole region if it is not square */
  if(kImageWidth * wholeRegion->complexArea.height
     > kImageHeight * wholeRegion->complexArea.width) {
    /* image is too narrow; add to both sides to make it fit */
    newSize = (kImageWidth * wholeRegion->complexArea.height) / kImageHeight;
    wholeRegion->complexArea.corner.x -=
      (newSize - wholeRegion->complexArea.width) / 2;
    wholeRegion->complexArea.width = newSize;
  } else {
    /* image is not tall enough; add to top and bottom to make it fit */
    newSize = (kImageHeight * wholeRegion->complexArea.width) / kImageWidth;
    wholeRegion->complexArea.corner.y -=
      (newSize - wholeRegion->complexArea.height) / 2;
    wholeRegion->complexArea.width = newSize;
  }

  region.complexArea.width = wholeRegion->complexArea.width / kHorizTiles;
  region.complexArea.height = wholeRegion->complexArea.height /kVerticalTiles;
  region.xSteps = wholeRegion->xSteps / kHorizTiles;
  region.ySteps = wholeRegion->ySteps / kVerticalTiles;
  bbox.width = region.xSteps;
  bbox.height = region.ySteps;

  bbox.corner.y = ExitButton.bbox.height + 2 * ExitButton.borderWidth + 2;
  y = wholeRegion->complexArea.corner.y;
  for (row = 0 ; row < kVerticalTiles ; row++) {
    x = wholeRegion->complexArea.corner.x;
    bbox.corner.x = 0;
    region.complexArea.corner.y = y;
    for(col = 0 ; col < kHorizTiles ; col++) {
      region.complexArea.corner.x = x;
      data = (char *)malloc(sizeof(char) * kTileWidth * kTileHeight);
      if (data == NULL) {
	fprintf(stderr, "malloc faile for tile data\n");
	exit(-1);
      }
      InitTile(&ScreenTiles[row][col], &region, &bbox, data, region.xSteps);
      x += region.complexArea.width;
      bbox.corner.x += bbox.width;
    }
    y += region.complexArea.height;
    bbox.corner.y += bbox.height;
  }
      
  return 0;
}

void DestroyScreenTiles(void)
{
  int row;
  int col;

  for (row = 0 ; row < kVerticalTiles ; row++) {
    for(col = 0 ; col < kHorizTiles ; col++) {
      XDestroyImage(ScreenTiles[row][col].xImage);
    }
  }
}

void DrawScreenTiles(void)
{
  int itemp;
  unsigned int width, height;
  unsigned int utemp;
  Window wtemp;
  int row;
  int col;

  /* Determine the current size of the main window */
  if (XGetGeometry(GState.display, MainWindow.winId, &wtemp, &itemp, &itemp,
		   &width, &height, &utemp, &utemp) == 0) {
    return;
  }

  for (row = 0 ; row < kVerticalTiles ; row ++) {
    for (col = 0 ; col < kHorizTiles ; col++) {
      DrawTile(&MainWindow, &ScreenTiles[row][col]);
    }
  }
}

void GraphicsInit(int argc, char *argv[])
{
#ifdef CHECKPOINT
  chkpt_callback_t funcs;
  RecoveryData *recoveryData;

  chkpt_block();
  recoveryData = (RecoveryData *)malloc(sizeof(RecoveryData));
  if(recoveryData == NULL) {
    fprintf(stderr, "cannot allocate recovery data\n");
    exit(-1);
  }
#endif
  if ((GState.display = XOpenDisplay(GState.displayName)) == NULL) {
    fprintf(stderr, "%s: cannot open display named %s\n",
	    AppName, XDisplayName(GState.displayName));
    exit(1);
  }
  GetResources();
  InitFonts();
  InitColors();
  InitWindowPosition();
  WindowInit(&MainWindow, argc, argv);
#ifdef CHECKPOINT
  funcs.pre_chkpt = NULL;
  funcs.post_chkpt = NULL;
  funcs.recovery = RestoreXState;
  chkpt_callback_push(&funcs, recoveryData);
  chkpt_unblock();
#endif

  TileInit();
}

/* Get resources from the resource file */
void GetResources(void)
{
  char  rsrcFilename[PATH_MAX];
  XrmDatabase rsrcDb;
  XrmValue    value;
  char	     *type;
  int         rsrc;

  XrmInitialize();
  strcpy(rsrcFilename, getenv("HOME"));
  strcat(rsrcFilename, "/.Xdefaults");
  rsrcDb = XrmGetFileDatabase(rsrcFilename);
  if (rsrcDb != NULL) {
    for (rsrc = 0 ; rsrc < NumResources ; rsrc++) {
      if (XrmGetResource(rsrcDb, Resources[rsrc].name,
			 Resources[rsrc].altName, &type, &value)) {
	*Resources[rsrc].valueStr = value.addr;
      }
    }
  }
}

void InitFonts(void)
{
  if ((GState.font = XLoadQueryFont(GState.display, GState.fontName)) == NULL){
    fprintf(stderr, "%s: display %s cannot load font %s\n",
	    AppName, DisplayString(GState.display), GState.fontName);
    exit(1);
  }
}

/* select colors using the default colormap */
void InitColors(void)
{
  Colormap  defColormap;
  XColor    color;
  Visual   *visual;
  int       status;
  int       colorIndex;

  defColormap = DefaultColormap(GState.display, DefaultScreen(GState.display));

  /* Use white bacground in case of failure */
  if (XParseColor(GState.display, defColormap, GState.bgColorName, &color) == 0
      || XAllocColor(GState.display, defColormap, &color) == 0)
    GState.bgPixel = WhitePixel(GState.display, DefaultScreen(GState.display));
  else
    GState.bgPixel = color.pixel;

  /* Use black foreground in case of failure */
  if (XParseColor(GState.display, defColormap, GState.fgColorName, &color) == 0
      || XAllocColor(GState.display, defColormap, &color) == 0)
    GState.fgPixel = BlackPixel(GState.display, DefaultScreen(GState.display));
  else
    GState.fgPixel = color.pixel;

  visual = DefaultVisual(GState.display, DefaultScreen(GState.display));
  if(!(ClassOfVisual(visual) == DirectColor
       || ClassOfVisual(visual) == PseudoColor
       || ClassOfVisual(visual) == GrayScale)) {
    fprintf(stderr, "This display does not support colormap modifications\n");
    fprintf(stderr, "Some colors may look strange\n");
    return;
  }
  status = XAllocColorCells(GState.display, defColormap, False,
			    NULL, 0, ImageLut, kNumColors );
  if(status == 0) {
    fprintf(stderr, "cannot allocate color cells\n");
    exit(-1);
  }

  /* ramp from black to 50% gray */
  for(colorIndex = 0 ; colorIndex < kMidpoint ; colorIndex++) {
    color.pixel = ImageLut[colorIndex];
    color.red = colorIndex * 65535 / kMidpoint;
    color.green = colorIndex * 65535 / kMidpoint;
    color.blue = colorIndex * 65535 / kMidpoint;
    color.flags = DoRed | DoGreen | DoBlue;
    XStoreColor(GState.display, defColormap, &color);
  }
  /* ramp from 50% gray to (almost) 100% red */
  for( ; colorIndex < kNumColors-1 ; colorIndex++) {
    color.pixel = ImageLut[colorIndex];
    color.red = 65535;
    color.green = (kNumColors - colorIndex) * 65535 / (kNumColors - kMidpoint);
    color.blue = (kNumColors - colorIndex) * 65535 / (kNumColors - kMidpoint);
    color.flags = DoRed | DoGreen | DoBlue;
    XStoreColor(GState.display, defColormap, &color);
  }

  /* last color is black */
  color.pixel = ImageLut[colorIndex];
  color.red = 0;
  color.green = 0;
  color.blue = 0;
  color.flags = DoRed | DoGreen | DoBlue;
  XStoreColor(GState.display, defColormap, &color);
}

/* Select initial position and size of top window.  Allocate and fill out
 * and XSizeHints structure to inform the window manager.  Here we pick a
 * default size large enough to fit the text and the Exit button.
 */
void InitWindowPosition(void)
{
  int  bitmask;

  if((GState.sizeHints = XAllocSizeHints()) == NULL) {
    fprintf(stderr, "Error allocating size hints!\n");
    exit(1);
  }

  GState.sizeHints->flags = (PSize | PMinSize | PMaxSize);
  GState.sizeHints->height = kImageHeight;
  GState.sizeHints->min_height = 50;
  GState.sizeHints->max_height = kImageHeight;

  GState.sizeHints->width = kImageWidth;
  GState.sizeHints->min_width = 50;
  GState.sizeHints->max_width = kImageWidth;

  GState.sizeHints->x = (DisplayWidth(GState.display,
				      DefaultScreen(GState.display))
			 - GState.sizeHints->width) / 2;
  GState.sizeHints->y = (DisplayHeight(GState.display,
				       DefaultScreen(GState.display))
			 - GState.sizeHints->height) / 2;

  /* Construct a default geometry string */
  sprintf(DefaultGeometry, "%dx%d+%d+%d",
	  GState.sizeHints->width, GState.sizeHints->height,
	  GState.sizeHints->x, GState.sizeHints->y);
  GState.geometry = DefaultGeometry;

  /* Override the geometry if necessary */
  if (GeomCline != NULL)
    GState.geometry = GeomCline;
  else if (GeomRsrc != NULL)
    GState.geometry = GeomRsrc;

  /* Process the geometry specification */
  bitmask = XGeometry(GState.display, DefaultScreen(GState.display),
		      GState.geometry, DefaultGeometry, kDefaultBdWidth,
		      GState.font->max_bounds.width,
		      GState.font->max_bounds.ascent
		      + GState.font->max_bounds.descent,
		      1, 1, &(GState.sizeHints->x), &(GState.sizeHints->y),
		      &(GState.sizeHints->width), &(GState.sizeHints->height));

  /* Check bitmask and set flags in XGState.sizeHints structure */
  if (bitmask & (XValue | YValue))
    GState.sizeHints->flags |= USPosition;
  if (bitmask & (WidthValue | HeightValue))
    GState.sizeHints->flags |= USSize;
}

void WindowInit(AppWindow *window, int argc, char *argv[])
{
  window->winId = XCreateSimpleWindow(GState.display,
				     DefaultRootWindow(GState.display),
				     GState.sizeHints->x, GState.sizeHints->y,
				     GState.sizeHints->width,
				     GState.sizeHints->height,
				     kDefaultBdWidth,
				     GState.fgPixel, GState.bgPixel);
  SetProperties(window, argc, argv);
  InitContext(window);
  SetWindowAttr(window);
  XSelectInput(GState.display, window->winId, ExposureMask);
  XMapWindow(GState.display, window->winId);
  AddTextButton(&ExitButton, window, 1, 1, kDefaultBdWidth, kExitText);
}

void SetProperties(AppWindow *window, int argc, char *argv[])
{
  if ((GState.classHint = XAllocClassHint()) == NULL) {
    fprintf(stderr, "Error allocating class hint!\n");
    exit(1);
  }
  GState.classHint->res_name = AppName;
  GState.classHint->res_class = "MBrot";

  /* Set up XTextProperty for window name and icon name */
  if (XStringListToTextProperty(&WindowTitle, 1, &window->title) == 0) {
    fprintf(stderr, "Error creating window name XTextProperty!\n");
    exit(1);
  }
  if(XStringListToTextProperty(&WindowTitle, 1, &window->iconName) == 0) {
    fprintf(stderr, "Error createing icon name XTextProperty!\n");
    exit(1);
  }

  if ((GState.xwmHints = XAllocWMHints()) == NULL) {
    fprintf(stderr, "error allocating Window Manager hints!\n");
    exit(1);
  }
  GState.xwmHints->flags = (InputHint | StateHint);
  GState.xwmHints->input = False;
  GState.xwmHints->initial_state = NormalState;
  XSetWMProperties(GState.display, window->winId, &window->title,
		   &window->iconName, argv, argc, GState.sizeHints,
		   GState.xwmHints, GState.classHint);
}

/* Create a graphics context for the main window
 */
void InitContext(AppWindow *window)
{
  XGCValues		gcValues;

  gcValues.font = GState.font->fid;
  gcValues.foreground = GState.fgPixel;
  gcValues.background = GState.bgPixel;
  window->context = XCreateGC(GState.display, window->winId,
			      (GCFont | GCForeground | GCBackground),
			      &gcValues);
}

void SetWindowAttr(AppWindow *window)
{
  XSetWindowAttributes windowAttr;
  
  windowAttr.colormap = DefaultColormap(GState.display,
					DefaultScreen(GState.display));
  windowAttr.bit_gravity = CenterGravity;
  XChangeWindowAttributes(GState.display, window->winId,
			  (CWColormap | CWBitGravity), &windowAttr);
}

void EventLoop(void)
{
  XEvent  theEvent;		/* Structure for current event */
  int     done;

  done = 0;
  while(!done) {
    XNextEvent(GState.display, &theEvent);

    if(theEvent.xany.window == MainWindow.winId) {
      HandleMainEvent(&theEvent, &done);
    } else if(theEvent.xany.window == ExitButton.winId) {
      HandleExitEvent(&theEvent, &done);
    }
  }
}

void HandleMainEvent(XEvent *theEvent, int *done)
{
  if (theEvent->type == Expose && theEvent->xexpose.count == 0) {
    DrawMainWindow((XExposeEvent *)theEvent, done);
  }
}

void DrawMainWindow(XExposeEvent *event, int *done)
{
  XClearWindow(GState.display, MainWindow.winId);
  DrawScreenTiles();
}

void HandleExitEvent(XEvent *theEvent, int *done)
{
  switch(theEvent->type) {
  case Expose:
    if (theEvent->xexpose.count == 0)
      DrawTextButton(&ExitButton);
    break;
  case ButtonPress:
    *done = 1;
    break;
  default:
    break;
  }
}

void Cleanup(void)
{
  /* wait for manager thread to finish.  When manager is finished no threads
   * are drawing into tiles
   */
  pthread_mutex_lock(&DoneMutex);
  DoneFlag = 1;
  while(!ManagerDone)
    pthread_cond_wait(&ManagerDoneCond, &DoneMutex);
  pthread_mutex_unlock(&DoneMutex);
  
  XFreeGC(GState.display, MainWindow.context);
  XFreeGC(GState.display, ExitButton.context);
  DestroyScreenTiles();
  XUnloadFont(GState.display, GState.font->fid);
  XDestroyWindow(GState.display, MainWindow.winId);
  XCloseDisplay(GState.display);
}

void StartThreads(void)
{
  int status;
  int thr;
  pthread_t tid;
  pthread_attr_t attr;

  InitTileList(&WorkList);
  InitTileList(&DoneList);

  pthread_attr_init(&attr);
  pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
  
  status = pthread_create(&tid, &attr, ManagerThread, NULL);
  if(status < 0) {
    fprintf(stderr, "Error creating thread: %s\n", strerror(status));
    exit(-1);
  }
  pthread_detach(tid);

  for(thr = 0 ; thr < kNumWorkerThreads ; thr++ ) {
    status = pthread_create(&tid, &attr, WorkerThread, NULL);
    if(status < 0) {
      fprintf(stderr, "Error creating thread: %s\n", strerror(status));
      exit(-1);
    }
    pthread_detach(tid);
  }
  pthread_attr_destroy(&attr);
}

void *ManagerThread(void *arg)
{
  int row;
  int col;
  int tileCnt;
  Tile *tile;
  int done;

  done = 0;
  if(!done) {
    for(row = 0 ; row < kVerticalTiles ; row++) {
      for(col = 0 ; col < kHorizTiles ; col++) {
	PutTile(&WorkList, &ScreenTiles[row][col]);
      }
    }
    
    tileCnt = kVerticalTiles * kHorizTiles;
    while(tileCnt > 0) {
      GetTile(&DoneList, &tile);
      DrawTile(&MainWindow, tile);
      tileCnt--;
      tileCnt -= CheckForManagerExit();
    }

    pthread_mutex_lock(&DoneMutex);
    if (DoneFlag) {
      done = 1;
    }
    pthread_mutex_unlock(&DoneMutex);
  }

  pthread_mutex_lock(&DoneMutex);
  ManagerDone = 1;
  pthread_mutex_unlock(&DoneMutex);
  pthread_cond_signal(&ManagerDoneCond);

  return NULL;
}

int CheckForManagerExit(void)
{
  int numTiles;

  pthread_mutex_lock(&DoneMutex);
  if(DoneFlag) {
    numTiles = ClearTileList(&WorkList);
  }
  pthread_mutex_unlock(&DoneMutex);

  return numTiles;
}

void *WorkerThread(void *arg)
{
  Tile *tile;

  while(1) {
    GetTile(&WorkList, &tile);
    MandelbrotTile(tile);
    PutTile(&DoneList, tile);
  }
  
  return NULL;
}

void MandelbrotTile(Tile *tile)
{
  int numIterations;
  double x, y;
  double xSqr, ySqr;
  double a, b;
  double aIncr, bIncr;
  char *result;
  int row, col;
  
  aIncr = tile->region.complexArea.width / tile->bbox.width;
  bIncr = tile->region.complexArea.height / tile->bbox.height;
  result = tile->data;

  b = tile->region.complexArea.corner.y;
  for(row = 0 ; row < tile->bbox.height ; row++) {
    a = tile->region.complexArea.corner.x;
    for(col = 0 ; col < tile->bbox.width ; col++) {
      x = 0;
      y = 0;
      xSqr = 0;
      ySqr = 0;
      numIterations = 0;
      while(numIterations < (kNumColors-1) && xSqr + ySqr < 10000) {
	y = 2 * x * y + b;
	x = xSqr - ySqr + a;
	xSqr = x * x;
	ySqr = y * y;
	numIterations++;
      }
      *result++ = ImageLut[numIterations];
      a += aIncr;
    }
    result += tile->bytes_per_row - tile->bbox.width;
    b += bIncr;
  }
}

void Usage(void)
{
  fprintf(stderr, "usage: %s [ -display host:display ] [ -geometry geom ]\n",
	  AppName);
  exit(1);
}

void RestoreXState(int num, void *arg)
{
  int row;
  int col;
  int depth;
  Visual *visual;
  RecoveryData *recoveryData;
  Tile *tile;

  recoveryData = (RecoveryData *)arg;
  if ((GState.display = XOpenDisplay(GState.displayName)) == NULL) {
    fprintf(stderr, "%s: cannot open display named %s\n",
	    AppName, XDisplayName(GState.displayName));
    exit(1);
  }
  GetResources();
  InitFonts();
  InitColors();
  InitWindowPosition();
  WindowInit(&MainWindow, recoveryData->argc, recoveryData->argv);

  for (row = 0 ; row < kVerticalTiles ; row++ ) {
    for (col = 0 ; col < kHorizTiles; col++ ) {
      depth = DefaultDepth(GState.display, DefaultScreen(GState.display));
      visual = DefaultVisual(GState.display, DefaultScreen(GState.display));
      tile = &ScreenTiles[row][col];
      tile->xImage = XCreateImage(GState.display, visual, depth, ZPixmap, 0,
				  tile->data, tile->region.xSteps,
				  tile->region.ySteps, 8, tile->bytes_per_row);
    }
  }
  DrawScreenTiles();
  DrawTextButton(&ExitButton);
}
