/*
 *
 * History
 * -------
 * $Log: tile.c,v $
 * Revision 1.1  1999/03/15 17:17:53  dieter
 * Initial revision
 *
 * Revision 1.4  1999/02/20  18:38:09  dieter
 * Allocate colors for a nicer display
 * Adjust aspect ratio.
 *
 * Revision 1.3  1999/02/19  22:23:32  dieter
 * Can draw mandlebrot set now.
 *
 * Revision 1.2  1999/02/19  20:30:21  dieter
 * Can redraw screen tiles.
 *
 * Revision 1.1  1999/02/19  15:47:09  dieter
 * Initial revision
 *
 */

#include <assert.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>

#include "gtype.h"
#include "tile.h"

/*****************************************************************************/
/*				Macro Definitions			     */
/*****************************************************************************/

#define kTileWidth     16
#define kTileHeight    16

#define kHorizTiles    32
#define kVerticalTiles 32

#define kImageWidth    (kHorizTiles * kTileWidth)
#define kImageHeight   (kVerticalTiles * kTileHeight)

#define ASSERT(x)      assert(x)

/*****************************************************************************/
/*				Type Definitions			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Global Variables			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Prototypes			     */
/*****************************************************************************/

/*****************************************************************************/
/*				Function Definitions			     */
/*****************************************************************************/

int InitTileList(TileList *list)
{
  list->head = NULL;
  list->len = 0;
  pthread_mutex_init(&list->mutex, NULL);
  pthread_cond_init(&list->cond, NULL);

  return 0;
}

/* remove everything from the list without freeing anything */
int ClearTileList(TileList *list)
{
  int len;

  pthread_mutex_lock(&list->mutex);
  list->head = NULL;
  len = list->len;
  list->len = 0;
  pthread_mutex_unlock(&list->mutex);

  ASSERT(len >= 0);
  
  return len;
}

int NewTile(CRegion *region, Rect *bbox, Tile **tile)
{
  char *data;

  *tile = (Tile *)malloc(sizeof(Tile));
  if (tile == NULL) {
    return -errno;
  }

  data = malloc(sizeof(char) * region->xSteps * region->ySteps);
  if (data == NULL) {
    free(*tile);
    return -errno;
  }
  
  InitTile(*tile, region, bbox, data, region->xSteps);

  return 0;
}

/* GState must be initialized before calling this function */
int InitTile(Tile *tile, CRegion *region, Rect *bbox, char *data,
	     int bytes_per_row)
{
  int row;
  int col;
  int rowBit;
  int colBit;
  unsigned int  depth;
  Visual       *visual;

  tile->region = *region;
  tile->bbox = *bbox;
  tile->data = data;
  tile->bytes_per_row = bytes_per_row;
  tile->next = NULL;

  /* initialize tile with checkerboard pattern */
  for (row = 0 ; row < region->ySteps ; row++) {
    for(col = 0 ; col < region->xSteps ; col++) {
      rowBit = (row >> 2) & 0x01;
      colBit = (col >> 2) & 0x01;
      data[col] = ((!rowBit && !colBit) || (rowBit && colBit)) ? 0xff : 0x00;
    }
    data += bytes_per_row;
  }

  depth = DefaultDepth(GState.display, DefaultScreen(GState.display));
  visual = DefaultVisual(GState.display, DefaultScreen(GState.display));
  tile->xImage = XCreateImage(GState.display, visual, depth, ZPixmap, 0,
			      tile->data, region->xSteps, region->ySteps, 8,
			      bytes_per_row);
  if(tile->xImage == NULL) {
    return -errno;
  }
  tile->xImage->byte_order = MSBFirst;
  
   return 0;
}

void DrawTile(AppWindow *window, Tile *tile)
{
  XPutImage(GState.display, window->winId, window->context, tile->xImage,
	    0, 0, tile->bbox.corner.x, tile->bbox.corner.y,
	    tile->bbox.width, tile->bbox.height);
}

int PutTile(TileList *list, Tile *tile)
{
  pthread_mutex_lock(&list->mutex);
  tile->next = list->head;
  list->head = tile;
  if(list->len == 0)
    pthread_cond_signal(&list->cond);
  list->len++;
  pthread_mutex_unlock(&list->mutex);

  return 0;
}

int GetTile(TileList *list, Tile **tile)
{
  pthread_mutex_lock(&list->mutex);
  while(list->len == 0)
    pthread_cond_wait(&list->cond, &list->mutex);
  ASSERT(list->head != NULL);
  *tile = list->head;
  list->head = list->head->next;
  list->len--;
  if(list->len > 0)
    pthread_cond_signal(&list->cond);
  pthread_mutex_unlock(&list->mutex);

  return 0;
}
