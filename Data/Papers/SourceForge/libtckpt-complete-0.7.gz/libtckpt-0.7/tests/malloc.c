/*
 * malloc.c
 *
 * Test malloc with checkpointing.  The problem here is the Solaris malloc
 * calls the underlying _mutex_lock call instead of pthread_mutex_lock, so
 * I do not trap the call.  Thus during recovery malloc will not get the
 * mutexes it was using back.  This is not just a problem with malloc.  It
 * should be a problem with any library function that uses mutexes.
 *
 * History
 * -------
 * $Log: malloc.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 1.1  2000/02/02 14:55:20  dieter
 * Initial revision
 *
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifdef CHECKPOINT
#include "checkpoint.h"
#endif

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS 5	/* number of threads + the main thread */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int num_threads = DEFAULT_THREADS;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);
void *do_work(void *arg);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  unsigned int thr_id;
  int        status;
  pthread_t  *threads;
  void 	     *ret;
  pthread_attr_t attr;

#ifdef CHECKPOINT
  chkpt_init(&argc, argv, NULL);
#endif

  handle_args(argc, argv);

  threads = (pthread_t *)malloc(sizeof(pthread_t) * num_threads);
  if(threads == NULL) {
    fprintf(stderr, "Cannot allocate id array for %d threads\n", num_threads);
    exit(-1);
  }
  
  pthread_attr_init(&attr);
  pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
  for(thr_id = 0 ; thr_id < num_threads ; thr_id++) {
    status = pthread_create(&threads[thr_id], &attr, do_work, (void *)thr_id);
    if(status != 0) {
      fprintf(stderr, "pthread_create: %s\n", strerror(status));
    }
  }
  pthread_attr_destroy(&attr);

  for(thr_id = 0 ; thr_id < num_threads ; thr_id++) {
    status = pthread_join(threads[thr_id], &ret);
    if(status != 0) {
      fprintf(stderr, "cannot join thread %d (id=%ld)\n",
	      thr_id, threads[thr_id]);
      fprintf(stderr, "pthread_join: %s\n", strerror(status));
      exit(-1);
    }
  }

  return 0;
}

void handle_args(int argc, char *argv[])
{
  int errflg = 0;
  int option;

  while ((option = getopt(argc, argv, "t:")) != EOF)
    switch (option) {
    case 't':
      num_threads = atoi(optarg);
      break;
    case '?':
      errflg++;
    }

  if (errflg) {
    fprintf(stderr, "test program that uses threads and synchronization\n");
    fprintf(stderr, "usage: %s [ -t threads ] [ -c num_cycles ]\n", argv[0]);
    exit (2);
  }

}

void *do_work(void *arg)
{
  unsigned int seed;
  unsigned int size;
  unsigned int id;
  void *ptr;
  int cnt;

  id = (unsigned int)arg;
  seed = id;

  while(1) {
    size = rand_r(&seed);
    /*    printf("%u: size= %u seed= %u\n", id, size, seed); */
    ptr = malloc(size);
    for(cnt = 0 ; cnt < 100000 ; cnt++)
      ;
    if(ptr != NULL)
      free(ptr);
  }
  
  return NULL;
}
