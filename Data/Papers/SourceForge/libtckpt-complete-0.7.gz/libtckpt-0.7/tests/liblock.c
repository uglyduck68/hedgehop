/*
 * liblock.c
 *
 * Test C library functions that use a mutex to make sure library mutex lock
 * and unlock calls are handled properly.
 *
 * ASSUME: malloc and free use a mutex to protect data structures shared by
 *         the whole process.  
 *
 * History
 * -------
 * $Log: liblock.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 1.1  2000/02/02 14:55:20  dieter
 * Initial revision
 *
 */

#include <sys/times.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "config.h"
#ifdef CHECKPOINT
#include "checkpoint.h"
#endif

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS 5	/* number of threads incl. the main thread */
#define DEFAULT_CYCLES  100000 /* number of times to add thread id 	   */

#define pthread_err(str,status) pthread_perr(__FILE__, __LINE__, str, status)

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int num_threads = DEFAULT_THREADS;
int num_cycles = DEFAULT_CYCLES;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);
void *do_test(void *arg);

void pthread_perr(char *file, int line, char *str, int status);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  int             thr_id;	/* thread id (not pthread_self) 	     */
  pthread_attr_t  attr;
  pthread_t      *tids;		/* array of thread ids (used for joining)    */
  int 	    	  status;	/* system return code 		   	     */
  void 		 *thr_status;	/* return status of threads		     */

  hrtime_t	  start_time;
  hrtime_t 	  end_time;

  /* initialization */
#ifdef CHECKPOINT
  chkpt_init(&argc, argv, NULL);
#endif

  handle_args(argc, argv);

  start_time = gethrtime();

  /* spawn threads */
  tids = (pthread_t *)malloc(sizeof(pthread_t) * num_threads);
  if(tids == NULL) {
    fprintf(stderr, "cannot allocated array of tids\n");
    exit(-1);
  }
  
  if( (status = pthread_attr_init(&attr)) != 0)
    pthread_err("pthread_attr_init", status);
  if( (status = pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM)) != 0)
    pthread_err("pthread_attr_setscope", status);
  for(thr_id = 1 ; thr_id <= num_threads ; thr_id++) {
    status = pthread_create(tids + thr_id - 1, &attr, do_test, (void *)thr_id);
    if(status != 0)
      pthread_err("pthread_create", status);
  }
  if( (status = pthread_attr_destroy(&attr)) != 0)
    pthread_err("pthread_attr_destroy", status);

  /* wait for threads */
  for(thr_id = 0 ; thr_id < num_threads ; thr_id++) {
    if( (status = pthread_join(tids[thr_id], &thr_status)) != 0)
      pthread_err("pthread_join", status);
  }
  
  end_time = gethrtime();

  printf("%4d threads %8d cycles %12f seconds\n", num_threads, num_cycles,
	 (1.0e-9 * (end_time - start_time)));
  
  return 0;
}

void handle_args(int argc, char *argv[])
{
  int errflg = 0;
  int option;

  while ((option = getopt(argc, argv, "t:c:")) != EOF)
    switch (option) {
    case 'c':
      num_cycles = atoi(optarg);
      break;
    case 't':
      num_threads = atoi(optarg);
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    fprintf(stderr, "test program that uses threads and synchronization\n");
    fprintf(stderr, "usage: %s [ -t threads ] [ -c num_cycles ]\n", argv[0]);
    exit (2);
  }
}

/* repeatedly allocate a (psuedo)random size memory chunk then free it */
void *do_test(void *arg)
{
  int thr_id;			/* (program assigned) thread id	   	     */
  int cycle_count;		/* number of times to repeat		     */
  unsigned int seed;		/* random number generator state	     */
  int malloc_size;		/* size of memory to allocate		     */
  void *ptr;			/* pointer to allocated memory		     */

  thr_id = (int)arg;
  seed = thr_id;

  for(cycle_count = 0 ; cycle_count < num_cycles ; cycle_count++) {
    malloc_size = rand_r(&seed);
    if ( (ptr = malloc(malloc_size)) == NULL) {
      fprintf(stderr, "thread %d cannot allocate %d bytes: %s\n",
	      thr_id, malloc_size, strerror(errno));
      exit(-1);
    }
    memset(ptr, thr_id, malloc_size);
    free(ptr);
  }

  return NULL;
}

void pthread_perr(char *file, int line, char *str, int status)
{
  fprintf(stderr, "%s:%d: %s: %s\n", file, line, str, strerror(status));
  exit(-1);
}
