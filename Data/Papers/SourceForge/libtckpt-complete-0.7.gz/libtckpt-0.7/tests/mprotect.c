/*
  mprotect

  A program to test interaction with mprotect and signal handling
 */
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <signal.h>
#ifdef SOLARIS
#include <siginfo.h>
#endif

#include "checkpoint.h"

#define CHKPT_FILENAME "mprotect.chkpt"

char largearray[1024*8*50]; /* will make parts read-only */
int pagelength; /* discovered via system call */
char *where; /* start of page in largearray with restricted privilege */
int chkpt_on = 0;
char *fault_addr = NULL;

void handle_args( int argc, char *argv[] );
void handler(int cause, siginfo_t *howCome, void *uap);

int main(int argc, char *argv[]) {
    struct sigaction action;

    chkpt_init(&argc, argv, NULL);

    /* simple test: make read-only, try writing */

    pagelength = sysconf(_SC_PAGESIZE); /* discover page size */
    /* rounded to certainly fall at page start */
    where = (char *)( ((int) (largearray + 1024*8) / pagelength) * pagelength);
    *where = 'f';

    handle_args( argc, argv );

    /* make one page read only */
    if (mprotect(where, pagelength, PROT_READ)) {
        perror("mprotect");
	exit(1);
    }

    /* establish SIGSEGV handler */
    action.sa_sigaction = handler;
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_SIGINFO;
    if (sigaction (SIGSEGV, &action, 0)) {
        perror("sigaction");
	exit(1);
    }
    printf( "testing the signal handler: " );
    /* the test itself */
#ifdef DEBUG
    fprintf(stdout, "About to read\n");
    fprintf(stdout, "What is there is '%c'\n", *where);
#endif
    if(*where != 'f') {
      fprintf(stdout, "memory at %p changed from 'f' to '%c'\n",
	      where, *where);
    }
#ifdef DEBUG
    fprintf(stdout, "About to write 'a'\n");
#endif
    if( chkpt_on )
      chkpt_now( CHKPT_FILENAME );
    *where = 'a';		/* should cause a fault, but then succeed */
#ifdef DEBUG
    fprintf(stdout, "What is there is '%c'\n", *where);
    fprintf(stdout, "About to write 'b'\n");
#endif
    if(*where != 'a') {
      fprintf(stdout, "incorrect data at %p: expected 'a', got '%c'\n",
	      where, *where);
    }
    if(fault_addr != where) {
      fprintf(stdout, "signal handler got the wrong faulting address\n");
    } else {
      fprintf(stdout, "signal handler ok\n");
    }
    *where = 'b';		/* no fault this time. */
    return(0);
}

void handle_args( int argc, char *argv[] )
{
  int c;
  int cflg = 0;
  int rflg = 0;
  int errflg = 0;
        
  while ((c = getopt(argc, argv, "c")) != EOF)
    switch (c) {
    case 'c':
      if( rflg )
	errflg++;
      else
	cflg++;
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    (void)fprintf(stderr, "usage: mprotect [-c]\n");
    exit (2);
  }

  if( cflg )
    chkpt_on = 1;

  return;
}

void handler(int cause, siginfo_t *siginfo, void *uap) 
{
#ifdef DEBUG
    fprintf( stderr, "handler got signal: %d, siginfo: %p, ", cause, siginfo );
    fprintf( stderr, "context: %p\n", uap );
    
    fprintf( stderr, "siginfo = { %d, %d, %d, %p }\n", siginfo->si_signo,
	     siginfo->si_errno, siginfo->si_code, siginfo->si_addr );
    /* SIGSEGV handler: called when protection fault occurs. */
    fprintf(stdout, "SIGSEGV raised at address 0x%x\n",
	    (int) siginfo->si_addr);
#endif
    fault_addr = siginfo->si_addr;

    /* now make the page writeable */
    if (mprotect(fault_addr, pagelength, PROT_READ | PROT_WRITE)) {
        perror("mprotect");
        exit(1);
    }
}
