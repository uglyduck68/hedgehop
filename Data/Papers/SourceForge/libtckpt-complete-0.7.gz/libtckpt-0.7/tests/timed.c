/*
 * timed.c
 *
 * A simple program that uses pthrad_cond_timedwait
 *
 * History
 * -------
 * $Log: timed.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.2  2000/02/01 23:52:20  dieter
 * Changes to make compiling easier (or possible) for both Linux and Solaris
 *
 * Revision 3.1  1999/03/03  20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:34:56  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.1  1998/09/15  14:34:24  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include <stdio.h>

#include "memdebug.h"
#include "checkpoint.h"

#define TIME_BUF_LEN 28

pthread_mutex_t time_mutex;
pthread_cond_t  time_cond;

int main(int argc, char *argv[])
{
  time_t now;
  int i;
  char time_buf[TIME_BUF_LEN];
  struct timespec timeout;
  int status;

  chkpt_init(&argc, argv, NULL);

  pthread_mutex_init(&time_mutex, NULL);
  pthread_cond_init(&time_cond, NULL);

  pthread_mutex_lock(&time_mutex);
  now = time(NULL);
  ctime_r(&now, time_buf, TIME_BUF_LEN);
  printf("%s", time_buf);
  for(i = 0 ; i < 10 ; i++) {
    timeout.tv_sec = now + 1;
    timeout.tv_nsec = 0;
    status = pthread_cond_timedwait(&time_cond, &time_mutex, &timeout);
    now = time(NULL);
    ctime_r(&now, time_buf, TIME_BUF_LEN);
    printf("%s", time_buf);
  }
  pthread_mutex_unlock(&time_mutex);

  return 0;
}

