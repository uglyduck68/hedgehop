/*
 * errors for server and clients
 */

#ifndef UDPERR_H
#define UDPERR_H

#define BAD_PORT     -5		/* illegal port number */
#define UNKOWN_OPT   -6		/* unknown option */
#define BAD_ADDR     -7		/* bad address specification */

#endif
