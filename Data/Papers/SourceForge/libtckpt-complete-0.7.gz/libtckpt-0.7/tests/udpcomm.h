/*
 * communication routines used by udpserv.c and udpcli.c
 *
 * History
 * -------
 * $Log: udpcomm.h,v $
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.1  1999/03/03 20:18:03  dieter
 * Made release 0.02
 *
 * Revision 1.1  1998/10/14  17:21:25  dieter
 * Initial revision
 *
 */
#ifndef UDPCOMM_H
#define UDPCOMM_H

/*****************************************************************************/
/*				Macros					     */
/*****************************************************************************/

#define MAX_MSG_LEN 256		/* maximum size of message sent in packed */

/*****************************************************************************/
/*			    Type Declarations				     */
/*****************************************************************************/

typedef unsigned short  uint16;
typedef unsigned long   uint32;

typedef struct message {
  uint16 version;		/* version number (major revision number)    */
  uint16 subversion;		/* subversion number (minor revision number) */
  uint32 count;			/* number of times this message was sent     */
  char   msg[MAX_MSG_LEN];	/* a message to send		 	     */
} message_t;

/*****************************************************************************/
/*			   Function Prototypes				     */
/*****************************************************************************/

int wait_for_message(int socket, message_t *msg, struct sockaddr_in *sender);
int send_message(int socket, message_t *msg, struct sockaddr_in *receiver);

#endif
