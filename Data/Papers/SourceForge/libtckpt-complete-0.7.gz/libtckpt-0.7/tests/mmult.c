/*
 * mmult.c
 *
 * pthreads matrix multiply
 *
 * History
 * -------
 * $Log: mmult.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.2  2000/02/01 23:52:20  dieter
 * Changes to make compiling easier (or possible) for both Linux and Solaris
 *
 * Revision 3.1  1999/03/03 20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:27:46  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.5  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.4  1998/08/31  21:25:11  dieter
 * Removed explicit call to pthread_exit because the checkpointing code
 * now handles functions that just return.
 *
 * Revision 1.3  1998/08/31  20:47:29  dieter
 * Skip over application arguments before reading checkpoint arguments.
 * Call pthread_exit explicitly.  Checkpointing cannot handle threads
 * that by returning (yet).
 * Call fclose to close the file at the end of write_matrix.
 *
 * Revision 1.2  1998/08/17  16:31:03  dieter
 * Added some comments.
 *
 * Revision 1.1  1998/08/17  16:14:37  dieter
 * Initial revision
 *
 */

#include <sys/time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h> 
#include <string.h>
#include <unistd.h>

#include "memdebug.h"
#include "checkpoint.h"

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_MATRIX_SIZE 200 /* default matrix dimension */
#define NUM_THREADS  5		/* number of threads incl. the main thread */
#define INDEX(matrix,row,column) \
((matrix)->data[(row)*((matrix)->row_skip) + (column)])

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct matrix {
  int     rows;			/* number of rows in the matrix */
  int     columns;		/* number of columns in the matrix */
  int     row_skip;		/* number of columns to skip to get to the
				 * next row
				 */
  double *data;			/* the actual matrix */
} matrix_t;

typedef struct thr_info {
  int id;
  matrix_t *mat1;
  matrix_t *mat2;
  matrix_t *result;
} thr_info_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

pthread_t *thread;
int num_threads = NUM_THREADS;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[], matrix_t *a, matrix_t *b, matrix_t *c);
int start_threads(matrix_t *mat1, matrix_t *mat2, matrix_t *result);
int join_threads(void);

void *thread_start(void *arg);

int  init_matrix(matrix_t *matrix, int rows, int columns);
void destroy_matrix(matrix_t *matrix);

void rand_matrix(matrix_t *matrix);
void print_matrix(matrix_t *matrix);
int  write_matrix(char *filename, matrix_t *matrix);

int  multiply_my_part(int id, int n_threads, matrix_t *m1, matrix_t *m2,
		      matrix_t *result);

int  mmult(matrix_t *m1, matrix_t *m2, matrix_t *result);

void subtimeval(struct timeval *diff, struct timeval *tv1,struct timeval *tv2);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  matrix_t matrix1;
  matrix_t matrix2;
  matrix_t result;

  struct timeval init_start;
  struct timeval compute_start;
  struct timeval compute_end;
  struct timeval output_end;

  struct timeval compute_time;
  struct timeval total_time;

  chkpt_init(&argc, argv, NULL);
  gettimeofday(&init_start, NULL);
  handle_args(argc, argv, &matrix1, &matrix2, &result);
  
  start_threads(&matrix1, &matrix2, &result);

  gettimeofday(&compute_start, NULL);
  /*  mmult(&matrix1, &matrix2, &result); */

  multiply_my_part(0, num_threads, &matrix1, &matrix2, &result);
  join_threads();

  gettimeofday(&compute_end, NULL);

  write_matrix("out", &result);
  gettimeofday(&output_end, NULL);

  subtimeval(&compute_time, &compute_end, &compute_start);
  subtimeval(&total_time, &output_end, &init_start);

  printf("compute wallclock time is %g seconds\n",
	 compute_time.tv_sec + compute_time.tv_usec * 1e-6);
  
  printf("total wallclock time is %g seconds\n",
	 total_time.tv_sec + total_time.tv_usec * 1e-6);
  
  return 0;
}

void handle_args(int argc, char *argv[], matrix_t *a, matrix_t *b, matrix_t *c)
{
  int option;
#if 0
  int cflg = 0;
  int rflg = 0;
#endif
  int errflg = 0;
  int arows = DEFAULT_MATRIX_SIZE;
  int acols = DEFAULT_MATRIX_SIZE;
  int bcols = DEFAULT_MATRIX_SIZE;

  while ((option = getopt(argc, argv, "m:n:k:t:")) != EOF)
    switch (option) {
#if 0
    case 'c':
      if( rflg )
	errflg++;
      else
	cflg++;
      break;
    case 'r':
      if( cflg )
	errflg++;
      else
	rflg++;
      break;
#endif
    case 'm':
      arows = atoi(optarg);
      break;
    case 'n':
      acols = atoi(optarg);
      break;
    case 'k':
      bcols = atoi(optarg);
      break;
    case 't':
      num_threads = atoi(optarg);
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    fprintf(stderr, "multiply an m x n matrix by an n x k matrix\n");
    fprintf(stderr, "usage: %s [ -t threads ] [ -m m ] [ -n n ] [ -k k ]\n",
	    argv[0]);
    exit (2);
  }

  srand48(42L);

  init_matrix(a, arows, acols);
  rand_matrix(a);
  write_matrix("mat1", a);

  init_matrix(b, acols, bcols);
  rand_matrix(b);
  write_matrix("mat2", b);

  init_matrix(c, arows, bcols);

  if(num_threads > arows) {
    num_threads = arows;
    fprintf(stderr, "cannot handle more threads than rows in first matrix\n");
    fprintf(stderr, "using %d threads\n", num_threads);
  }
  thread = (pthread_t *)malloc(sizeof(pthread_t) * num_threads);
  if(thread == NULL) {
    fprintf(stderr, "cannot allocate thread id array\n");
    exit(-1);
  }

#if 0
  if( cflg )
    chkpt_on = 1;

  if( rflg )
    restore_state( CHKPT_FILENAME );
#endif

  printf("multiply a %dx%d with a %dx%d using %d threads\n",
	 arows, acols, acols, bcols, num_threads);

  return;
}

int start_threads(matrix_t *mat1, matrix_t *mat2, matrix_t *result) 
{
  int thr;
  int status;
  thr_info_t *info;

  for( thr = 1 ; thr < num_threads ; thr++ ) {
    info = (thr_info_t *)malloc(sizeof(thr_info_t));
    if(info == NULL) {
      fprintf(stderr, "cannot allocate info structure\n");
      return -1;
    }
    info->id = thr;
    info->mat1 = mat1;
    info->mat2 = mat2;
    info->result = result;
    status = pthread_create(&thread[thr], NULL, thread_start, (void *)info);
    if( status < 0 ) {
      fprintf(stderr, "Could not create thread %d\n", thr);
      fprintf(stderr, "pthread_create: %s\n", strerror(status));
      exit(-1);
    }
  }

  return 0;
}

int join_threads(void)
{
  void *status;
  int thr;
  int pstatus;

  for(thr = 1 ; thr < num_threads ; thr++) {
    pstatus = pthread_join(thread[thr], &status);
    if(pstatus != 0) {
      fprintf(stderr, "cannot join the %dth thread which has id %ld\n", thr,
	      thread[thr]);
      fprintf(stderr, "join_threads: %s\n", strerror(pstatus));
    }
  }
  
  return 0;
}

void *thread_start(void *arg)
{
  thr_info_t *info;

  info = (thr_info_t *)arg;
  multiply_my_part(info->id, num_threads, info->mat1, info->mat2,
		   info->result);
  return NULL;
}

int  init_matrix(matrix_t *matrix, int rows, int columns)
{
  matrix->rows = rows;
  matrix->columns = columns;
  matrix->row_skip = columns;
  matrix->data = (double *)malloc(sizeof(double)*rows*columns);
  if(matrix->data == NULL) {
    fprintf(stderr, "cannot allocate space for matrix data\n");
    return ENOMEM;
  }
  return 0;
}

void destroy_matrix(matrix_t *matrix)
{
  free(matrix->data);
  matrix->data = NULL;
}

/* generate data for a random matrix */
void rand_matrix(matrix_t *matrix)
{
  int row;
  int column;

  for(row = 0 ; row < matrix->rows ; row++) {
    for(column = 0 ; column < matrix->columns ; column++) {
      INDEX(matrix, row, column) = drand48();
    }
  }
}

void print_matrix(matrix_t *matrix)
{
  int row;
  int column;

  for(row = 0 ; row < matrix->rows ; row++) {
    for(column = 0 ; column < matrix->columns ; column++) {
      printf("%7.4g ", INDEX(matrix, row, column));
    }
    printf("\n");
  }
  printf("\n");
}

int  write_matrix(char *filename, matrix_t *matrix)
{
  int row;
  int column;
  FILE *fp;
  int status;

  fp = fopen(filename, "w");
  if(fp == NULL) {
    fprintf(stderr, "write_matrix: cannot open output file %s\n", filename);
    perror("write_matrix");
    return errno;
  }
  
  for(row = 0 ; row < matrix->rows ; row++) {
    for(column = 0 ; column < matrix->columns ; column++) {
      status = fprintf(fp, "%7.4g ", INDEX(matrix, row, column));
      if (status < 1) {
	fprintf(stderr, "could not write %7.4g to file \"%s\"\n",
		INDEX(matrix, row, column), filename);
      }
    }
    status = fprintf(fp, "\n");
    if (status < 1) {
      fprintf(stderr, "could not write newline to file %s\n", filename);
    }
  }
  fclose(fp);

  return 0;
}

/* do my part of the mutlply */

int  multiply_my_part(int id, int n_threads, matrix_t *m1, matrix_t *m2,
		      matrix_t *result)
{
  matrix_t a;
  matrix_t b;
  matrix_t c;
  int start_row;
  int end_row;
  int rows_per_thread;
  int extra_rows;

  a = *m1;
  b = *m2;
  c = *result;

  rows_per_thread = m1->rows / n_threads;
  extra_rows = m1->rows % n_threads;
  
  start_row = rows_per_thread * id + (id * extra_rows) / n_threads;
  end_row =   rows_per_thread * (id + 1) + ((id + 1) * extra_rows) / n_threads;

  printf("%d starting with row %d ending with row %d\n",
	 id, start_row, end_row);
  a.rows = end_row - start_row;
  a.data = &INDEX(&a, start_row, 0);

  c.rows = a.rows;
  c.data = &INDEX(&c, start_row, 0);
  
  mmult(&a, &b, &c);
  
  return 0;
}

/* compute m1 * m2 sequentially */
int  mmult(matrix_t *m1, matrix_t *m2, matrix_t *result)
{
  int row;
  int column;
  int index;

  if(m1->columns != m2->rows) {
    fprintf(stderr, "inner dimensions of m1 and m2 must match\n");
    return -1;
  }

  if(m1->rows != result->rows) {
    fprintf(stderr, "result must have same number of rows as m1\n");
    return -1;
  }

  if(m2->columns != result->columns) {
    fprintf(stderr, "result must have same number of columns as m2\n");
    return -1;
  }
  
#define COLUMNS_IN_INNER_LOOP	/* COLUMNS_IN_INNER_LOOP is slightly faster */
#ifdef COLUMNS_IN_INNER_LOOP
  for(row = 0 ; row < m1->rows ; row++) {
    for(column = 0 ; column < m2->columns ; column++) {
      INDEX(result, row, column) = 0.0;
    }
    for(index = 0 ; index < m1->columns ; index++ ) {
      for(column = 0 ; column < m2->columns ; column++) {
    	INDEX(result, row, column) +=
	  INDEX(m1, row, index) * INDEX(m2, index, column);
      }
    }
  }
#else
  for(row = 0 ; row < m1->rows ; row++) {
    for(column = 0 ; column < m2->columns ; column++) {
      INDEX(result, row, column) = 0.0;
      for(index = 0 ; index < m1->columns ; index++ ) {
    	INDEX(result, row, column) +=
	  INDEX(m1, row, index) * INDEX(m2, index, column);
      }
    }
  }
#endif

  return 0;
}

void subtimeval(struct timeval *diff, struct timeval *tv1, struct timeval *tv2)
{
  diff->tv_usec = tv1->tv_usec - tv2->tv_usec;
  if(diff->tv_usec < 0) {
    diff->tv_usec += 1000000;
    diff->tv_sec = -1;
  } else {
    diff->tv_sec = 0;
  }
  diff->tv_sec += tv1->tv_sec - tv2->tv_sec;
}
