/*
 * ring.c
 *
 * a checkpointing test program that uses lots of synchronization
 *
 * History
 * -------
 * $Log: ring.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.2  2000/02/01 23:52:20  dieter
 * Changes to make compiling easier (or possible) for both Linux and Solaris
 *
 * Revision 3.1  1999/03/03 20:19:18  dieter
 * Made release 0.02
 *
 * Revision 2.1  1999/01/06  23:43:11  dieter
 * bump version to 2 to keep up with the rest of the code
 *
 * Revision 1.6  1999/01/06  00:28:30  dieter
 * Revision 1.4 setup the attribute structure for system-wide scheduling,
 * but forgot to pass the attribute structure to pthread_create.  Pass
 * the thread attribute structure to pthread_create to get system scope
 * threads.
 *
 * Revision 1.5  1998/12/22  15:33:37  dieter
 * version of that worked for ftcs paper.
 *
 * Revision 1.4  1998/12/11  21:45:09  dieter
 * Set the thread scope to system for fair comparison with checkpointing.
 *
 * Revision 1.3  1998/12/03  19:35:52  dieter
 * Added option to set number of iterations.
 *
 * Revision 1.2  1998/11/19  14:33:11  dieter
 * Several bug fixes and added checkpointing.
 *
 * Revision 1.1  1998/10/27  16:48:58  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>

#ifdef CHECKPOINT
#include "checkpoint.h"
#endif

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS 5	/* number of threads incl. the main thread */
#define DEFAULT_CYCLES      1000000 /* number of times to go around the ring */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int num_threads = DEFAULT_THREADS;
int num_cycles = DEFAULT_CYCLES;
pthread_mutex_t count_update_mutex;
pthread_cond_t  count_update_cond;
int count = 0;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);
void *do_count(void *arg);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  int thr_id;
  pthread_t ptid;
  hrtime_t start_time;
  hrtime_t end_time;
  hrtime_t init_start;
  hrtime_t init_end;
  pthread_attr_t attr;
#ifdef CHECKPOINT

  init_start = gethrtime();
  chkpt_init(&argc, argv, NULL);
  init_end = gethrtime();
#endif

  handle_args(argc, argv);

  count = 0;
  pthread_mutex_init(&count_update_mutex, NULL);
  pthread_cond_init(&count_update_cond, NULL);
  
  start_time = gethrtime();
  pthread_attr_init(&attr);
  pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
  for(thr_id = 1 ; thr_id < num_threads ; thr_id++) {
    pthread_create(&ptid, &attr, do_count, (void *)thr_id);
    pthread_detach(ptid);
  }
  pthread_attr_destroy(&attr);

  do_count((void *) 0);
  end_time = gethrtime();

#if 0
#ifdef CHECKPOINT
  printf("init time = %f seconds\n", (1.0e-9 * (init_end - init_start)));
  printf("ring time = %f seconds\n", (1.0e-9 * (end_time - start_time)));
#endif
#endif
  printf("%4d %8d %12f\n", num_threads, num_cycles,
	 (1.0e-9 * (end_time - start_time)));
  
  return 0;
}

void *do_count(void *arg)
{
  int thr_id;
  int cycle_count;
#ifdef PREFORMANCE_TESTING
  hrtime_t wait_start;
  hrtime_t wait_end;
  hrtime_t total_wait = 0;
  int wait_count = 0;
#endif
  int status;

  thr_id = (int)arg;

#if 0
  printf("thr_id %d in do_count\n", thr_id);
#endif
  status = pthread_mutex_lock(&count_update_mutex);
  assert(status != EDEADLK);
  for(cycle_count = 0 ; cycle_count < num_cycles ; cycle_count++) {
    while(count % num_threads != thr_id) {
#ifdef PERFORMANCE_TESTING
      wait_start = gethrtime();
      wait_count++;
#endif
      pthread_cond_wait(&count_update_cond, &count_update_mutex);
#ifdef PERFORMANCE_TESTING
      wait_end = gethrtime();
      total_wait += wait_end - wait_start;
#endif
    }
#if 1
    if ((count % 1001) == 0) {
      printf("thr_id %d (%ld): count = %d\n", thr_id, pthread_self(), count);
    }
#endif
    count++;
    pthread_cond_broadcast(&count_update_cond);
  }
  status = pthread_mutex_unlock(&count_update_mutex);
  assert(status != EDEADLK);

#ifdef PERFORMANCE_TESTING
  fprintf(stderr, "wait time = %f seconds\n", (1.0e-9 * total_wait));
  fprintf(stderr, "wait count = %d\n", wait_count);
#endif

  /* give all other threads a chance to finish before returning */

  pthread_mutex_lock(&count_update_mutex);
  while(count < num_threads * num_cycles) {
    pthread_cond_wait(&count_update_cond, &count_update_mutex);
  }
  pthread_mutex_unlock(&count_update_mutex);

  return NULL;
}

void handle_args(int argc, char *argv[])
{
  int errflg = 0;
  int waitflg = 0;
  int num_waits = 0;
  int option;

  while ((option = getopt(argc, argv, "t:c:w:")) != EOF)
    switch (option) {
    case 'c':
      num_cycles = atoi(optarg);
      break;
    case 't':
      num_threads = atoi(optarg);
      break;
    case 'w':
      num_waits = atoi(optarg);
      waitflg++;
      break;
    case '?':
      errflg++;
    }
  if(waitflg) {
    num_cycles = (num_waits + num_threads - 1) / num_threads;
  }
  if (errflg) {
    fprintf(stderr, "test program that uses threads and synchronization\n");
    fprintf(stderr, "usage: %s [ -t threads ] [ -c num_cycles ]\n", argv[0]);
    exit (2);
  }

}
