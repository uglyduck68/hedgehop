/*
 * locktest.c
 *
 * test pthread_mutex_lock and pthread_mutex_unlcok to make sure they work
 *
 * locktests spawns some number of threads and assigns each thread a number.
 * Each thread adds its assigned number to a shared sum variable some
 * number of times, locking and unlocking a mutex each time.  After all 
 * threads have finished the main thread checks to make sure the some
 * is correct.  If the mutex does not provide mutual exclusion, it is likely
 * that one of the threads will overwrite another thread's answer and
 * the sum will be incorrect.
 *
 * History
 * -------
 * $Log: locktest.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 1.3  2000/02/01 23:52:20  dieter
 * Changes to make compiling easier (or possible) for both Linux and Solaris
 *
 * Revision 1.2  1999/04/19 21:57:48  dieter
 * Include configuration output even if test fails.
 *
 * Revision 1.1  1999/04/16  13:56:10  dieter
 * Initial revision
 *
 */

#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>

#include "config.h"
#ifdef CHECKPOINT
#include "checkpoint.h"
#endif

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS 5	/* number of threads incl. the main thread */
#define DEFAULT_CYCLES  2000000 /* number of times to add thread id 	   */

#define pthread_err(str,status) pthread_perr(__FILE__, __LINE__, str, status)

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int num_threads = DEFAULT_THREADS;
int num_cycles = DEFAULT_CYCLES;

unsigned long    sum;		/* the shared sum */
pthread_mutex_t  sum_mutex;	/* the mutex that protects sum */

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);
void *do_sum(void *arg);

void pthread_perr(char *file, int line, char *str, int status);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  int             thr_id;	/* thread id (not pthread_self) 	     */
  unsigned long   correct_sum;	/* the correct result of summing             */
  pthread_attr_t  attr;
  pthread_t      *tids;		/* array of thread ids (used for joining)    */
  int 	    	  status;	/* system return code 		   	     */
  void 		 *thr_status;	/* return status of threads		     */
  hrtime_t	  start_time;
  hrtime_t 	  end_time;

  /* initialization */
#ifdef CHECKPOINT
  chkpt_init(&argc, argv, NULL);
#endif

  handle_args(argc, argv);

  sum = 0;
  if( (status = pthread_mutex_init(&sum_mutex, NULL)) != 0)
    pthread_err("pthread_mutex_init", status);

  start_time = gethrtime();

  /* spawn threads */
  tids = (pthread_t *)malloc(sizeof(pthread_t) * num_threads);
  if(tids == NULL) {
    fprintf(stderr, "cannot allocated array of tids\n");
    exit(-1);
  }
  
  if( (status = pthread_attr_init(&attr)) != 0)
    pthread_err("pthread_attr_init", status);
  if( (status = pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM)) != 0)
    pthread_err("pthread_attr_setscope", status);
  for(thr_id = 1 ; thr_id <= num_threads ; thr_id++) {
    status = pthread_create(tids + thr_id - 1, &attr, do_sum, (void *)thr_id);
    if(status != 0)
      pthread_err("pthread_create", status);
  }
  if( (status = pthread_attr_destroy(&attr)) != 0)
    pthread_err("pthread_attr_destroy", status);

  /* wait for threads */
  for(thr_id = 0 ; thr_id < num_threads ; thr_id++) {
    if( (status = pthread_join(tids[thr_id], &thr_status)) != 0)
      pthread_err("pthread_join", status);
  }
  
  end_time = gethrtime();

  /* check the sum */
  /* NOTE: sum will not overflow with 2 million cycles and 64 or less threads.
   * Even if sum overflows it should not be a big deal.  This calculation
   * should get the same answer as the thread sum.
   */
  correct_sum = num_threads * (num_threads+1) / 2 * num_cycles;
  if(sum != correct_sum) {
    printf("test failed: sum is %ld instead of %ld\n", sum, correct_sum);
    status = -1;
  } else {
    printf("test passed: ");
    status = 0;
  }
  
  printf("%4d threads %8d cycles %12f seconds\n", num_threads, num_cycles,
	 (1.0e-9 * (end_time - start_time)));
  
  return status;
}

void handle_args(int argc, char *argv[])
{
  int errflg = 0;
  int option;

  while ((option = getopt(argc, argv, "t:c:")) != EOF)
    switch (option) {
    case 'c':
      num_cycles = atoi(optarg);
      break;
    case 't':
      num_threads = atoi(optarg);
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    fprintf(stderr, "test program that uses threads and synchronization\n");
    fprintf(stderr, "usage: %s [ -t threads ] [ -c num_cycles ]\n", argv[0]);
    exit (2);
  }
}

void *do_sum(void *arg)
{
  int thr_id;
  int cycle_count;
  int status;

  thr_id = (int)arg;

  for(cycle_count = 0 ; cycle_count < num_cycles ; cycle_count++) {
    if( (status = pthread_mutex_lock(&sum_mutex)) != 0)
      pthread_err("pthread_mutex_lock", status);
    sum = sum + thr_id;
    if( (status = pthread_mutex_unlock(&sum_mutex)) != 0)
      pthread_err("pthread_mutex_unlock", status);
  }

  return NULL;
}

void pthread_perr(char *file, int line, char *str, int status)
{
  fprintf(stderr, "%s:%d: %s: %s\n", file, line, str, strerror(status));
  exit(-1);
}
