/*
 * client for a simple UDP ping program
 *
 * History
 * -------
 * $Log: udpcli.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.1  1999/03/03 20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.2  1999/01/09  00:02:18  dieter
 * Added calls to chkpt_block and chkpt_unblock to prevent checkpoints when they would cause the protocol to lock up.
 *
 * Revision 2.1  1999/01/07  00:12:32  dieter
 * Use a checkpoint callback function to restore the udp socket
 * during recovery.  The test locks, however, if the client was
 * waiting for a reply from the server, because the server does
 * not know about the checkpoint.
 *
 * Revision 1.1  1998/10/14  17:21:25  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "udperr.h"
#include "udpcomm.h"

#include "checkpoint.h"

/*****************************************************************************/
/*				Macros					     */
/*****************************************************************************/

/*****************************************************************************/
/*			    Type Declarations				     */
/*****************************************************************************/

typedef struct client_opts {
  struct sockaddr_in addr;
  struct sockaddr_in server_addr;
} client_opt_t;

typedef struct recovery_info {
  client_opt_t *opts;
  int socket;
} recovery_info_t;

/*****************************************************************************/
/*			   Function Prototypes				     */
/*****************************************************************************/

int handle_opts(int argc, char *argv[], client_opt_t *opts);
int get_server_addr(char *addr, client_opt_t *opts);
void usage(char *prog);

int get_client_socket(client_opt_t *opts);
void restore_client_socket(int chkpt_num, void *arg);

/*****************************************************************************/
/*			   Function Declarations			     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  client_opt_t opts;
  int client_socket;
  int status;
  message_t msg;
  chkpt_callback_t callback;
  recovery_info_t info;

  chkpt_init(&argc, argv, NULL);

  handle_opts(argc, argv, &opts);

  /* open my socket */
  client_socket = get_client_socket(&opts);
  if( client_socket < 0 ) {
    fprintf(stderr, "%s: error opening client socket\n", argv[0]);
    fprintf(stderr, "%s\n", strerror(client_socket));
  }

  callback.pre_chkpt = NULL;
  callback.post_chkpt = NULL;
  callback.recovery = restore_client_socket;
  info.opts = &opts;
  info.socket = client_socket;
  chkpt_callback_push(&callback, &info);

  /* initialize messages */
  msg.version = 0;
  msg.subversion = 0;
  msg.count = 0;
  sprintf(msg.msg, "hello from the client at %s:%d\n",
	 inet_ntoa(opts.addr.sin_addr), ntohs(opts.addr.sin_port));
  
  status = 0;
  while(status >= 0) {

    chkpt_block();
    /* reply to incoming messages */
    status = send_message(client_socket, &msg, &opts.server_addr);
    if( status < 0 ) {
      fprintf(stderr, "%s: error sending message\n", argv[0]);
      fprintf(stderr, "%s\n", strerror(status));
      exit(status);
    }

    /* listen for incoming messages */
    status = wait_for_message(client_socket, &msg, &opts.server_addr);
    if( status < 0 ) {
      fprintf(stderr, "%s: error waiting for message\n", argv[0]);
      fprintf(stderr, "%s\n", strerror(status));
      exit(status);
    }
    chkpt_unblock();

    printf("received reply %ld from server\n", msg.count);

    msg.count++;
    sleep(1);
 }

  close(client_socket);
  
  return 0;
}

/*****************************************************************************/
/*		        Command Line Option Handling			     */
/*****************************************************************************/

int handle_opts(int argc, char *argv[], client_opt_t *opts)
{
  int opt;

  /* initialize address */
  memset(&opts->addr, 0, sizeof(struct sockaddr_in));
  opts->addr.sin_family = AF_INET;
  opts->addr.sin_port = htons(0);
  opts->addr.sin_addr.s_addr = INADDR_ANY;

  /* handle command line arguments */
  while((opt = getopt(argc, argv, "s:")) != EOF) {
    switch(opt) {
    case 's':
      if (get_server_addr(optarg, opts) == -1) {
	fprintf(stderr, "invalid address: %s\n", optarg);
	usage(argv[0]);
	exit(BAD_ADDR);
      }
      break;
    default:
      fprintf(stderr, "unknown option '%c'\n", opt);
      usage(argv[0]);
      exit(UNKOWN_OPT);
      break;
    }
  }
  
  return 0;
}

int get_server_addr(char *addr, client_opt_t *opts)
{
  char *port_str;		/* a string containing server's port */
  long port;			/* the server's port number */
  unsigned long ip_addr;	/* the server's ip address */

  /* split the address string into port number and IP address */
  port_str = strchr(addr, ':');
  if(port_str == NULL ) {
    fprintf(stderr, "port not specified with -s option: %s\n", addr);
    return BAD_PORT;
  }
  *port_str++ = '\0';

  /* initialize the address structure */
  memset(&opts->server_addr, 0, sizeof(struct sockaddr_in));
  opts->server_addr.sin_family = AF_INET;

  /* get the port */
  port = atoi(port_str);
  if (port < 0 || port > 65535) {
    fprintf(stderr, "invalid port %ld\n", port);
    return BAD_PORT;
  }
  opts->server_addr.sin_port = htons(port);

  /* get the IP address */
  ip_addr = inet_addr(addr);
  if (ip_addr == -1) {
    fprintf(stderr, "cannot find ip address in '%s'\n", addr);
    return BAD_ADDR;
  }
  opts->server_addr.sin_addr.s_addr = ip_addr;
  
  return 0;
}

void usage(char *prog)
{
  fprintf(stderr, "usage: %s [ -s addr:port ] \n", prog);
  fprintf(stderr, "   -s addr:port	use addr:port as the server's IP address and udp port\n");
}

/*****************************************************************************/
/*		              Communication				     */
/*****************************************************************************/

int get_client_socket(client_opt_t *opts)
{
  int client_socket;
  int addr_len;
  int status;

  client_socket = socket(AF_INET, SOCK_DGRAM, 0);
  if (client_socket == -1) {
    fprintf(stderr, "Error allocating socket\n");
    return -errno;
  }

  status = bind(client_socket, (struct sockaddr *)&opts->addr,
		sizeof(struct sockaddr_in));
  if (status == -1) {
    fprintf(stderr, "Error binding socket to %s:%d\n",
	    inet_ntoa(opts->addr.sin_addr), ntohs(opts->addr.sin_port));
    return -errno;
  }

  addr_len = sizeof(struct sockaddr_in);
  status = getsockname(client_socket, (struct sockaddr *)&opts->addr,
		       &addr_len);
  if (status < 0) {
    fprintf(stderr, "could not read socket name\n");
    return -errno;
  }

  return client_socket;
}

void restore_client_socket(int chkpt_num, void *arg)
{
  recovery_info_t *info;
  int new_socket;
  int status;

  info = (recovery_info_t *)arg;
  close(info->socket);
  new_socket = get_client_socket(info->opts);
  if( new_socket < 0 ) {
    fprintf(stderr, "error opening recovered socket\n");
    fprintf(stderr, "%s\n", strerror(new_socket));
  }

  if( new_socket != info->socket) {
    status = dup2(new_socket, info->socket);
    if(status < 0) {
      perror("dup2");
      fprintf(stderr, "error dup'ing socket %d to %d\n",
	      new_socket, info->socket);
    }
    /* close(new_socket) */
  }
}
