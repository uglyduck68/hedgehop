/*
 *
 * Measure overhead of intercepting function calls
 *
 * History
 * -------
 * $Log: it2.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 1.1  2000/02/02 14:55:20  dieter
 * Initial revision
 *
 * Revision 1.1  1998/11/25  17:36:10  dieter
 * Initial revision
 *
 */

#include <sys/time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h> 
#include <string.h>
#include <dlfcn.h>

#include "config.h"

#ifdef CHECKPOINT
#include "checkpoint.h"
#endif
/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS  5	/* number of threads incl. the main thread */
#define DEFAULT_ITERATIONS 1000000 /* default number of lock iterations      */

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

typedef struct thr_info {
  int id;
} thr_info_t;

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

pthread_t *thread;
int num_threads = DEFAULT_THREADS;
int num_iterations = DEFAULT_ITERATIONS;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);

int start_threads(void);
int join_threads(double *avg_time);

void *thread_start(void *arg);

void subtimeval(struct timeval *diff, struct timeval *tv1,struct timeval *tv2);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  hrtime_t init_start;
  double avg_time;

#ifdef CHECKPOINT
  chkpt_init(&argc, argv, NULL);
#endif
  init_start = gethrtime();
  handle_args(argc, argv);
  
  start_threads();

  join_threads(&avg_time);

  printf("avg time for %d threads to call function %d times is %g sec\n",
	 num_threads, num_iterations, avg_time ); return 0;
}

void handle_args(int argc, char *argv[])
{
  int option;
  int errflg = 0;

  while ((option = getopt(argc, argv, "i:t:")) != EOF)
    switch (option) {
    case 't':
      num_threads = atoi(optarg);
      break;
    case 'i':
      num_iterations = atoi(optarg);
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    fprintf(stderr, "Test locking independent mutexes\n");
    fprintf(stderr, "usage: %s [ -t threads ]\n",
	    argv[0]);
    exit (2);
  }

  if(num_iterations < 1) {
    num_threads = DEFAULT_THREADS;
    fprintf(stderr, "cannot handle less that 1 iteration\n");
    fprintf(stderr, "using %d iterations\n", num_iterations);
  }

  if(num_threads < 1) {
    num_threads = DEFAULT_THREADS;
    fprintf(stderr, "cannot handle less that 1 thread\n");
    fprintf(stderr, "using %d threads\n", num_threads);
  }
  thread = (pthread_t *)malloc(sizeof(pthread_t) * num_threads);
  if(thread == NULL) {
    fprintf(stderr, "cannot allocate thread id array\n");
    exit(-1);
  }

  return;
}

int start_threads(void) 
{
  int thr;
  int status;
  thr_info_t *info;
  pthread_attr_t attr;

  pthread_attr_init(&attr);
  pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

  for( thr = 1 ; thr < num_threads ; thr++ ) {
    info = (thr_info_t *)malloc(sizeof(thr_info_t));
    if(info == NULL) {
      fprintf(stderr, "cannot allocate info structure\n");
      return -1;
    }
    info->id = thr;
    status = pthread_create(&thread[thr], &attr, thread_start, (void *)info);
    if( status < 0 ) {
      fprintf(stderr, "Could not create thread %d\n", thr);
      fprintf(stderr, "pthread_create: %s\n", strerror(status));
      exit(-1);
    }
  }

  pthread_attr_destroy(&attr);

  return 0;
}

int join_threads(double *avg_time)
{
  int thr;
  int pstatus;
  int num_joined;
  union {
    void *ptr_val;
    float float_val;
  } retval;

  num_joined = 0;
  *avg_time = 0;
  for(thr = 1 ; thr < num_threads ; thr++) {
    pstatus = pthread_join(thread[thr], &(retval.ptr_val));
    if(pstatus != 0) {
      fprintf(stderr, "cannot join the %dth thread which has id %d\n", thr,
	      thread[thr]);
      fprintf(stderr, "join_threads: %s\n", strerror(pstatus));
    }
    num_joined++;
    *avg_time += retval.float_val;
  }

  *avg_time /= num_joined;
  
  return 0;
}

void *thread_start(void *arg)
{
  thr_info_t *info;
  hrtime_t start_time;		/* in nanoseconds */
  hrtime_t end_time;		/* in nanoseconds */
  double total_time;		/* in seconds */
  int count;
  union {
    void *ptr_val;
    float float_val;
  } retval;

  info = (thr_info_t *)arg;

  start_time = gethrtime();
  for(count = 0 ; count < num_iterations ; count++) {
    pthread_self();
  }
  end_time = gethrtime();

  total_time = (end_time - start_time) * 1.0e-9;
/*   printf("thread %d did %d locks and unlocks in ", info->id, num_iterations); */
/*   printf("%0.4f seconds\n    %g sec per (lock,unlock)\n", total_time, */
/* 	 (total_time/num_iterations)); */

  retval.float_val = (total_time/num_iterations);
  return retval.ptr_val;
}

#ifdef INTERCEPT
pthread_t pthread_self(void)
{
  return real_pthread_self();
}
#endif
