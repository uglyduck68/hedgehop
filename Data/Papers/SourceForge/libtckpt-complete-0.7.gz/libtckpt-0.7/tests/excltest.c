/*
 * Test memory exclusion
 *
 * History
 * -------
 * $Log: excltest.c,v $
 * Revision 6.3  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.2  2000/10/20 19:40:55  dieter
 * Updated calls to chkpt_exclude_region to include remap flag.
 *
 * Revision 6.1  2000/05/02  20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.3  2000/05/02 20:10:55  dieter
 * Make sure that big excluded chunks are still mapped after recovery.
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.3  2000/02/01 23:52:20  dieter
 * Changes to make compiling easier (or possible) for both Linux and Solaris
 *
 * Revision 3.2  1999/07/06 20:24:47  dieter
 * Added a test where a mapping that is mapped using mmap is excluded
 * entirely from the checkpoint.
 *
 * Revision 3.1  1999/03/03  20:19:18  dieter
 * Made release 0.02
 *
 * Revision 1.1  1999/01/13  21:46:28  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "checkpoint.h"

#define TIME_BUF_SZ 32
#define HUGE_SIZE (4 * 1024 * 1024)

int main(int argc, char *argv[])
{
  char *not_saved;
  char saved[TIME_BUF_SZ];
  time_t clock;
  long page_size;

  int fd;
  char *mapped_saved;
  char *mapped_unsaved;

  char *big_chunk;		/* a big chunk of malloc'ed memory */

  page_size = sysconf(_SC_PAGESIZE);
  not_saved = valloc(page_size);
  if (not_saved == NULL) {
    perror("malloc");
    return -1;
  }
  clock = time(NULL);
  ctime_r(&clock, not_saved, TIME_BUF_SZ);

  if ( (fd = open("/dev/zero", O_RDWR)) == -1) {
    perror(argv[0]);
    exit(-1);
  }

  /* basic test for memory exclusion */
  /* map some regions to test exclusion.  They need to be mapped before
   * checkpoint_init so the excluded region will be present during recovery.
   */
  mapped_saved = mmap(NULL, page_size, PROT_READ|PROT_WRITE,
		      MAP_PRIVATE, fd, 0);
  if(mapped_saved == MAP_FAILED) {
    perror(argv[0]);
    exit(-1);
  }
  mapped_unsaved = mmap(NULL, page_size, PROT_READ|PROT_WRITE,
		      MAP_PRIVATE, fd, 0);
  if(mapped_unsaved == MAP_FAILED) {
    perror(argv[0]);
    exit(-1);
  }
  close(fd);

  chkpt_init(&argc, argv, NULL);

  ctime_r(&clock, saved, TIME_BUF_SZ);
  chkpt_exclude_region(not_saved, page_size, CHKPT_EXCL_REMAP);

  /* try excluding a page in a separate mapping */

  ctime_r(&clock, mapped_saved, TIME_BUF_SZ);
  ctime_r(&clock, mapped_unsaved, TIME_BUF_SZ);
  chkpt_exclude_region(mapped_unsaved, page_size, CHKPT_EXCL_REMAP);

  if ( (big_chunk = malloc(HUGE_SIZE)) == NULL) {
    perror(argv[0]);
    exit(-1);
  }
  chkpt_exclude_region(big_chunk, HUGE_SIZE, CHKPT_EXCL_REMAP);

  chkpt_now("excltest.chkpt");

  printf("saved time '%s'\n", saved);
  printf("unsaved time '%s'\n", not_saved);
  
  printf("mapped saved time '%s'\n", mapped_saved);
  printf("unampped saved time '%s'\n", mapped_unsaved);

  printf("write into excluded region...");
  sprintf(mapped_unsaved, "this is a test");

  /* write into middle of big chunk to make sure it is all mapped */
  sprintf(big_chunk + HUGE_SIZE / 2, "this is a test");
  printf("write succeeded\n");

  
  return 0;
}
