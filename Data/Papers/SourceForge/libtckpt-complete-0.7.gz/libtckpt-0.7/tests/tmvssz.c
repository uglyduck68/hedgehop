/*
 * Generate a graph of time versus size by taking checkpoints of
 * increasing size
 *
 * History
 * -------
 * $Log: tmvssz.c,v $
 * Revision 1.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 1.1  2001/01/05 19:43:58  dieter
 * This program takes checkpoints of increasing size to determine the
 * relationship between checkpoint size and checkpoint time.
 *
 */

#include "config.h"

#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "checkpoint.h"

int main(int argc, char *argv[])
{
  char *chunk;			/* a big chunk of memory */
  size_t size;			/* size of chunk */
  size_t old_size;		/* previous size of chunk */
  struct stat chkpt_stat;	/* information about the checkpoint file */

  chkpt_init(&argc, argv, NULL);
  chkpt_now("tmvssz.chkpt");
  stat("tmvssz.chkpt", &chkpt_stat);
  printf("checkpoint size is %ld bytes\n", chkpt_stat.st_size);

  /* start with no chunck and grow to 1M by 4K steps */

  size = 4096;
  if ( (chunk = (char *)malloc(size)) == NULL) {
    fprintf(stderr, "failed to alloc chunk of %d bytes\n", size);
    exit(-1);
  }
  /* touch all the memory to make sure it is really allocated */
  memset(chunk, 0x55, size);

  do {
    chkpt_now("tmvssz.chkpt");
    stat("tmvssz.chkpt", &chkpt_stat);
    printf("checkpoint size is %ld bytes\n", chkpt_stat.st_size);

    old_size = size;
    size += 4096;
    if ( (chunk = (char *)realloc(chunk, size)) == NULL) {
      fprintf(stderr, "failed to alloc chunk of %d bytes\n", size);
      exit(-1);
    }
    /* touch all the new memory to make sure it is really allocated */
    memset(chunk + old_size, 0x55, size - old_size);
  } while(size <= 1024 * 1024);

  /* start at 2 MB and go to 128 MB in 1 MB steps */
  size = 2 * 1024 * 1024;
  do {
    chkpt_now("tmvssz.chkpt");
    stat("tmvssz.chkpt", &chkpt_stat);
    printf("checkpoint size is %ld bytes\n", chkpt_stat.st_size);

    old_size = size;
    size += 1024 * 1024;
    if ( (chunk = (char *)realloc(chunk, size)) == NULL) {
      fprintf(stderr, "failed to alloc chunk of %d bytes\n", size);
      exit(-1);
    }
    /* touch all the new memory to make sure it is really allocated */
    memset(chunk + old_size, 0x55, size - old_size);
  } while(size <= 128 * 1024 * 1024);

  return 0;
}
