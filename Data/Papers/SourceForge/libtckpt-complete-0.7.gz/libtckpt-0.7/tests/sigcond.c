/*
 * sigcond.c
 *
 * see how condition variables behave with signals.
 *
 * History
 * -------
 * $Log: sigcond.c,v $
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 1.1  1999/11/01 13:36:28  dieter
 * Initial revision
 *
 */

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

/*****************************************************************************/
/*			Macro Definitions				     */
/*****************************************************************************/

#define DEFAULT_THREADS 5	/* number of threads incl. the main thread */
#if OS == LINUX
#define SIGCHKPT        SIGFPE
#else
#define SIGCHKPT	SIGUSR1
#endif

/*****************************************************************************/
/*			Type Declarations				     */
/*****************************************************************************/

/*****************************************************************************/
/*			Global Variables				     */
/*****************************************************************************/

int num_threads = DEFAULT_THREADS;
pthread_mutex_t test_mutex;
pthread_cond_t  test_cond;
pthread_cond_t  thread_ready_cond;
int ready_threads = 0;
pthread_cond_t  thread_done_cond;
int done_threads = 0;
int test_done = 0;

/*****************************************************************************/
/*			Function Prototypes				     */
/*****************************************************************************/

void handle_args(int argc, char *argv[]);
void *do_test(void *arg);

void chkpt_handler(int signo, siginfo_t *info, void *uc);

/*****************************************************************************/
/*			Function Definitions				     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  int thr_id;
  pthread_attr_t attr;
  pthread_t *tid;
  struct sigaction sigchkpt_action;

  handle_args(argc, argv);

  pthread_mutex_init(&test_mutex, NULL);
  pthread_cond_init(&test_cond, NULL);
  if ( (tid = (pthread_t *)malloc(sizeof(pthread_t) * num_threads)) == NULL) {
    fprintf(stderr, "cannot allocate thread id array\n");
    exit(-1);
  }

  sigchkpt_action.sa_handler = (void (*)(int))chkpt_handler;
  sigemptyset(&sigchkpt_action.sa_mask);
  sigchkpt_action.sa_flags = SA_RESTART|SA_SIGINFO;
  sigaction(SIGCHKPT, &sigchkpt_action, NULL);
  
  pthread_attr_init(&attr);
  pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
  for(thr_id = 0 ; thr_id < num_threads ; thr_id++) {
    pthread_create(&tid[thr_id], &attr, do_test, (void *)thr_id);
    pthread_detach(tid[thr_id]);
  }
  pthread_attr_destroy(&attr);

  pthread_mutex_lock(&test_mutex);
  while(ready_threads < num_threads) {
    pthread_cond_wait(&thread_ready_cond, &test_mutex);
    printf("%d threads are ready\n", ready_threads);
  }

  for(thr_id = 0 ; thr_id < num_threads ; thr_id++) {
    printf("sending signal to thread %d\n", thr_id);
    pthread_kill(tid[thr_id], SIGCHKPT);
  }
  printf("sent signals to all threads\n");
  
  while(done_threads < num_threads) {
    pthread_cond_wait(&thread_done_cond, &test_mutex);
    printf("%d threads are ready\n", done_threads);
  }
  pthread_mutex_unlock(&test_mutex);
  return 0;
}

void *do_test(void *arg)
{
  int thr_id;
  int status;

  thr_id = (int)arg;

  printf("thread %d has pthread id %ld\n", thr_id, pthread_self());
  pthread_mutex_lock(&test_mutex);
  ready_threads++;
  pthread_cond_signal(&thread_ready_cond);

  while(!test_done) {
    status = pthread_cond_wait(&test_cond, &test_mutex);
    printf("thread %d unblocked from pthread_cond_wait, status = ", thr_id);
    if (status == EINTR) {
      printf("EINTR\n");
    } else {
      printf("%d\n", status);
    }
  }
  pthread_mutex_unlock(&test_mutex);

  return NULL;
}

void handle_args(int argc, char *argv[])
{
  int errflg = 0;
  int option;

  while ((option = getopt(argc, argv, "t:")) != EOF)
    switch (option) {
    case 't':
      num_threads = atoi(optarg);
      break;
    case '?':
      errflg++;
    }
  if (errflg) {
    fprintf(stderr, "test program that uses threads and synchronization\n");
    fprintf(stderr, "usage: %s [ -t threads ]\n", argv[0]);
    exit (2);
  }

}

void chkpt_handler(int signo, siginfo_t *info, void *uc)
{
  printf("pthread id %ld in chkpt_handler for\n", pthread_self());
}
