/*
 * a simple test using a pipe
 *
 * main thread writes to the pipe, another thread reads from the pipe
 *
 * History
 * -------
 * $Log: pipetest.c,v $
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 1.1  2000/01/19 15:43:21  dieter
 * Initial revision
 *
 */
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "checkpoint.h"

#define MAX_MSGS  100000
#define MAX_MSG_SZ 4096
int pipedes[2];

void *pipe_reader(void *arg);

int main(int argc, char *argv[])
{
  int status;
  pthread_t tid;
  void *ret;
  int msg_cnt;
  char pipe_msg[MAX_MSG_SZ];

  chkpt_init(&argc, argv, NULL);

  if ( (status = pipe(pipedes)) < 0) {
    fprintf(stderr, "cannot open pipe: %s\n", strerror(errno));
    exit(-1);
  }

  if ( (status = pthread_create(&tid, NULL, pipe_reader, NULL)) != 0) {
    fprintf(stderr, "error creating thread %s\n", strerror(status));
    exit(-1);
  }

  for(msg_cnt = 0 ; msg_cnt < MAX_MSGS ; msg_cnt++) {
    sprintf(pipe_msg, "this is message %d\n", msg_cnt);
    write(pipedes[1], pipe_msg, strlen(pipe_msg));
  }
  close(pipedes[1]);

  if ( (status = pthread_join(tid, &ret)) != 0) {
    fprintf(stderr, "pthread_join failed: %s\n", strerror(status));
    exit(-1);
  }

  return 0;
}

void *pipe_reader(void *arg)
{
  int bytes_read;
  char pipe_msg[MAX_MSG_SZ];

  bytes_read = 1;
  while(bytes_read > 0) {
    if ( (bytes_read = read(pipedes[0], pipe_msg, MAX_MSG_SZ)) > 0)
      write(1, pipe_msg, bytes_read);
  }

  return NULL;
}
