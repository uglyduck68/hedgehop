/*
 * coop.c
 *
 * A simple program to test threads with checkpointing.  The threads cooperate
 * in the synchronization and gathering information to be saved.  The program
 * just tests whether a multithreaded program can be restarted in some
 * reasonable way.
 *
 * History
 * -------
 * $Log: iocptest.c,v $
 * Revision 6.3  2001/06/06 22:46:26  wrdieter
 * First cut at asynchronous checkpointing with clone.  Due to a race recovery
 * does not work all the time...
 *
 * Revision 6.2  2001/06/06 21:26:39  wrdieter
 * Changed checkpoint_init to chkpt_init.
 *
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.2  2000/02/02 14:55:20  dieter
 * Switched to checkpoint_init with options argument.
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.2  2000/02/01 23:52:20  dieter
 * Changes to make compiling easier (or possible) for both Linux and Solaris
 *
 * Revision 3.1  1999/03/03 20:18:03  dieter
 * Made release 0.02
 *
 * Revision 2.1  1998/12/22  15:12:36  dieter
 * version that worked for ftcs paper.
 *
 * Revision 1.7  1998/12/22  15:12:02  dieter
 * removed include of setjmp (it is no longer necesary).
 *
 * Revision 1.6  1998/12/03  14:53:47  dieter
 * removed unused variable.
 *
 * Revision 1.5  1998/12/03  14:52:38  dieter
 * Added braces around PTHREAD_MUTEX_INITIALIZER and
 * PTHREAD_COND_INITIALIZER to remove warnings.
 *
 * Revision 1.4  1998/09/15  14:34:24  dieter
 * Added support for memdebug.
 *
 * Revision 1.3  1998/08/31  20:48:12  dieter
 * Pass a pointer to argc to it can be updated.
 *
 * Revision 1.2  1998/08/31  12:21:52  dieter
 * Take out explicit call to checkpoint_now.
 *
 * Revision 1.1  1998/08/25  20:18:04  dieter
 * Initial revision
 *
 * Revision 1.6  1998/08/18  19:07:49  dieter
 * Added stubs for checkpoint thread.
 *
 * Revision 1.5  1998/08/16  17:37:39  dieter
 * Added dummy loop with sched_yield because the program does not work if
 * sleep is interrupted to take a checkpoint.  This may be bad.
 *
 * Revision 1.4  1998/08/16  16:42:17  dieter
 * Made changes so that threads checkpoint when they get a SIGUSR1.
 * Recovery does not work yet.
 *
 * Revision 1.3  1998/08/11  15:38:04  dieter
 * changed name of checkpoint file to cptest.chkpt.
 *
 */

#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

#include <sched.h>		/* for sched_yeild */

#include "memdebug.h"
#include "checkpoint.h"

#define CHKPT_FILENAME "cptest.chkpt"
#define NUM_THREADS  5		/* number of threads incl. the main thread */

pthread_t thread[NUM_THREADS];

void *thread_func(void *arg);

void barrier(void);

extern chkpt_opt_t chkpt_opts;

int main( int argc, char *argv[] )
{
  int status;
  int thr;
  struct timeval start_time;	/* time when checkpoint starts */
  struct timeval end_time;	/* time when checkpoint ends */

  chkpt_init( &argc, argv, NULL );

  /* main thread is thread 0 */
  thread[0] = pthread_self();

  /* start some threads */
  for( thr = 1 ; thr < NUM_THREADS ; thr++ ) {
    status = pthread_create(&thread[thr], NULL, thread_func, NULL);
    if( status < 0 ) {
      fprintf(stderr, "Could not create thread %d\n", thr);
      fprintf(stderr, "pthread_create: %s\n", strerror(status));
      exit(-1);
    }
  }
  
  /* 
     wait for all threads to stop at a barrier
     At this point the threads have saved their local state.
   */

  printf("main thread (%ld) waiting at barrier\n", pthread_self());
  barrier();
  printf("main thread past initial barrier\n");
  fflush(stdout);
  
  gettimeofday( &start_time, NULL );

#if 0
  if( chkpt_opts.enable )
    chkpt_now( CHKPT_FILENAME );
#endif

  printf( "checkpoint done; restarting threads\n" );

  barrier();

  gettimeofday( &end_time, NULL );
  printf( "The checkpoint took %g seconds.\n",
	  (end_time.tv_sec - start_time.tv_sec)
	  + (end_time.tv_usec - start_time.tv_usec) * 1e-6 );

  /* have the threads do something to show they are still running */

  /* wait for all threads to finish */
  barrier();

  return 0;
}

#define FNAME_MAX 256
 
void *thread_func(void *arg)
{
  int tid;
  long wait_count;
  char filename[FNAME_MAX];
  int outfd;
  char outchar;

  tid = pthread_self();

  printf("Thread %d waiting at initial barrier\n", tid);

  sprintf(filename, "out.%d", tid);
  outfd = open(filename, O_WRONLY|O_CREAT, 0644);
  if (outfd == -1) {
    fprintf(stderr, "cannot create output file %s\n", filename);
    perror("open");
    exit(-1);
  }

  /* wait for other threads to start up */
  barrier();
  printf("Thread %d past initial barrier\n", tid);
  fflush(stdout);

  /* do some busy work to wait for checkpointing to happen */
  if (chkpt_opts.period != 0) {
    for (wait_count = 0 ; wait_count < 30 ; wait_count++) {
      if (wait_count % 3 == 0) {
	printf("...%d,%ld", tid, wait_count);
	fflush(stdout);
      }

      sleep(1);

      outchar = 0x20 + (wait_count % 0x5f);
      write(outfd, &outchar, sizeof(char));
    }
  }

  close(outfd);

  /* now that the local state is saved wait for main thread */
  barrier();

  printf("thread that was %d is now %ld\n", tid, pthread_self());
  /* wait for all other threads to finish */
  barrier();

  printf("thread %d past final barrier\n", tid);

  return NULL;
}

void barrier(void) 
{
  static pthread_mutex_t  barrier_mutex = PTHREAD_MUTEX_INITIALIZER;
  static pthread_cond_t   barrier_cond = PTHREAD_COND_INITIALIZER;
  static int waiting_threads = 0;
  static int next_wait = NUM_THREADS;

  int wait_val;
  int my_val;

  pthread_mutex_lock(&barrier_mutex);

  /* 
   * need to store wait val in a local because barrier_count might
   * change before this thread gets to run
   */
  wait_val = next_wait;
  waiting_threads++;
  my_val = waiting_threads;
  while( waiting_threads < wait_val ) {
    pthread_cond_wait(&barrier_cond, &barrier_mutex);
  }

  if( my_val == wait_val ) {
    pthread_cond_broadcast(&barrier_cond);
    next_wait += NUM_THREADS;
  }

  pthread_mutex_unlock(&barrier_mutex);
}
