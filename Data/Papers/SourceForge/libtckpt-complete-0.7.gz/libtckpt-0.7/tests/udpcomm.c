/*
 * communication routines used by udpserv.c and udpcli.c
 *
 * History
 * -------
 * $Log: udpcomm.c,v $
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.1  1999/03/03 20:18:03  dieter
 * Made release 0.02
 *
 * Revision 1.1  1998/10/14  17:21:25  dieter
 * Initial revision
 *
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "udpcomm.h"
#include "udperr.h"

int wait_for_message(int socket, message_t *msg, struct sockaddr_in *sender)
{
  int status;
  int sender_len;

  sender_len = sizeof(struct sockaddr_in);
  status = recvfrom(socket, (char *)msg, sizeof(message_t), 0,
		    (struct sockaddr *)sender, &sender_len);
  if (status == -1) {
    fprintf(stderr, "error reading from socket %d\n", socket);
    return errno;
  }

  return status;
}

int send_message(int socket, message_t *msg, struct sockaddr_in *receiver)
{
  int status;

  status = sendto(socket, (char *)msg, sizeof(message_t), 0,
		  (struct sockaddr *)receiver, sizeof(struct sockaddr_in));
  if (status == -1) {
    fprintf(stderr, "error sending message to %s:%d on socket %d\n",
	    inet_ntoa(receiver->sin_addr), ntohs(receiver->sin_port), socket);
    return errno;
  }

  return status;
}
