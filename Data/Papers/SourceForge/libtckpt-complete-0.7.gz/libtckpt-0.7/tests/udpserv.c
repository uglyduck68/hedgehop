/*
 * server for a simple UDP ping program
 *
 * History
 * -------
 * $Log: udpserv.c,v $
 * Revision 6.1  2000/05/02 20:13:39  dieter
 * Released version 0.6
 *
 * Revision 5.1  2000/02/01 23:55:20  dieter
 * Release 0.5 plus some fixes.
 *
 * Revision 3.1  1999/03/03 20:18:03  dieter
 * Made release 0.02
 *
 * Revision 1.1  1998/10/14  17:21:25  dieter
 * Initial revision
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "udperr.h"
#include "udpcomm.h"
 
/*****************************************************************************/
/*				Macros					     */
/*****************************************************************************/

/*****************************************************************************/
/*			    Type Declarations				     */
/*****************************************************************************/

typedef struct server_opts{
  struct sockaddr_in addr;
} server_opt_t;

/*****************************************************************************/
/*			   Function Prototypes				     */
/*****************************************************************************/

int handle_opts(int argc, char *argv[], server_opt_t *opts);
int get_port(char *prog, char *port_str);
void usage(char *prog);

int get_server_socket(server_opt_t *opts);

/*****************************************************************************/
/*			   Function Declarations			     */
/*****************************************************************************/

int main(int argc, char *argv[])
{
  server_opt_t opts;
  int server_socket;
  int status;
  message_t msg;
  struct sockaddr_in client;
  
  handle_opts(argc, argv, &opts);

  /* open my socket */
  server_socket = get_server_socket(&opts);
  if( server_socket < 0 ) {
    fprintf(stderr, "%s: error opening server socket\n", argv[0]);
    fprintf(stderr, "%s\n", strerror(server_socket));
  }

  printf("server started on %s:%d\n", inet_ntoa(opts.addr.sin_addr),
	 ntohs(opts.addr.sin_port));
  status = 0;
  while(status >= 0) {
    /* intialize the client structure to expect a client from any host */
    memset(&client, 0, sizeof(struct sockaddr_in));
    client.sin_family = AF_INET;
    client.sin_port   = htons(0);
    client.sin_addr.s_addr = INADDR_ANY;
    
    /* listen for incoming messages */
    status = wait_for_message(server_socket, &msg, &client);
    if( status < 0 ) {
      fprintf(stderr, "%s: error waiting for message\n", argv[0]);
      fprintf(stderr, "%s\n", strerror(status));
      exit(status);
    }

    printf("received message %ld from client\n", msg.count);

    /* reply to incoming messages */
    status = send_message(server_socket, &msg, &client);
    if( status < 0 ) {
      fprintf(stderr, "%s: error sending message\n", argv[0]);
      fprintf(stderr, "%s\n", strerror(status));
      exit(status);
    }
  }

  close(server_socket);
  
  return 0;
}

/*****************************************************************************/
/*		        Command Line Option Handling			     */
/*****************************************************************************/

int handle_opts(int argc, char *argv[], server_opt_t *opts)
{
  int opt;

  /* initialize address */
  memset(&opts->addr, 0, sizeof(struct sockaddr_in));
  opts->addr.sin_family = AF_INET;
  opts->addr.sin_port = htons(0);
  opts->addr.sin_addr.s_addr = INADDR_ANY;

  /* handle command line arguments */
  while((opt = getopt(argc, argv, "p:")) != EOF) {
    switch(opt) {
    case 'p':
      opts->addr.sin_port = htons(get_port(argv[0], optarg));
      break;
    default:
      fprintf(stderr, "unknown option '%c'\n", opt);
      usage(argv[0]);
      exit(UNKOWN_OPT);
      break;
    }
  }
  
  return 0;
}

int get_port(char *prog, char *port_str)
{
  long port;

  port = atoi(port_str);
  if (port < 0 || port > 65535) {
    fprintf(stderr, "%ld is and illegal port value\n", port);
    usage(prog);
    exit(BAD_PORT);
  }

  return port;
}

void usage(char *prog)
{
  fprintf(stderr, "usage: %s [ -p port ] \n", prog);
  fprintf(stderr, "   -p port	use port as the server's udp port\n");
}

/*****************************************************************************/
/*		              Communication				     */
/*****************************************************************************/

int get_server_socket(server_opt_t *opts)
{
  int server_socket;
  int addr_len;
  int status;

  server_socket = socket(AF_INET, SOCK_DGRAM, 0);
  if (server_socket == -1) {
    fprintf(stderr, "Error allocating socket\n");
    return -errno;
  }

  status = bind(server_socket, (struct sockaddr *)&opts->addr,
		sizeof(struct sockaddr_in));
  if(status == -1) {
    fprintf(stderr, "Error binding socket to %s:%d\n",
	    inet_ntoa(opts->addr.sin_addr), ntohs(opts->addr.sin_port));
    return -errno;
  }
  
  addr_len = sizeof(struct sockaddr_in);
  status = getsockname(server_socket, (struct sockaddr *)&opts->addr,
		       &addr_len);
  if (status < 0) {
    fprintf(stderr, "could not read socket name\n");
    return -errno;
  }

  return server_socket;
}
