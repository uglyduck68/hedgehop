#include "interface/ICommandInterfaceDDS.h"
#include "msg/rmOPV_Protocol.hpp"
ADD_DDSCommand(1,SC_SIM_OWNSHIP);
ADD_DDSCommand(1,SC_SIM_ENTITY);
ADD_DDSCommand(1,SIM_SC_ENTITY_STATE);
ADD_DDSCommand(1,SC_SIM_ENVIRONMENT);