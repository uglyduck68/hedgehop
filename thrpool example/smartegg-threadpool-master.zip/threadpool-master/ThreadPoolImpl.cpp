#include "ThreadPoolImpl.hpp"

namespace  ndsl {

ThreadPoolImpl::ThreadPoolImpl(int minCap, int maxCap) {

}

ThreadPoolImpl::~ThreadPoolImpl() {

}

} //namespace ndsl
