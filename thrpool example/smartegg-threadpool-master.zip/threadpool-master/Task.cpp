/**
 * @file Task.cpp
 * @brief
 * @author smartegg<lazysmartegg@gmail.com>
 * @version 1.0
 * @date Fri, 04 May 2012 14:02:00
 * @copyright Copyright (C) 2012 smartegg<lazysmartegg@gmail.com>
 */

#include "Task.hpp"

namespace ndsl {

Task::Task() {

}

Task::~Task() {

}



} //namespace ndsl
